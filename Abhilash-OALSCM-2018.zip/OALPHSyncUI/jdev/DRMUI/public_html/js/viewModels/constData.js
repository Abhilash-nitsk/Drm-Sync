/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout'], function (oj, ko, $) {
    /**
     * The view model for the main content view template
     */
    function constDataViewModel() {
        var self = this;

        self.base_url = '';
        //security
        self.isValidUser = ko.observable(true);
	self.isdrmuser=ko.observable(true);
        

        

        self.GetData = function (url, req_type, req_async_type, username, page, msg) {
            var obj = {
                status: '',
                reqLog: '',
                data: ''
            };
            
            if(username !== '' && username !== null && username.length > 0){
                url = url + '?username=' + username+'&page=0';
            }
            

            $.ajax({
                url: self.base_url + url,
                type: req_type,
                async: req_async_type,
                success: function (data, textStatus) {
                   obj.status=textStatus;
                   obj.reqLog= '';
                   obj.data=data;   
                },
                error: function (xhr, textStatus, err) {
                   obj.status=textStatus;
                   obj.reqLog= err;
                   obj.data= '';
                }
            });
            return obj;
        };

    }
    ;

    return new constDataViewModel();
});

