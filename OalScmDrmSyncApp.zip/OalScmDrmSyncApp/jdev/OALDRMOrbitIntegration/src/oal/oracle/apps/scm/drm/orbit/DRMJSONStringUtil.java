package oal.oracle.apps.scm.drm.orbit;

public class DRMJSONStringUtil {
    public DRMJSONStringUtil() {
        super();
    }
    public static final String CATALOG_CODE = "catalogCode";
    public static final String CATEGORY_CODE = "categoryCode";
    public static final String CATEGORY_PROCESSED_FLAG = "processedFlag";
    public static final String CATEGORY_NAME = "categoryName";
    public static final String CATEGORY_DESCRIPTION = "categoryDescription";
    public static final String CATEGORY_PARENT_CATEGORY_CODE = "parentCategoryCode";
    public static final String START_DATE = "startDate";
    public static final String END_DATE = "endDate";
    public static final String CATEGORY_IS_LEAF = "isLeaf";
    public static final String CATEGORY_LEVEL = "levl";
    public static final String CATEGORY_DISABLE_FLAG = "disableFlag";
    public static final String CATEGORY_END_DATE = "endDate";
    public static final String REFRESH_ID = "refreshId";
    public static final String COMMENTS = "comments";
    
    
    // ITEM
    public static final String ITEM="item";
    public static final String ITEM_ORGANIZATION_CODE="OrganizationCode";
    public static final String ITEM_CLASS="ItemClass";
    public static final String ITEM_NUMBER="ItemNumber";
    public static final String ITEM_DESCRIPTION="ItemDescription";
    public static final String ITEM_STATUS_VALUE="ItemStatusValue";
    public static final String ITEM_LIFECYCLE_PHASE_VALUE="LifecyclePhaseValue";
    public static final String ITEM_PRIMARY_UNIT_OF_MEASUREMENT="PrimaryUOMValue";
    
    public static final String ITEM_CATEGORY="ItemCategory";
    public static final String ITEM_CATALOG="ItemCatalog";
    
    
    
    public static String DATE_FORMAT="yyyy-MM-dd";
   
    
    
    
    
    
}
