package oal.oracle.apps.scm.drm.orbit;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;

import org.apache.commons.lang.StringEscapeUtils;

import java.io.ByteArrayOutputStream;

import java.io.IOException;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import java.io.StringReader;

import oal.util.logger.*;

import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Base64;
import java.util.Date;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class OrbitMicroServiceInvoker {
    
   


    private static String loggerName = OrbitMicroServiceInvoker.class.getName();

    public OrbitMicroServiceInvoker() {
        super();
    }
    
    private static SOAPMessage getNewSOAPMessage() throws SOAPException {
        //Create soap message for the web service request
        MessageFactory messageFactory = MessageFactory.newInstance();
        //SOAPConstants.SOAP_1_2_PROTOCOL
        //MessageFactory.newInstance();
         return messageFactory.createMessage();
    }
    
    private static SOAPEnvelope getEnvelop(SOAPMessage soapMessage) throws SOAPException {
       
        SOAPPart soapPart = soapMessage.getSOAPPart();
        String authorization = DRMSyncPropertyV2.getInstance().getAuthorizationKey();
        MimeHeaders hd = soapMessage.getMimeHeaders();
        // hd.setHeader("Content-Type","application/soap+xml;charset=UTF-8;");
        hd.addHeader("Authorization", "Basic " + authorization);
        return soapPart.getEnvelope();
    }
   

    public static boolean invokeMergeItemService(JSONObject data) throws SOAPException, IOException, JSONException {


        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Invoking Process Item through Orbit Microservice");
        SOAPMessage soapMessage=OrbitMicroServiceInvoker.getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = OrbitMicroServiceInvoker.getEnvelop(soapMessage);
        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("mod",
                                             "http://xmlns.oracle.com/apps/flex/fnd/applcore/attachments/model/");
        soapEnvelope.addNamespaceDeclaration("item3",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/flex/itemGdf/");
        soapEnvelope.addNamespaceDeclaration("item2", "http://xmlns.oracle.com/apps/scm/productModel/items/flex/item/");
        soapEnvelope.addNamespaceDeclaration("cat2",
                                             "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/");
        soapEnvelope.addNamespaceDeclaration("cat1",
                                             "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/");
        soapEnvelope.addNamespaceDeclaration("item1",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/flex/itemRevision/");
        soapEnvelope.addNamespaceDeclaration("cat",
                                             "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemSupplier/categories/");
        soapEnvelope.addNamespaceDeclaration("item",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

      


        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement processItem = soapBody.addChildElement(DRMXMLStringUtil.ITEM_OPERATION_MERGE_ITEM, "typ");


        //  SOAPElement category = processCategory.addChildElement("category","typ");
        //            documentNumber.addTextNode("100");


        JSONObject jobj = data;

        addItemData(jobj, processItem);

        soapMessage.saveChanges();
       
        //Parse the recipe response
        SOAPBody responseSoapBody = invokeService(soapMessage, DRMSyncPropertyV2.getInstance().getItemServiceURL());
        java.util.Iterator iterator = responseSoapBody.getChildElements();
        SOAPBodyElement bodyElement2 = (SOAPBodyElement) iterator.next();
        if (bodyElement2.getTagName().contains("Fault"))
            throw new SOAPException();
       // String responseBody = bodyElement2.toString();
        //  System.out.print(responseBody);


        return true;
    }
    
    public static boolean invokeUpdateCategoryService(String categoryCode,String categoryName,String catalogName) throws SOAPException, IOException {

        //        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(),loggerName,DRMSyncPropertyV2.getInstance().getLoggerID(),
        //                          "debug","Invoking MergeCategory through Orbit Microservice");
      
        SOAPMessage soapMessage=getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = getEnvelop(soapMessage);

        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/types/");
        soapEnvelope.addNamespaceDeclaration("item",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/");
        soapEnvelope.addNamespaceDeclaration("cat",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/flex/category/");
        soapEnvelope.addNamespaceDeclaration("typ1", "http://xmlns.oracle.com/adf/svc/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

        
      

        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement processCategory =
        soapBody.addChildElement("updateCategory", "typ");
        
        SOAPElement category = processCategory.addChildElement("category", "typ");

        SOAPElement catName = category.addChildElement("CategoryName", "item");
        catName.addTextNode(categoryName);
        

        SOAPElement catCode = category.addChildElement("CategoryCode", "item");
        catCode.addTextNode(categoryCode);

        SOAPElement catalogCode = category.addChildElement("CatalogCode", "item");
        catalogCode.addTextNode(catalogName);

        
        soapMessage.saveChanges();
       // ByteArrayOutputStream out = new ByteArrayOutputStream();
      //  soapMessage.writeTo(out);
      //  String strMsg = new String(out.toByteArray());
       // System.out.print(strMsg);
        //Parse the recipe response
        SOAPBody responseSoapBody = invokeService(soapMessage,DRMSyncPropertyV2.getInstance().getCatalogServiceURL());
        java.util.Iterator iterator = responseSoapBody.getChildElements();
        SOAPBodyElement bodyElement2 = (SOAPBodyElement) iterator.next();
        
       

        if (bodyElement2.getTagName().contains("Fault")) {
            
            System.out.println("Errored: "+categoryCode);
           
            java.util.Iterator iterator2 = bodyElement2.getChildElements();
            iterator2.next();
            SOAPElement bodyElement3 = (SOAPElement) iterator2.next();
            throw new SOAPException();
        }
     //   String responseBody = bodyElement2.toString();
     //   System.out.print(responseBody);
        return true;
    }
    
    
    public static void addItemData(JSONObject jobj, SOAPElement processItem) throws SOAPException, JSONException {
        SOAPElement item = processItem.addChildElement(DRMXMLStringUtil.ITEM, "typ");

        SOAPElement orgCode = item.addChildElement(DRMXMLStringUtil.ITEM_ORGANIZATION_CODE, DRMXMLStringUtil.ITEM);
        orgCode.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_ORGANIZATION_CODE));

        SOAPElement itemClass = item.addChildElement(DRMXMLStringUtil.ITEM_CLASS, DRMXMLStringUtil.ITEM);
        itemClass.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_CLASS));

        SOAPElement itemNumber = item.addChildElement(DRMXMLStringUtil.ITEM_NUMBER, DRMXMLStringUtil.ITEM);
        itemNumber.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_NUMBER));

        SOAPElement itemDesc = item.addChildElement(DRMXMLStringUtil.ITEM_DESCRIPTION, DRMXMLStringUtil.ITEM);
        itemDesc.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_DESCRIPTION));

        SOAPElement itemStatus = item.addChildElement(DRMXMLStringUtil.ITEM_STATUS_VALUE, DRMXMLStringUtil.ITEM);
        itemStatus.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_STATUS_VALUE));

        SOAPElement lcp = item.addChildElement(DRMXMLStringUtil.LIFECYCLE_PHASE_VALUE, DRMXMLStringUtil.ITEM);
        lcp.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_LIFECYCLE_PHASE_VALUE));

        SOAPElement uom = item.addChildElement(DRMXMLStringUtil.PRIMARY_UNIT_OF_MEASUREMENT, DRMXMLStringUtil.ITEM);
        uom.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_PRIMARY_UNIT_OF_MEASUREMENT));


        SOAPElement itemCategory = item.addChildElement(DRMXMLStringUtil.ITEM_CATEGORY, DRMXMLStringUtil.ITEM);

        SOAPElement itemCatalog = itemCategory.addChildElement(DRMXMLStringUtil.ITEM_CATALOG, DRMXMLStringUtil.ITEM);
        itemCatalog.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_CATALOG));

        SOAPElement catName = itemCategory.addChildElement(DRMXMLStringUtil.CATEGORY_NAME, DRMXMLStringUtil.ITEM);
        catName.addTextNode(jobj.getString(DRMJSONStringUtil.ITEM_CATEGORY));

    }

    public static boolean invokeItemService(JSONArray dataArray) throws SOAPException, IOException, JSONException
    {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Invoking Process Item through Orbit Microservice");
        SOAPMessage soapMessage=OrbitMicroServiceInvoker.getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = OrbitMicroServiceInvoker.getEnvelop(soapMessage);

        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("mod",
                                             "http://xmlns.oracle.com/apps/flex/fnd/applcore/attachments/model/");
        soapEnvelope.addNamespaceDeclaration("item3",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/flex/itemGdf/");
        soapEnvelope.addNamespaceDeclaration("item2", "http://xmlns.oracle.com/apps/scm/productModel/items/flex/item/");
        soapEnvelope.addNamespaceDeclaration("cat2",
                                             "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/item/categories/");
        soapEnvelope.addNamespaceDeclaration("cat1",
                                             "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemRevision/categories/");
        soapEnvelope.addNamespaceDeclaration("item1",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/flex/itemRevision/");
        soapEnvelope.addNamespaceDeclaration("cat",
                                             "http://xmlns.oracle.com/apps/scm/productCatalogManagement/advancedItems/flex/egoItemEff/itemSupplier/categories/");
        soapEnvelope.addNamespaceDeclaration("item",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

       

        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement processItem = soapBody.addChildElement(DRMXMLStringUtil.ITEM_OPERATION_PROCESS_ITEM, "typ");


        SOAPElement changeOperation = processItem.addChildElement(DRMXMLStringUtil.ITEM_CHANGE_OPERATION, "typ");
        changeOperation.addTextNode("Merge");

        //  SOAPElement category = processCategory.addChildElement("category","typ");
        //            documentNumber.addTextNode("100");


        for (int i = 0; i < dataArray.length(); i++) {

            JSONObject jobj = dataArray.getJSONObject(i);

            addItemData(jobj, processItem);

        }

        soapMessage.saveChanges();
        
        //Parse the recipe response
        SOAPBody responseSoapBody = invokeService(soapMessage, DRMSyncPropertyV2.getInstance().getItemServiceURL());
        java.util.Iterator iterator = responseSoapBody.getChildElements();
        SOAPBodyElement bodyElement2 = (SOAPBodyElement) iterator.next();
        if (bodyElement2.getTagName().contains("Fault"))
            throw new SOAPException();
       // String responseBody = bodyElement2.toString();
        //  System.out.print(responseBody);

        return true;


    }

    public static void addCategoryData(SOAPElement processCategory,JSONObject jobj,String catalogName) throws SOAPException,
                                                                                            JSONException {
        
        SOAPElement category = processCategory.addChildElement(DRMXMLStringUtil.CATEGORY, "typ");

        SOAPElement catName = category.addChildElement(DRMXMLStringUtil.CATEGORY_NAME, "item");
        catName.addTextNode(jobj.getString(DRMJSONStringUtil.CATEGORY_NAME));

        SOAPElement catCode = category.addChildElement(DRMXMLStringUtil.CATEGORY_CODE, "item");
        catCode.addTextNode(jobj.getString(DRMJSONStringUtil.CATEGORY_CODE));

        SOAPElement desc = category.addChildElement(DRMXMLStringUtil.CATEGORY_DESCRIPTIOIN, "item");
        desc.addTextNode(jobj.getString(DRMJSONStringUtil.CATEGORY_DESCRIPTION));

        
        String startDate = jobj.optString(DRMJSONStringUtil.START_DATE);
        Date date = null;
        DateFormat df = new SimpleDateFormat("dd-MMM-yy");

        if (startDate!=null && !startDate.isEmpty()) {
            try {
                date = df.parse(startDate);
                if (date.compareTo(new Date()) < 0) {
                    date = new Date();
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        if (date == null)
            date = new Date();

        String type = jobj.optString("type");
        if (type.isEmpty())
            type = "N";
        if (type.equals("N") || (type.equals("O") && date.compareTo(new Date()) > 0)) {
            SOAPElement stdate = category.addChildElement(DRMXMLStringUtil.START_DATE, "item");
            String modifiedDate = new SimpleDateFormat(DRMXMLStringUtil.DATE_FORMAT).format(date);
            stdate.addTextNode(modifiedDate);
        }
        
        
        /// END DATE
        String endDate = jobj.optString(DRMJSONStringUtil.END_DATE);
        Date eDate = null;

        if (endDate!=null && !endDate.isEmpty()) {
            try {
                
                eDate = df.parse(endDate);
                
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        if (eDate != null)
          {            
            SOAPElement enDate = category.addChildElement(DRMXMLStringUtil.END_DATE, "item");
            String modifiedDate = new SimpleDateFormat(DRMXMLStringUtil.DATE_FORMAT).format(eDate);
            enDate.addTextNode(modifiedDate);
        }

        ///

        SOAPElement catalogCode = category.addChildElement(DRMXMLStringUtil.CATALOG_CODE, "item");
        catalogCode.addTextNode(catalogName);

        SOAPElement parentCatCode = category.addChildElement(DRMXMLStringUtil.PARENT_CATEGORY_CODE, "item");
        parentCatCode.addTextNode(jobj.getString(DRMJSONStringUtil.CATEGORY_PARENT_CATEGORY_CODE));

    }
    
    public static boolean invokeCategoryService(JSONArray dataArray, String catalogName) throws SOAPException,
                                                                                                IOException,
                                                                                                JSONException {

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Invoking ProcessCategory through Orbit Microservice");
        SOAPMessage soapMessage=OrbitMicroServiceInvoker.getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = OrbitMicroServiceInvoker.getEnvelop(soapMessage);

        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/types/");
        soapEnvelope.addNamespaceDeclaration("item",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/");
        soapEnvelope.addNamespaceDeclaration("cat",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/flex/category/");
        soapEnvelope.addNamespaceDeclaration("typ1", "http://xmlns.oracle.com/adf/svc/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

        //Authentication of soap request in header part
        //   SOAPHeader header = soapEnvelope.getHeader();

        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement processCategory =
            soapBody.addChildElement(DRMXMLStringUtil.CATEGORY_OPERATION_PROCESS_CATEGORY, "typ");


        SOAPElement changeOperation =
            processCategory.addChildElement(DRMXMLStringUtil.CATEGORY_CHANGE_OPERATION, "typ");
        changeOperation.addTextNode("Merge");

        //  SOAPElement category = processCategory.addChildElement("category","typ");
        //            documentNumber.addTextNode("100");

        //  String CategoryName="",CategoryCode="",Description="",StartDate="",CatalogCode="",ParentCategoryCode="";

        for (int i = 0; i < dataArray.length(); i++) {

            JSONObject jobj = dataArray.getJSONObject(i);

           addCategoryData(processCategory, jobj, catalogName);

        }

        SOAPElement processControl = processCategory.addChildElement(DRMXMLStringUtil.CATEGORY_PROCESS_CONTROL, "typ");
        SOAPElement returnMode = processControl.addChildElement(DRMXMLStringUtil.CATEGORY_RETURN_MODE, "typ1");
        returnMode.addTextNode("Full");

        SOAPElement partialFailureAllowed =
            processControl.addChildElement(DRMXMLStringUtil.CATEGORY_PARTIAL_FAILURE_ALLOWED, "typ1");
        partialFailureAllowed.addTextNode("false");

        soapMessage.saveChanges();

        //Parse the recipe response

        SOAPBody responseSoapBody = invokeService(soapMessage, DRMSyncPropertyV2.getInstance().getCatalogServiceURL());
        java.util.Iterator iterator = responseSoapBody.getChildElements();
        SOAPBodyElement bodyElement2 = (SOAPBodyElement) iterator.next();
        if (bodyElement2.getTagName().contains("Fault"))
            throw new SOAPException();
       // String responseBody = bodyElement2.toString();
        //  System.out.print(responseBody);

        return true;

    }

    public static boolean categoryExist(String category) throws SOAPException, IOException {
        //        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(),loggerName,DRMSyncPropertyV2.getInstance().getLoggerID(),
        //                          "debug","Invoking findCategory through Orbit Microservice");
        SOAPMessage soapMessage=OrbitMicroServiceInvoker.getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = OrbitMicroServiceInvoker.getEnvelop(soapMessage);
        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/types/");
        soapEnvelope.addNamespaceDeclaration("typ1", "http://xmlns.oracle.com/adf/svc/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

        


        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement findcat = soapBody.addChildElement("findCategory", "typ");


        SOAPElement findcriteria = findcat.addChildElement("findCriteria", "typ");
        SOAPElement filter = findcriteria.addChildElement("filter", "typ1");
        SOAPElement group = filter.addChildElement("group", "typ1");
        SOAPElement item = group.addChildElement("item", "typ1");

        SOAPElement attribute = item.addChildElement("attribute", "typ1");
        attribute.addTextNode("CategoryCode");

        SOAPElement operator = item.addChildElement("operator", "typ1");
        operator.addTextNode("=");

        SOAPElement value = item.addChildElement("value", "typ1");
        value.addTextNode(category);

        soapMessage.saveChanges();


        SOAPBody responseSoapBody = invokeService(soapMessage, DRMSyncPropertyV2.getInstance().getCatalogServiceURL());

        SOAPElement findCategoryResponse, results = null;

        java.util.Iterator iterator = responseSoapBody.getChildElements();
        if (iterator.hasNext()) {
            findCategoryResponse = (SOAPElement) iterator.next();

            java.util.Iterator iterator1 = findCategoryResponse.getChildElements();
            if (iterator1.hasNext())
                results = (SOAPElement) iterator1.next();
        }
        if (results == null)
            return false;

        // System.out.println("cat exist "+category);
        return true;
    }

    public static void main(String args[]) throws SOAPException, IOException {

        System.out.println(itemExist("00AA1_CRM_ZK2PP"));
        
    }

    public static boolean itemExist(String itemnumber) throws SOAPException, IOException {
        //        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(),loggerName,DRMSyncPropertyV2.getInstance().getLoggerID(),
        //                          "debug","Invoking findCategory through Orbit Microservice");
        //        //Create soap message for the web service request
       
        SOAPMessage soapMessage=OrbitMicroServiceInvoker.getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = OrbitMicroServiceInvoker.getEnvelop(soapMessage);
        

        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/items/itemServiceV2/types/");
        soapEnvelope.addNamespaceDeclaration("typ1", "http://xmlns.oracle.com/adf/svc/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

        //Authentication of soap request in header part
        //   SOAPHeader header = soapEnvelope.getHeader();


       
        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement findcat = soapBody.addChildElement("findItem", "typ");


        SOAPElement findcriteria = findcat.addChildElement("findCriteria", "typ");
        SOAPElement filter = findcriteria.addChildElement("filter", "typ1");
        SOAPElement group = filter.addChildElement("group", "typ1");
        SOAPElement item = group.addChildElement("item", "typ1");

        SOAPElement attribute = item.addChildElement("attribute", "typ1");
        attribute.addTextNode("ItemNumber");

        SOAPElement operator = item.addChildElement("operator", "typ1");
        operator.addTextNode("=");

        SOAPElement value = item.addChildElement("value", "typ1");
        value.addTextNode(itemnumber);

        soapMessage.saveChanges();

       

        SOAPBody responseSoapBody = invokeService(soapMessage, DRMSyncPropertyV2.getInstance().getItemServiceURL());

        SOAPElement findCategoryResponse, results = null, val = null;

        java.util.Iterator iterator = responseSoapBody.getChildElements();
        if (iterator.hasNext()) {
            findCategoryResponse = (SOAPElement) iterator.next();

            java.util.Iterator iterator1 = findCategoryResponse.getChildElements();
            if (iterator1.hasNext())
                results = (SOAPElement) iterator1.next();
        }

        java.util.Iterator iterator2 = results.getChildElements();
        if (iterator2.hasNext())
            val = (SOAPElement) iterator2.next();

        if (val == null)
            return false;
        // System.out.println("cat exist "+category);
        return true;
    }

    public static SOAPBody invokeService(SOAPMessage soapMessage,String serviceEndPoint) throws SOAPException,
                                                                                                 IOException {
        
        System.out.println(soapMessage.toString());

        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();
       
        URL endpoint = new URL(serviceEndPoint);
        //Throw Exception if the recipe call times out

        //Recipe call
        SOAPMessage response = soapConnection.call(soapMessage, endpoint);


        ByteArrayOutputStream out = new ByteArrayOutputStream();
        soapMessage.writeTo(out);
        String strMsg = new String(out.toByteArray());
        System.out.print(strMsg);


        out = new ByteArrayOutputStream();
        System.out.println("Response");
        response.writeTo(out);
        strMsg = new String(out.toByteArray());
        System.out.print(strMsg);

        //Parse the recipe response
        SOAPBody responseSoapBody = response.getSOAPBody();
        return responseSoapBody;
        
    }
    public static boolean invokeMergeCategoryService(JSONObject data, String catalogName,
                                                     String[] output) throws SOAPException, IOException, JSONException {

        //        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(),loggerName,DRMSyncPropertyV2.getInstance().getLoggerID(),
        //                          "debug","Invoking MergeCategory through Orbit Microservice");
        SOAPMessage soapMessage=OrbitMicroServiceInvoker.getNewSOAPMessage();
        SOAPEnvelope soapEnvelope = OrbitMicroServiceInvoker.getEnvelop(soapMessage);

        //Add Namespace Declaration
        soapEnvelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
        soapEnvelope.addNamespaceDeclaration("typ",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/types/");
        soapEnvelope.addNamespaceDeclaration("item",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/itemCatalogService/");
        soapEnvelope.addNamespaceDeclaration("cat",
                                             "http://xmlns.oracle.com/apps/scm/productModel/catalogs/flex/category/");
        soapEnvelope.addNamespaceDeclaration("typ1", "http://xmlns.oracle.com/adf/svc/types/");
        // soapEnvelope.addNamespaceDeclaration("soapenv","http://schemas.xmlsoap.org/soap/envelope/");

        
      

        //Populate the body part of the soap request
        SOAPBody soapBody = soapEnvelope.getBody();

        //   QName bodyName = new QName("processCategory", "typ");
        SOAPElement processCategory =
            soapBody.addChildElement(DRMXMLStringUtil.CATEGORY_OPERATION_MERGE_CATEGORY, "typ");

        JSONObject jobj = data;

        addCategoryData(processCategory, jobj, catalogName);
        
        soapMessage.saveChanges();
        //Parse the recipe response
        SOAPBody responseSoapBody = invokeService(soapMessage, DRMSyncPropertyV2.getInstance()
                                                .getCatalogServiceURL());
        java.util.Iterator iterator = responseSoapBody.getChildElements();
        SOAPBodyElement bodyElement2 = (SOAPBodyElement) iterator.next();


        if (bodyElement2.getTagName().contains("Fault")) {

            java.util.Iterator iterator2 = bodyElement2.getChildElements();
            iterator2.next();
            SOAPElement bodyElement3 = (SOAPElement) iterator2.next();
            output[0] = "Failure";
            String errormssg = StringEscapeUtils.unescapeHtml(bodyElement3.getTextContent());
            output[1] = errormssg;
            throw new SOAPException();
        }
        String responseBody = bodyElement2.toString();
        System.out.print(responseBody);
        return true;
    }


}
