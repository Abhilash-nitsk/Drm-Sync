package oal.oracle.apps.scm.drm.exception;

public class DRMParentDoesnotExistException extends DRMException {
    public DRMParentDoesnotExistException(String string) {
        super(string);
    }
}
