package oal.oracle.apps.scm.drm.exception;

public class DRMCatalogNotFoundException extends DRMException {
    public DRMCatalogNotFoundException(String string) {
        super(string);
    }
}
