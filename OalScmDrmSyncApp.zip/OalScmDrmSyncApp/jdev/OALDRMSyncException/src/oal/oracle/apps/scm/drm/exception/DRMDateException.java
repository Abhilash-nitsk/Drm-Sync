package oal.oracle.apps.scm.drm.exception;

public class DRMDateException extends DRMException{
    public DRMDateException(String s) {
        super(s);
    }
}
