package oal.oracle.apps.scm.drm.exception;

public class DRMException extends Exception {
    public DRMException(String s) {
        super(s);
    }
   
}
