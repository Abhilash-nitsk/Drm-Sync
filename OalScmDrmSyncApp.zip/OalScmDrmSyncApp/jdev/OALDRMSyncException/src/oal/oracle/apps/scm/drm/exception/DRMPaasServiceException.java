package oal.oracle.apps.scm.drm.exception;

public class DRMPaasServiceException extends DRMException {
    public DRMPaasServiceException(String string) {
        super(string);
    }
}
