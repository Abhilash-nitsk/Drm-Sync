package oal.oracle.apps.scm.drm;

import oal.oracle.apps.scm.drm.exception.DRMCatalogNotFoundException;
import oal.oracle.apps.scm.drm.exception.DRMPaasServiceException;
import oal.oracle.apps.scm.drm.exception.DRMParentDoesnotExistException;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.xml.soap.SOAPException;

import oal.oracle.apps.misegp.drm.OALDRMSyncUtil;
import oal.oracle.apps.scm.drm.OALDRMSync.Processcat;
import oal.oracle.apps.scm.drm.orbit.DRMJSONStringUtil;

import oal.oracle.apps.scm.drm.orbit.OrbitMicroServiceInvoker;

import oal.util.logger.OalLogger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AssociateItem {
    public AssociateItem() {
        super();
    }
    private String loggerName = AssociateItem.class.getName();
    public static void main(String args[]) throws IOException, JSONException, SOAPException,
                                                  DRMCatalogNotFoundException, DRMPaasServiceException,
                                                  DRMParentDoesnotExistException {
     //   new AssociateItem().sync(DRMSyncPropertyV2.Catalog.CRM, "1000");
    }

    public void sync(DRMSyncPropertyV2.Catalog catalog, String refreshId) {
        
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Item Association Started "  + " [" +
                          catalog.getValue() + "]["+refreshId+"]");
        
        String catalogCode = DRMSyncPropertyV2.getInstance().getCatalogCode(catalog);
        String catalogName = DRMSyncPropertyV2.getInstance().getCatalogName(catalog);

        JSONArray dataArray = null;
        JSONArray olddataArray = null;


        int currentLevel = 1;

        int maxLevel = 0;
        try {
            maxLevel = OALDRMSyncUtil.getMaxLevel(DRMSyncPropertyV2.getInstance().getCatalogCode(catalog), refreshId);
        } catch (DRMPaasServiceException e) {
        }
        System.out.println("maxlevel " + maxLevel);

        while (currentLevel <= maxLevel) {
            ExecutorService executorService = Executors.newFixedThreadPool(10);

            System.out.println("current level " + currentLevel);
            String level = String.valueOf(currentLevel);

            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                              "Item Association Started for level "+ level + " [" +
                              catalog.getValue() + "]["+refreshId+"]");
            
            try {
                dataArray = OALDRMSyncUtil.getCategories(catalogCode, currentLevel, refreshId, true);
            } catch (DRMPaasServiceException | JSONException e) {
                
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                                  "Error while getting categories for Item Association at level "+ level + " [" +
                                  catalog.getValue() + "]["+refreshId+"] Error: "+e.getMessage());
            }

            System.out.println("no of data : " + dataArray.length() + " for [" + catalogCode + "] level " + level);

            if (dataArray.length() == 0) {
                currentLevel++;
                
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                                  "No item association data found at level "+ level + " [" +
                                  catalog.getValue() + "]["+refreshId+"] ");
                
                continue;
            }


            olddataArray = dataArray;
            dataArray = OALDRMSync.getMaskedData(dataArray, catalog);


            int batchSize = DRMSyncPropertyV2.getInstance().getBatchSize();

            int batchNumber = 1;
            int offset = 0;

            while (dataArray.length() - offset > batchSize) {
                System.out.println("current batch " + batchNumber);

                batchNumber++;

                executorService.execute(new ProcessItem(olddataArray, dataArray, offset, offset + batchSize, 
                                                        catalogCode, catalogName, refreshId));
                //                process(olddataArray, dataArray, offset, offset + batch_size, batch_size,catalog_code, catalog_name, leafIndex,
                //                        level);

                offset = offset + batchSize;
            }
            try {
                processItems(olddataArray, dataArray, offset, dataArray.length(),  catalogCode, catalogName,
                             refreshId);
            } catch (IOException | SOAPException e) {
            }
            currentLevel++;

            executorService.shutdown();
            try {
                executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        //  fw.close();
        // saveRefreshId(mostRecentRefresh);


    }

    private boolean processItems(JSONArray olddataArray, JSONArray categories, int startIndex, int endIndex,
                                 String catalogCode, String catalogName,
                                 String refreshId) throws SOAPException, IOException {

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Processing Item Association Started  [" +
                          catalogCode + "]["+refreshId+"]");
        
        JSONArray itemJSONArray = new JSONArray();

        try {
            for (int m = startIndex; m < endIndex; m++) {
                try {
                    JSONObject obj =
                        createItem(categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_CODE),
                                   categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_DESCRIPTION),
                                   categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_NAME), catalogName);
                    itemJSONArray.put(obj);

                } catch (JSONException e) {

                    e.printStackTrace();
                    return false;
                }
            }


            if (itemJSONArray.length() > 0) {
                OrbitMicroServiceInvoker.invokeItemService(itemJSONArray);
            }

            try {

                updateItemAssociation(catalogCode, olddataArray, startIndex, endIndex, "P", refreshId);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            for (int i = 0; i < itemJSONArray.length(); i++) {
                try {
                    if (!OrbitMicroServiceInvoker.itemExist(itemJSONArray.getJSONObject(i)
                                                            .getString(DRMJSONStringUtil.ITEM_NUMBER)))
                        OrbitMicroServiceInvoker.invokeMergeItemService(itemJSONArray.getJSONObject(i));
                    updateItemAssociation(catalogCode, olddataArray, startIndex + i, startIndex + i + 1, "P",
                                          refreshId);
                } catch (JSONException e) {
                    try {
                        updateItemAssociation(catalogCode, olddataArray, startIndex + i, startIndex + i + 1, "E",
                                              refreshId);
                    } catch (JSONException f) {
                    }
                }
            }
        }


        return true;
    }


    private static JSONObject createItem(String itemNumber, String itemDesc, String categoryCode,
                                         String catalogName) throws JSONException {
        JSONObject jobj = new JSONObject();
        jobj.put(DRMJSONStringUtil.ITEM_CLASS, DRMSyncPropertyV2.getInstance().getDefaultItemClass());
        jobj.put(DRMJSONStringUtil.ITEM_ORGANIZATION_CODE, DRMSyncPropertyV2.getInstance().getDefaultItemOrg());
        jobj.put(DRMJSONStringUtil.ITEM_NUMBER, itemNumber);
        jobj.put(DRMJSONStringUtil.ITEM_DESCRIPTION, itemDesc);
        jobj.put(DRMJSONStringUtil.ITEM_PRIMARY_UNIT_OF_MEASUREMENT,
                 DRMSyncPropertyV2.getInstance().getDefaultItemUOM());
        jobj.put(DRMJSONStringUtil.ITEM_STATUS_VALUE, DRMSyncPropertyV2.getInstance().getDefaultItemStatus());
        jobj.put(DRMJSONStringUtil.ITEM_LIFECYCLE_PHASE_VALUE,
                 DRMSyncPropertyV2.getInstance().getDefaultItemLCPValue());
        jobj.put(DRMJSONStringUtil.ITEM_CATEGORY, categoryCode);
        jobj.put(DRMJSONStringUtil.ITEM_CATALOG, catalogName);

        return jobj;

    }

    private void updateItemAssociation(String catalogCode, JSONArray olddataArray, int startIndex, int endIndex,
                                       String flag, String refreshId) throws JSONException {
    
        OALDRMSyncUtil.updateItemAssociation(catalogCode, olddataArray, startIndex, endIndex, null, flag, refreshId);
    }

    class ProcessItem implements Runnable {
        JSONArray olddataArrayC;
        JSONArray dataArrayC;
        int startIndexC;
        int endindexC;
       
        String catalogCodeC;
        String catalogNameC;
        ArrayList<Integer> leafIndexC;
        String levelC;
        String refreshIdC;

        ProcessItem(JSONArray olddataArray, JSONArray dataArray, int startIndex, int endIndex, 
                    String catalogCode, String catalogName, String refreshId) {
            olddataArrayC = olddataArray;
            dataArrayC = dataArray;
            startIndexC = startIndex;
            
            catalogCodeC = catalogCode;
            catalogNameC = catalogName;
            endindexC = endIndex;
            refreshIdC = refreshId;

        }

        @Override
        public void run() {

            try {
                processItems(olddataArrayC, dataArrayC, startIndexC, endindexC, catalogCodeC, catalogNameC,
                             refreshIdC);
            } catch (IOException | SOAPException e) {
            }


        }
    }
}
