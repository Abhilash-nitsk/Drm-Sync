package oal.oracle.apps.scm.drm;

import oal.oracle.apps.scm.drm.exception.DRMCatalogNotFoundException;

import java.sql.Timestamp;

import oal.oracle.apps.scm.drm.exception.DRMDataSanityTestFailedException;
import oal.oracle.apps.scm.drm.exception.DRMPaasServiceException;
import oal.oracle.apps.scm.drm.exception.DRMParentDoesnotExistException;

import java.io.FileNotFoundException;
import java.io.FileWriter;

import java.util.Set;

import java.sql.Connection;
import java.sql.DriverManager;

import java.io.IOException;
import java.io.File;

import java.math.BigDecimal;

import java.util.List;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;

import javax.persistence.EntityManager;

import javax.xml.soap.SOAPException;

import oal.oracle.apps.misegp.drm.OALDRMSyncUtil;

import oal.oracle.apps.scm.drm.orbit.DRMJSONStringUtil;

import oal.oracle.apps.scm.drm.orbit.DRMXMLStringUtil;

import oal.util.logger.*;

import org.json.JSONArray;

import org.json.JSONException;
import org.json.JSONObject;

import oal.oracle.apps.scm.drm.orbit.OrbitMicroServiceInvoker;

import org.json.JSONString;

import java.util.Map;
import java.util.HashSet;
import java.util.HashMap;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.concurrent.TimeUnit;

import oal.oracle.apps.scm.drm.MailNotification;

import javax.mail.MessagingException;

import javax.naming.NamingException;


public class OALDRMSync {


    private String loggerName = OALDRMSync.class.getName();
    private long totalTime;
    private static final String SUCCESS = "Success";
    private static final String ERRORED = "Errored";
    private String result = SUCCESS;
    private long startTimestamp;
    private long completedTimestamp;
    private boolean errorFlag = false;
    private Map<String, Set<String>> erroredCategoriesMap = new HashMap();
    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";


    // private String catalogCode="";
    // private String catalogName="";

    class Processcat implements Runnable {
        JSONArray olddataArrayC;
        JSONArray dataArrayC;
        int startIndexC;
        int endIndexC;

        String catalogCodeC;
        String catalogNameC;
        ArrayList<Integer> leafIndexC;
        String levelC;
        String refreshIdC;

        Processcat(JSONArray olddataArray, JSONArray dataArray, int startIndex, int endIndex, String catalogCode,
                   String catalogName, ArrayList<Integer> leafIndex, String level, String refreshId) {
            olddataArrayC = olddataArray;
            dataArrayC = dataArray;
            startIndexC = startIndex;

            catalogCodeC = catalogCode;
            catalogNameC = catalogName;
            endIndexC = endIndex;
            levelC = level;
            leafIndexC = leafIndex;
            refreshIdC = refreshId;
        }

        @Override
        public void run() {
            try {

                process(olddataArrayC, dataArrayC, startIndexC, endIndexC, catalogCodeC, catalogNameC, leafIndexC,
                        levelC, refreshIdC);

            } catch (DRMParentDoesnotExistException | IOException | JSONException | SOAPException e) {
            }
        }
    }

    public OALDRMSync() {
        super();
    }

    public static void main(String args[]) throws JSONException {

        String newCategoryName = randomAlphaNumeric(10);

        JSONObject obj = new JSONObject();
        obj.put(DRMJSONStringUtil.CATEGORY_CODE, "TEST_LOAD_DNU_AA_5367");
        obj.put(DRMJSONStringUtil.CATEGORY_NAME, "0BBB");
        obj.put(DRMJSONStringUtil.CATEGORY_DESCRIPTION, "DNU1");
        obj.put(DRMJSONStringUtil.CATEGORY_PARENT_CATEGORY_CODE, "TEST_LOAD_DNU_AA_5367");
        // obj.put(DRMJSONStringUtil.CATALOG_CODE, "DNU");
        obj.put(DRMJSONStringUtil.START_DATE, "14-DEC-2017");

        String catalogName = "DNU";
        String[] out = new String[2];
        try {
            OrbitMicroServiceInvoker.invokeMergeCategoryService(obj, catalogName, out);
        } catch (Exception e) {

            String oldcategoryName = obj.getString(DRMJSONStringUtil.CATEGORY_NAME);

            obj.put(DRMJSONStringUtil.CATEGORY_NAME, newCategoryName);

            String[] out1 = new String[2];

            try {

                OrbitMicroServiceInvoker.invokeMergeCategoryService(obj, catalogName, out1);
                OrbitMicroServiceInvoker.invokeUpdateCategoryService(obj.getString(DRMJSONStringUtil.CATEGORY_CODE),
                                                                     oldcategoryName, catalogName);
                obj.put(DRMJSONStringUtil.CATEGORY_NAME, oldcategoryName);

                //  continue;

            } catch (Exception exc) {
                //         OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                //                           DRMSyncPropertyV2.getInstance().getLoggerID(), "Error",
                //                           "Nested Error Found while creating category :" +
                //                           "FND_CMN_OBJECT_NAME_EXISTS"+exc.getMessage()+", "+out[1]);
            }
        }
    }
    //    public static void main(String args[]) {
    //
    ////        OALDRMSync drmsync = new OALDRMSync();
    ////
    ////        try {
    ////            //  drmsync.init("1000", "0BBB", "00", "OAL_TEST_CATEGORY_SYNC");
    ////        } catch (Exception e) {
    ////            e.printStackTrace();
    ////        } finally {
    ////
    ////        }
    //    }

    //    public static void main(String args[]) {
    //        try {
    //            new OALDRMSync().sync(DRMSyncPropertyV2.Catalog.FPH, "1000");
    //        } catch (DRMCatalogNotFoundException | DRMPaasServiceException | DRMParentDoesnotExistException | IOException |
    //                 JSONException | SOAPException e) {
    //
    //        }
    //    }


    public void init(String refreshId, DRMSyncPropertyV2.Catalog catalog) {

        try {


            //  findDelta(refreshId);
            //  loggerName+="["+DRMSyncPropertyV2.getInstance().getCatalogCode(catalog)+"]";
            //

            startTimestamp = System.currentTimeMillis();
            DRMResultPublisher.getInstance()
                .updateRecordStartTimestamp(refreshId, catalog, new Timestamp(startTimestamp));
            sync(catalog, refreshId);
            //  Thread.sleep(30000);

            completedTimestamp = System.currentTimeMillis();

            totalTime = completedTimestamp - startTimestamp;

        } catch (Exception e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "Error" + "[" + catalog.getValue() + "] message:" + e.getMessage());
            e.printStackTrace();

        } finally {
            try {
                // String catalog_code = DRMSyncPropertyV2.getInstance().getCatalogCode(catalog);
                String catalogName = DRMSyncPropertyV2.getInstance().getCatalogName(catalog);
                JSONObject jobj = generateReportV2(catalog.getCode(), refreshId, catalogName, result);


                DRMResultPublisher.getInstance().publishResult(jobj);
                MailNotification.sendNotification("DRM SYNC REPORT", jobj,
                                                  generateDetailedReport(catalog.getCode(), refreshId));

            } catch (MessagingException e) {


                e.printStackTrace();
            } catch (DRMPaasServiceException | IOException | JSONException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException | SQLException e) {
            } catch (NamingException e) {
            }

        }

    }


    //@SuppressWarnings("oracle.jdeveloper.java.nested-assignment")
    public void sync(DRMSyncPropertyV2.Catalog catalog, String refreshId) throws IOException, JSONException,
                                                                                 SOAPException,
                                                                                 DRMCatalogNotFoundException,
                                                                                 DRMPaasServiceException,
                                                                                 DRMParentDoesnotExistException {

        String catalogCode = DRMSyncPropertyV2.getInstance().getCatalogCode(catalog);
        String catalogName = DRMSyncPropertyV2.getInstance().getCatalogName(catalog);

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Initializing DRM Sync.." + "[" + catalog.getValue() + "]");

        if (!catalogExist(catalogName)) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "Unable to find catalog" + "[" + catalog.getValue() + "]");

            throw new DRMCatalogNotFoundException("Unable to find Catalog, Please make sure if catalog exist." + "[" +
                                                  catalog.getValue() + "]");
        }

        JSONArray dataArray;
        JSONArray olddataArray;


        int currentLevel = 1;

        int maxLevel = OALDRMSyncUtil.getMaxLevel(DRMSyncPropertyV2.getInstance().getCatalogCode(catalog), refreshId);
        System.out.println("maxlevel " + maxLevel);
        // maxLevel=3;
        // if data exist in DRM at level x, get the data in dataArray

        while (currentLevel <= maxLevel) {

            ExecutorService executorService = Executors.newFixedThreadPool(10);

            System.out.println("current level " + currentLevel);
            String level = String.valueOf(currentLevel);
            //HashSet<String> errored_cat=new HashSet();
            // erroredCategoriesMap.put(level, errored_cat);
            Set<String> erroredCat = OALDRMSyncUtil.getErroredCategories(catalogCode, currentLevel, refreshId);

            erroredCategoriesMap.put(level, erroredCat);

            dataArray = OALDRMSyncUtil.getCategories(catalogCode, currentLevel, refreshId, false);

            System.out.println("no of data : " + dataArray.length() + " for [" + catalogCode + "] level " + level);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                              "Initializing Category Creation for level " + currentLevel + " [" + catalog.getValue() +
                              "]");


            dataArray = sanityFilter(dataArray, currentLevel);


            System.out.println("no of data after sanity testing : " + dataArray.length() + " for [" + catalogCode +
                               "] level " + level);

            if (dataArray.length() == 0) {
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                                  "No updated record found at level " + level + ", Continuing to next level." + " [" +
                                  catalog.getValue() + "]");
                currentLevel++;
                continue;
            }

            ArrayList<Integer> leafIndex = new ArrayList<>();


            if (DRMSyncPropertyV2.getInstance().createItemLeaf(catalogCode))

                for (int i = 0; i < dataArray.length(); i++) {

                    JSONObject job = dataArray.getJSONObject(i);

                    // adding categories which qualifies for leaf level item creation
                    String isleaf = job.optString(DRMJSONStringUtil.CATEGORY_IS_LEAF);

                    if (isleaf.equalsIgnoreCase("True")) {
                        leafIndex.add(i);
                    }
                }

            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                              "Total number of nodes at level " + currentLevel + "is " + dataArray.length() + " [" +
                              catalog.getValue() + "]");

            olddataArray = dataArray;
            dataArray = getMaskedData(dataArray, catalog);

            // invoking catalog and item ws with bulk categories and items in batch of batch_size

            int batchSize = DRMSyncPropertyV2.getInstance().getBatchSize();

            int batchNumber = 1;
            int offset = 0;
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                              "Invoking catalog and item ws with bulk categories and items in batch of " + batchSize +
                              " [" + catalog.getValue() + "]");

            while (dataArray.length() - offset > batchSize) {
                System.out.println("current batch " + batchNumber);

                batchNumber++;
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                                  "Processing batch " + (batchNumber));
                executorService.execute(new Processcat(olddataArray, dataArray, offset, offset + batchSize, catalogCode,
                                                       catalogName, leafIndex, level, refreshId));
                //                process(olddataArray, dataArray, offset, offset + batch_size, batch_size,catalog_code, catalog_name, leafIndex,
                //                        level);

                offset = offset + batchSize;
            }
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                              "Processing last batch of level " + currentLevel + " [" + catalog.getValue() + "]");
            process(olddataArray, dataArray, offset, dataArray.length(), catalogCode, catalogName, leafIndex, level,
                    refreshId);
            currentLevel++;

            executorService.shutdown();
            try {
                executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "DRM Sync Successful !" + " [" + catalog.getValue() + "]");

        //  fw.close();
        // saveRefreshId(mostRecentRefresh);


    }


    public static File generateDetailedReport(String catalogCode, String refreshId) throws IOException,
                                                                                           DRMPaasServiceException,
                                                                                           JSONException {
        File csvFile = File.createTempFile("Detailed Report", ".csv");


        FileWriter writer = new FileWriter(csvFile);
        int level = OALDRMSyncUtil.getMaxLevel(catalogCode, refreshId);
        // following one Line should be commented
        // level=3;

        String[] elementHeader = new String[] {
            "Catalog Code", "Category Code", "Category Name", "Category Description", "Level", "Status", "Comments",
            "Refresh Id"
        };
        CSVUtils.writeLine(writer, Arrays.asList(elementHeader));
        for (int i = 1; i <= level; i++) {
            JSONArray arr = OALDRMSyncUtil.getCategoriesfromStageTable(catalogCode, i, refreshId);

            String[] elementNames = new String[] {

                DRMJSONStringUtil.CATALOG_CODE, DRMJSONStringUtil.CATEGORY_CODE, DRMJSONStringUtil.CATEGORY_NAME,
                DRMJSONStringUtil.CATEGORY_DESCRIPTION, DRMJSONStringUtil.CATEGORY_LEVEL,
                DRMJSONStringUtil.CATEGORY_PROCESSED_FLAG, DRMJSONStringUtil.COMMENTS, DRMJSONStringUtil.REFRESH_ID


            };
            for (int j = 0; j < arr.length(); j++) {
                List<String> str = new ArrayList<String>();

                //System.out.printf("%d ELEMENTS IN CURRENT OBJECT:\n", elementNames.length);
                for (String elementName : elementNames) {

                    Object value = arr.getJSONObject(j).opt(elementName);
                    if (value != null) {
                        if (elementName.equals("comments")) {
                            String rawMessage = String.valueOf(value);
                            //  String error=rawMessage.substring(0,rawMessage.indexOf("<MESSAGE>"));
                            int a = rawMessage.indexOf("<TEXT>");
                            int b = rawMessage.indexOf("</TEXT>");
                            String reason = rawMessage.substring(a + 6, b);
                            str.add(reason);
                        } else
                            str.add(String.valueOf(value));
                    } else
                        str.add("");
                    // System.out.printf("name=%s, value=%s\n", elementName, value);
                }
                CSVUtils.writeLine(writer, str);
            }

        }
        writer.close();
        return csvFile;
    }

    public JSONObject generateReportV2(String catalogCode, String refreshId, String catalogName,
                                       String result) throws DRMPaasServiceException, IOException, JSONException {

        // FileWriter fw=new FileWriter(DRMSyncProperty.getInstance().getReportFile());
        JSONObject jobj = new JSONObject();

        jobj.put("header", "DRM SYNC REPORT SUMMARY");
        jobj.put("dateTime", new Date().toString());
        jobj.put("catalogCode", catalogCode);
        jobj.put("status", result);
        jobj.put("catalogName", catalogName);

        jobj.put("startTimestamp", startTimestamp);

        jobj.put("completedTimestamp", completedTimestamp);

        jobj.put("totalTime", totalTime);
        jobj.put("refreshId", refreshId);


        int level = OALDRMSyncUtil.getMaxLevel(catalogCode, refreshId);
        // following one Line should be removed
        //level=3;
        jobj.put("maxDepth", String.valueOf(level));
        jobj.put("tableHeader", "Level wise details");

        JSONArray arr = new JSONArray();
        for (int i = 1; i <= level; i++) {
            JSONObject obj = new JSONObject();

            obj.put("level", String.valueOf(i));
            int processed = OALDRMSyncUtil.getCategoryCount(catalogCode, i, "P", refreshId);
            obj.put("processed", String.valueOf(processed));

            int unprocessed = OALDRMSyncUtil.getCategoryCount(catalogCode, i, "U", refreshId);
            obj.put("unprocessed", String.valueOf(unprocessed));

            int errored = OALDRMSyncUtil.getCategoryCount(catalogCode, i, "E", refreshId);
            obj.put("errored", String.valueOf(errored));
            arr.put(obj);

        }

        jobj.put("data", arr);

        if (catalogCode.equalsIgnoreCase(DRMSyncPropertyV2.Catalog
                                                          .CRM
                                                          .getCode())) {

            JSONArray array = new JSONArray();

            for (int i = 1; i <= level; i++) {
                JSONObject obj = new JSONObject();

                obj.put("level", String.valueOf(i));
                int processed = OALDRMSyncUtil.getItemCount(catalogCode, i, "P", refreshId);
                obj.put("processed", String.valueOf(processed));

                int unprocessed = OALDRMSyncUtil.getItemCount(catalogCode, i, "U", refreshId);
                obj.put("unprocessed", String.valueOf(unprocessed));

                int errored = OALDRMSyncUtil.getItemCount(catalogCode, i, "E", refreshId);
                obj.put("errored", String.valueOf(errored));
                array.put(obj);

            }
            jobj.put("itemData", array);
        }

        return jobj;


    }


    //TO Be uncommented once the PL/SQL Procedure works fine


    private void process(JSONArray olddataArray, JSONArray dataArray, int startIndex, int endIndex, String catalogCode,
                         String catalogName, ArrayList<Integer> leafIndex, String level,
                         String refreshId) throws IOException, JSONException, SOAPException,
                                                  DRMParentDoesnotExistException {


        System.out.println("Processing " + (endIndex - startIndex) + " no of items for catalog code " + catalogCode +
                           " and level " + level);
        if (!level.equals("1"))
            if (!checkifparentexist(catalogCode, olddataArray, startIndex, endIndex, refreshId))
                throw new DRMParentDoesnotExistException("Parent Doesnot exist for some categories" + " [" +
                                                         catalogCode + "]");


        if (!processCategoriesAndItems(olddataArray, dataArray, startIndex, endIndex, catalogCode, catalogName,
                                       leafIndex, refreshId)) {
            // fw.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "Error while creating category using bulk creation method");
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                              "Retrying category creation.." + " [" + catalogCode + "]");
            try {

                mergeCategoryAndItem(olddataArray, dataArray, startIndex, endIndex, catalogCode, catalogName, leafIndex,
                                     level, refreshId);

            } catch (IOException | JSONException | SOAPException e) {
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                                  "ERROR after calling merge category" + " [" + catalogCode + "] ERROR:" +
                                  e.getMessage());

                throw e;
            }
        }

    }


    /**
     * Creates bulk category and leaf level item if requested.
     * @param createItems
     * @param categories
     * @param startIndex
     * @param endIndex
     * @param batchSize
     * @param catalogCode
     * @param leafIndex
     * @return
     */

    private boolean processCategoriesAndItems(JSONArray olddataArray, JSONArray categories, int startIndex,
                                              int endIndex, String catalogCode, String catalogName,
                                              ArrayList<Integer> leafIndex, String refreshId) {
        JSONArray sublist = new JSONArray();
        for (int m = startIndex; m < endIndex; m++) {
            try {

                sublist.put(categories.getJSONObject(m));
            } catch (JSONException e) {
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                                  "Failed while creating batches.." + " [" + catalogCode + "]");
                e.printStackTrace();
                return false;
            }
        }
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Invoking catalog Orbit Microserviceservice.." + " [" + catalogCode + "]");
        System.out.println("Invoking catalog Orbit Microserviceservice.." + " [" + catalogCode + "]");
        try {

            if (sublist.length() > 0) {
                OrbitMicroServiceInvoker.invokeCategoryService(sublist, catalogName);
            }
        } catch (Exception e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "Process failed while creating categories." + " [" + catalogCode + "] ERROR:" +
                              e.getMessage());
            e.printStackTrace();
            return false;
        }


        try {
            updateCategories(catalogCode, olddataArray, startIndex, endIndex, "P", refreshId);
        } catch (JSONException e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "updating data in stage table failed.." + " [" + catalogCode + "] ERROR" +
                              e.getMessage());
        }

        // }
        JSONArray itemJSONArray = new JSONArray();

        try {


            for (int j : leafIndex) {
                if (j < startIndex || j >= endIndex)
                    continue;

                JSONObject obj =
                    createItem(categories.getJSONObject(j).getString(DRMJSONStringUtil.CATEGORY_CODE),
                               categories.getJSONObject(j).getString(DRMJSONStringUtil.CATEGORY_DESCRIPTION),
                               categories.getJSONObject(j).getString(DRMJSONStringUtil.CATEGORY_NAME), catalogName);
                itemJSONArray.put(obj);

            }

            if (itemJSONArray.length() > 0) {
                OrbitMicroServiceInvoker.invokeItemService(itemJSONArray);
            }

        } catch (Exception ex) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "Error in Item Creation." + " [" + catalogCode + "] message:" + ex.getMessage());
            ex.printStackTrace();
            return false;
        }

        try {
            if (itemJSONArray.length() > 0)
                updateItemAssociation(catalogCode, olddataArray, startIndex, endIndex, leafIndex, "P", refreshId);

        } catch (JSONException e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "updating data in stage table failed.." + " [" + catalogCode + "] ERROR:" +
                              e.getMessage());
        }
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "updating data in stage table" + " [" + catalogCode + "]");

        return true;

    }


    /**
     * Creates single category and leaf level item if requested.
     * @param createItems
     * @param categories
     * @param startIndex
     * @param endIndex
     * @param batchSize
     * @param catalog_code
     * @param leafIndex
     * @return
     */
    private boolean mergeCategoryAndItem(JSONArray olddataArray, JSONArray categories, int startIndex, int endIndex,
                                         String catalogCode, String catalogName, ArrayList<Integer> leafIndex,
                                         String level, String refreshId) throws JSONException, IOException,
                                                                                SOAPException {


        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Invoking merge category Orbit Microserviceservice.." + " [" + catalogCode + "]");

        for (int m = startIndex; m < endIndex; m++) {

            String[] out = new String[2];
            try {

                OrbitMicroServiceInvoker.invokeMergeCategoryService(categories.getJSONObject(m), catalogName, out);
            } catch (Exception e) {


                if (out[1].contains("FND_CMN_OBJECT_NAME_EXISTS")) {

                    OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                      DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                                      "Error :" + "FND_CMN_OBJECT_NAME_EXISTS");

                    String newCategoryName = randomAlphaNumeric(10);
                    String oldcategoryName = categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_NAME);

                    categories.getJSONObject(m).put(DRMJSONStringUtil.CATEGORY_NAME, newCategoryName);

                    String[] out1 = new String[2];

                    try {

                        OrbitMicroServiceInvoker.invokeMergeCategoryService(categories.getJSONObject(m), catalogName,
                                                                            out1);
                        OrbitMicroServiceInvoker.invokeUpdateCategoryService(categories.getJSONObject(m)
                                                                             .getString(DRMJSONStringUtil.CATEGORY_CODE),
                                                                             oldcategoryName, catalogName);
                        categories.getJSONObject(m).put(DRMJSONStringUtil.CATEGORY_NAME, oldcategoryName);

                        continue;

                    } catch (Exception exc) {
                        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                          DRMSyncPropertyV2.getInstance().getLoggerID(), "Error",
                                          "Nested Error Found while creating category :" +
                                          "FND_CMN_OBJECT_NAME_EXISTS" + exc.getMessage() + ", " + out[1]);
                    }


                }

                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "Error",
                                  "Error while creating :" +
                                  categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_CODE) + " [" +
                                  catalogCode + "] ERROR:" + e.getMessage() + out[1]);

                updateError(catalogCode, olddataArray, m, m + 1, "E", refreshId);
                OALDRMSyncUtil.updateComments(catalogCode,
                                              olddataArray.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_CODE),
                                              out[1], refreshId);
                result = ERRORED;
                erroredCategoriesMap.get(level)
                    .add(olddataArray.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_CODE));
                e.printStackTrace();
                if (!errorFlag)
                    errorFlag = true;
                continue;
                //throw e;
            }
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                              "Processed :" + categories.getJSONObject(m).get(DRMJSONStringUtil.CATEGORY_CODE) + " [" +
                              catalogCode + "]");

            try {
                OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                  DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                                  "updating stage table" + " [" + catalogCode + "]");
                updateCategories(catalogCode, olddataArray, m, m + 1, "P", refreshId);

            } catch (JSONException e) {
                e.printStackTrace();
            }


            /// Item Creation
            JSONObject obj = null;
            if (leafIndex.contains(m)) {

                obj =
                    createItem(categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_CODE),
                               categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_DESCRIPTION),
                               categories.getJSONObject(m).getString(DRMJSONStringUtil.CATEGORY_NAME), catalogName);
                try {
                    if (!OrbitMicroServiceInvoker.itemExist(categories.getJSONObject(m)
                                                            .getString(DRMJSONStringUtil.CATEGORY_CODE)))
                        OrbitMicroServiceInvoker.invokeMergeItemService(obj);
                    OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                      DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                                      "Processed Item :" +
                                      categories.getJSONObject(m).get(DRMJSONStringUtil.CATEGORY_CODE) + " [" +
                                      catalogCode + "]");

                    try {
                        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                                          "updating stage table" + " [" + catalogCode + "]");
                        updateItemAssociation(catalogCode, olddataArray, m, m + 1, leafIndex, "P", refreshId);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } catch (IOException | SOAPException e) {

                    OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                                      DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                                      "Error while Item :" +
                                      categories.getJSONObject(m).get(DRMJSONStringUtil.CATEGORY_CODE) + " [" +
                                      catalogCode + "] ERROR:" + e.getMessage());
                    updateItemAssociation(catalogCode, olddataArray, m, m + 1, leafIndex, "E", refreshId);
                    //  throw e;
                }


            }

        }


        return true;
    }

    public static String randomAlphaNumeric(int count) {
        StringBuilder builder = new StringBuilder();
        while (count-- != 0) {
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return builder.toString();
    }

    private static JSONObject createItem(String itemNumber, String itemDesc, String categoryCode,
                                         String catalogName) throws JSONException {
        JSONObject jobj = new JSONObject();
        jobj.put(DRMJSONStringUtil.ITEM_CLASS, DRMSyncPropertyV2.getInstance().getDefaultItemClass());
        jobj.put(DRMJSONStringUtil.ITEM_ORGANIZATION_CODE, DRMSyncPropertyV2.getInstance().getDefaultItemOrg());
        jobj.put(DRMJSONStringUtil.ITEM_NUMBER, itemNumber);
        jobj.put(DRMJSONStringUtil.ITEM_DESCRIPTION, itemDesc);
        jobj.put(DRMJSONStringUtil.ITEM_PRIMARY_UNIT_OF_MEASUREMENT,
                 DRMSyncPropertyV2.getInstance().getDefaultItemUOM());
        jobj.put(DRMJSONStringUtil.ITEM_STATUS_VALUE, DRMSyncPropertyV2.getInstance().getDefaultItemStatus());
        jobj.put(DRMJSONStringUtil.ITEM_LIFECYCLE_PHASE_VALUE,
                 DRMSyncPropertyV2.getInstance().getDefaultItemLCPValue());
        jobj.put(DRMJSONStringUtil.ITEM_CATEGORY, categoryCode);
        jobj.put(DRMJSONStringUtil.ITEM_CATALOG, catalogName);

        return jobj;

    }


    public static JSONArray getMaskedData(JSONArray dataArray, DRMSyncPropertyV2.Catalog cat) {

        JSONArray newdata = new JSONArray();

        for (int i = 0; i < dataArray.length(); i++) {
            try {

                JSONObject clone = new JSONObject();
                JSONObject job = dataArray.getJSONObject(i);
                Iterator<?> keys = job.keys();

                while (keys.hasNext()) {
                    String key = (String) keys.next();

                    if (key.equalsIgnoreCase(DRMJSONStringUtil.CATEGORY_CODE) |
                        key.equalsIgnoreCase(DRMJSONStringUtil.CATEGORY_PARENT_CATEGORY_CODE) |
                        key.equalsIgnoreCase(DRMJSONStringUtil.CATEGORY_NAME))
                        clone.put(key, DRMSyncPropertyV2.getInstance().getPrependString(cat) + job.getString(key));
                    else
                        clone.put(key, job.get(key));
                }
                newdata.put(clone);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return newdata;
    }


    private static boolean catalogExist(String catalogName) {
        // yet to be implemented
        if (catalogName.isEmpty())
            return false;
        return true;
    }

    private void updateItemAssociation(String catalogCode, JSONArray olddataArray, int startIndex, int endIndex,
                                       ArrayList<Integer> leafIndex, String flag,
                                       String refreshId) throws JSONException {
        OALDRMSyncUtil.updateItemAssociation(catalogCode, olddataArray, startIndex, endIndex, leafIndex, flag,
                                             refreshId);
    }

    private void updateCategories(String catalogCode, JSONArray olddataArray, int startIndex, int endIndex, String flag,
                                  String refreshId) throws JSONException {


        OALDRMSyncUtil.updateCategoriesV2(catalogCode, olddataArray, startIndex, endIndex, flag, refreshId);
        //OALDRMSyncUtil.deleteCategories(newarr,startIndex,endIndex);
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Successfully updated stage table" + " [" + catalogCode + "]");

    }

    private boolean checkifparentexist(String catalogCode, JSONArray arr, int st, int end,
                                       String refreshId) throws JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "checking if parents exist" + " [" + catalogCode + "]");
        return OALDRMSyncUtil.parentExist(catalogCode, arr, st, end, refreshId);
    }

    private void updateError(String catalogCode, JSONArray arr, int a, int b, String flag,
                             String refreshId) throws JSONException {
        OALDRMSyncUtil.updateCategoriesV2(catalogCode, arr, a, b, flag, refreshId);
    }

    private JSONArray sanityFilter(JSONArray arr, int level) throws JSONException {
        if (level == 1)
            return arr;
        JSONArray array = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {

            String x = arr.getJSONObject(i).getString(DRMJSONStringUtil.CATEGORY_PARENT_CATEGORY_CODE);
            if (erroredCategoriesMap.get(String.valueOf(level - 1)).contains(x)) {
                erroredCategoriesMap.get(String.valueOf(level))
                    .add(arr.getJSONObject(i).getString(DRMJSONStringUtil.CATEGORY_CODE));
            } else {
                array.put(arr.getJSONObject(i));
                //  System.out.print("code"+arr.getJSONObject(i).getString(DRMJSONStringUtil.CATEGORY_CODE)+" ");
            }
        }
        return array;
    }
}
