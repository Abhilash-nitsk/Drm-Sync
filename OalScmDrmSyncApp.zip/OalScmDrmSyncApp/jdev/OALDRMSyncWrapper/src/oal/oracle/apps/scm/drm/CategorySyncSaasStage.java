/*
package oal.oracle.apps.scm.drm;

import java.io.IOException;
import java.io.FileWriter;

import java.io.PrintStream;
import java.io.OutputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.soap.SOAPException;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import java.util.Vector;
import java.util.concurrent.TimeUnit;

import oal.oracle.apps.scm.drm.orbit.OrbitMicroServiceInvoker;

// class can be optimized using producer consumer approach
@Deprecated
public class CategorySyncSaasStage {
    
    public static void main(String args[]) throws SQLException, IOException, ClassNotFoundException {
        new CategorySyncSaasStage().sync(1000);
    }
    
    List<String> categories=Collections.synchronizedList(new ArrayList());
    public CategorySyncSaasStage() {
        super();
    }
    String mask(String next) {
    return next="0MFPH_"+next;
    }
    String Unmask(String next) {
        return next.replace("0MFPH_","");
    }    
    void sync(int refresh_id) throws SQLException, IOException, ClassNotFoundException {
        
        PrintStream out = System.out;
        PrintStream in=new PrintStream(new OutputStream() {
            @Override public void write(int b) throws IOException {}
        });
        System.setOut(in);
        
        long ini=System.currentTimeMillis();
        long time=ini;
        Connection dbConnection=getConnection();
        
        ArrayList<String> catalogCodes = new ArrayList();
        catalogCodes.add("0BBB");
        catalogCodes.add("ZBBB");
        catalogCodes.add("0EH1");
        
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        ExecutorService executorService1 = Executors.newFixedThreadPool(10); 
        for(String s:catalogCodes) {
            
        
        ResultSet rs=getResultSet(refresh_id,s,dbConnection);
        
        
        
        String next;
        int u=1000;
        while((next=getNext(rs))!=null )
        {
            if(u++%1000==0)
            {
                synchronized(categories)
                {
                System.setOut(out);
                System.out.println("completed 1k in "+(System.currentTimeMillis()-time));
                time=System.currentTimeMillis();
                System.setOut(in);
                    
                    List<String> consume=new ArrayList();

                    while(categories.size()>0)
                        consume.add(categories.remove(0));
                
                    int i=0;
                    int batch_size = 100;

                    int offset = 0;
                    
                    while (consume.size() - offset > batch_size) {
                    while(consume.size() - offset > batch_size) {
                        executorService1.execute(new updatecat(offset, offset + batch_size, dbConnection, consume, refresh_id, s));
                        offset = offset + batch_size;
                    }
                    executorService1.execute(new updatecat(offset, consume.size(), dbConnection, consume, refresh_id, s));
                    
                    }
                
                categories.notifyAll();
                }
            }
            next=mask(next);
            //System.out.println("finding "+next);
        executorService.execute(new findcat(next));          
        
        }
        
            synchronized(categories)
            {
            System.setOut(out);
            System.out.println("completed 1k in "+(System.currentTimeMillis()-time));
            time=System.currentTimeMillis();
            System.setOut(in);
                
                List<String> consume=new ArrayList();

                while(categories.size()>0)
                    consume.add(categories.remove(0));
            
                int i=0;
                int batch_size = 100;

                int offset = 0;
                
                while (consume.size() - offset > batch_size) {
                while(consume.size() - offset > batch_size) {
                    executorService1.execute(new updatecat(offset, offset + batch_size, dbConnection, consume, refresh_id, s));
                    offset = offset + batch_size;
                }
                executorService1.execute(new updatecat(offset, consume.size(), dbConnection, consume, refresh_id, s));
                
                }
            
            categories.notifyAll();
            }
        
        }
        
        executorService.shutdown();
        executorService1.shutdown();
        
        try {
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            executorService1.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // categories.forEach(System.out::println);
        
        
            dbConnection.close();
            System.setOut(out);
            System.out.print("time: "+(System.currentTimeMillis()-ini));
        
    }
    
    String getNext(ResultSet s) throws SQLException {
    
    synchronized(this) {
        String next;
        if(s.next())
           return s.getString("category_code");
        return null;
    }
        
    }
    
    
    Connection getConnection() throws ClassNotFoundException, SQLException {
                       Class.forName(DRMSyncPropertyV2.getInstance().getDBDriver());
                        
                        return   DriverManager.getConnection(DRMSyncPropertyV2.getInstance().getDBURL(),
                                                       DRMSyncPropertyV2.getInstance().getDBUser(),
                                                       DRMSyncPropertyV2.getInstance().getDBPassword());
                        
                   }
    
    
    ResultSet getResultSet(int refresh_id,String catalogCode, Connection dbConnection) {
        try {
            
            String st="select category_code from oalego_drm_sync_data where refresh_id='"+refresh_id+"' and catalog_code = '"+catalogCode+"'";
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement(st);
            
            ResultSet rs = preparedStatement.executeQuery();
            return rs;
        } catch (Exception e) {
            
            e.printStackTrace();
        
        
        }
        return null;
    }
    
     void update(int refresh_id, Connection dbConnection, List v, int a, int b, String catalog_code) {
        
//        synchronized (v)
//        {
        try {
            StringBuilder sb=new StringBuilder();
           
            for(int i=a+1;i<b;i++) {
                sb.append("'");
                sb.append(v.get(i));
                sb.append("'");
                sb.append(",");
            }
            if(sb.length()==0) {
                return;
            }
            String st="update oalego_drm_sync_data set processed_flag = 'X' where refresh_id='"+refresh_id+"' " +
                "and catalog_code = '"+catalog_code+"' and category_code in (" +sb.substring(0, sb.length()-1).toString()+")";
            
            System.out.println(st);
            PreparedStatement preparedStatement =
            dbConnection.prepareStatement(st);
            
            preparedStatement.executeUpdate();
            preparedStatement.close();
           
        } catch (Exception e) {
            
            e.printStackTrace();
        
        
        }
        //}
       
    }
    
    class updateThread implements Runnable {

        @Override
        public void run() {
            // TODO Implement this method
        }
    }
    
    class updatecat implements Runnable {
        int a;
        int b;
        Connection dbConnection;
        int refresh_id;
        String catalog_code;
        List v;
        updatecat(int x,int y, Connection con,List arr,int refid,String catalogCode) {
            a=x;
            b=y;
            dbConnection=con;
            refresh_id=refid;
            v=arr;
            catalog_code=catalogCode;
        }
        @Override
        public void run() {
           update(refresh_id, dbConnection, v, a, b, catalog_code);
           
        }

        
    }
    
    
    
    class findcat implements Runnable {
    
    String catCode="";
    
    findcat(String cat) {
        catCode=cat;
       
    }
        @Override
        public void run() {
            try {
                if (OrbitMicroServiceInvoker.categoryExist(catCode)) {
                    //System.out.println("Adding to list "+catCode);
                    synchronized(categories)
                    {
                    categories.add(Unmask(catCode));
                    categories.notifyAll();
                    }
                }
                    
            } catch (IOException | SOAPException e) {
            }
        }
    }
}
*/