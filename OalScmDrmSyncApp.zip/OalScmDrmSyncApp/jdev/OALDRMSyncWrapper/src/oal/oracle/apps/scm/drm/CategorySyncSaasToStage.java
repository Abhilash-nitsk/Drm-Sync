package oal.oracle.apps.scm.drm;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.List;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.List;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import javax.xml.soap.SOAPException;

import oal.oracle.apps.scm.drm.orbit.OrbitMicroServiceInvoker;

import oracle.ldap.util.thread.WorkerThread;

// partially implemented class as extension of CategorySyncSaasStage using producer consumer approach
public class CategorySyncSaasToStage {

    private String loggerName = CategorySyncSaasToStage.class.getName();
    private final List<String> synchronizedList = Collections.synchronizedList(new ArrayList<String>());
    private long ini = System.currentTimeMillis();
    private Connection dbConnection;
    private int refreshId;
    private boolean producerFinished = false;
    //private boolean lastReached = false;
    private int totalItemConsumed = 0;
    private int totalItemProduced = 0;
    private int size = 10000;
    private ExecutorService updateExecutorService = Executors.newFixedThreadPool(10);

    public static void main(String args[]) {
        try {
            new CategorySyncSaasToStage().sync(1130);
        } catch (ClassNotFoundException | SQLException e) {
        } catch (NamingException e) {
        }
    }


    public void sync(int refreshIid) throws ClassNotFoundException, SQLException, NamingException {
        this.refreshId = refreshIid;

        
        dbConnection = getConnection();

        try
        {

        ExecutorService executorService = Executors.newFixedThreadPool(20);
        List<Future<?>> futures = new ArrayList<Future<?>>();

        ExecutorService executorService1 = Executors.newFixedThreadPool(1);


        //   for(String s:catalogCodes) {
        for (DRMSyncPropertyV2.Catalog cat : DRMSyncPropertyV2.Catalog.values()) {

            String s = cat.getCode();
            totalItemConsumed = 0;
            totalItemProduced = 0;
            producerFinished = false;

            ResultSet r = getResultSet(refreshIid, s, dbConnection);

            Runnable worker1 = new Consumer( synchronizedList, s);

            Future<?> fConsumer = executorService1.submit(worker1);

            for (int i = 0; i < 20; i++) {

                Runnable worker = new Producer(size, synchronizedList, r, cat);
                Future<?> f = executorService.submit(worker);
                futures.add(f);
            }

            System.out.println("futures added");
            for (Future<?> future : futures)
                try {
                    future.get();
                } catch (ExecutionException | InterruptedException e) {
                }

            System.out.println("producer finished job " + totalItemProduced + " " + totalItemConsumed + " " + synchronizedList.size());
            synchronized (synchronizedList) {
                producerFinished = true;
                synchronizedList.notifyAll();
            }

            try {
                fConsumer.get();
            } catch (ExecutionException | InterruptedException e) {
            }

            System.out.println("consumer finished job ");
        }
        executorService.shutdown();
        executorService1.shutdown();
        updateExecutorService.shutdown();

        try {
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            executorService1.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
            updateExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        }finally
        {
        dbConnection.close();
        }

    }

    Connection getConnection() throws ClassNotFoundException, SQLException, NamingException {
       return ConnectionUtil.getNewConnection();
    }


    ResultSet getResultSet(int refreshId, String catalogCode, Connection dbConnection) {
        try {

            String st =
                "select category_code from oalego_drm_sync_data where refresh_id='" + refreshId +
                "' and catalog_code = '" + catalogCode + "'";
            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);

            ResultSet rs = preparedStatement.executeQuery();
            return rs;
        } catch (Exception e) {

            e.printStackTrace();


        }
        return null;
    }


    class Consumer implements Runnable {

       
        List<String> v;
        String CatalogCode;

        Consumer( List v, String catalogCode) {
           
            this.v = v;
            this.CatalogCode = catalogCode;
            System.out.println("New Consumer Created !" + totalItemProduced + " " + totalItemConsumed + " " +
                               producerFinished);
        }

        @Override
        public void run() {
            try {
                while (true) {

                    if (totalItemProduced == totalItemConsumed && producerFinished) {
                        System.out.println("Consumer Halted !" + totalItemProduced + " " + totalItemConsumed + " " +
                                           producerFinished);
                        break;

                    }
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                    }
                    consume( v, CatalogCode);
                }
            } catch (IOException | SOAPException e) {
            }
        }
    }

    class Producer implements Runnable {

        int size;
        List<String> v;
        ResultSet rs;
        DRMSyncPropertyV2.Catalog cat;

        Producer(int size, List v, ResultSet rs, DRMSyncPropertyV2.Catalog cat) {
            this.size = size;
            this.v = v;
            this.rs = rs;
            this.cat = cat;
        }

        @Override
        public void run() {

            String next;

            try {
                while ((next = getNext(rs)) != null) {

                    next = mask(next, cat);
                    try {
                        produce(next, size, cat);
                    } catch (IOException | SOAPException e) {
                    }
                }

            } catch (SQLException e) {
            }
        }

        String getNext(ResultSet rs) throws SQLException {

            synchronized (rs) {
                String next = null;
                if (rs.next())
                    next = rs.getString("category_code");
                rs.notifyAll();
                return next;


            }

        }

    }

    private void produce(String next, int size, DRMSyncPropertyV2.Catalog cat) throws SOAPException, IOException {

        boolean b = OrbitMicroServiceInvoker.categoryExist(next);
        if (!b) {
            //  System.out.println(next+ " not found");
            return;
        }

        synchronized (synchronizedList) {


            while (synchronizedList.size() == size)
                try {
                    synchronizedList.wait();
                } catch (InterruptedException e) {
                }


            //System.out.println("producing");
            synchronizedList.add(unMask(next, cat));
            totalItemProduced++;
            synchronizedList.notifyAll();
            //System.out.println("Adding to list "+catCode);

        }
    }

    String mask(String next, DRMSyncPropertyV2.Catalog cat) {

        return DRMSyncPropertyV2.getInstance().getPrependString(cat) + next;

    }

    String unMask(String next, DRMSyncPropertyV2.Catalog cat) {
        return next.replace(DRMSyncPropertyV2.getInstance().getPrependString(cat), "");

    }

    private int consume(List<String> v, String catalogCode) throws SOAPException, IOException {
        synchronized (v) {

            while (v.size() == 0 && !producerFinished)
            //                if(producer_finished) {
            //                   return 0;

            // }
            {
                try {
                    System.out.println("Consumer Waiting !");
                    v.wait();
                } catch (InterruptedException e) {
                }
            }
            ArrayList<String> arr = new ArrayList();

            System.out.println(" size of array before removal " + v.size() + " processed by " +
                               Thread.currentThread().getName());

            int z = v.size();

            if (z == 0 && producerFinished) {
                v.notifyAll();
                return 0;
            }

            for (int i = 0; i < z && i < 500; i++) {
                arr.add(v.remove(0));
            }
            System.out.println(" size of array after removal " + v.size() + " processed by " +
                               Thread.currentThread().getName());
            //System.out.println("Consuming " + arr.size() + " items");
            totalItemConsumed += arr.size();
            // if(total_item_consumed>1000)
            System.out.println("Consumed " + totalItemConsumed + " items till now, Total Time:  " +
                               ((System.currentTimeMillis() - ini) / 1000) + " sec");
            updateExecutorService.execute(new UpdateCat(arr, catalogCode));

            //  v.remove(arg0)
            v.notifyAll();
            //System.out.println("Adding to list "+catCode);
            return arr.size();
        }
    }

    class UpdateCat implements Runnable {
        int a;
        int b;
        String catalog_code;
        List v;

        UpdateCat(List arr, String catalogCode) {

            v = arr;
            catalog_code = catalogCode;
        }

        @Override
        public void run() {
            update(refreshId, dbConnection, v, catalog_code);
        }


    }

    void update(int refreshId, Connection dbConnection, List v, String catalogCode) {

        //        synchronized (v)
        //        {
        try {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < v.size(); i++) {
                sb.append("'");
                sb.append(v.get(i));
                sb.append("'");
                sb.append(",");
            }
            if (sb.length() == 0) {
                return;
            }

            String st =
                "update oalego_drm_sync_data set processed_flag = 'P' where refresh_id='" + refreshId + "' " +
                "and catalog_code = '" + catalogCode + "' and category_code in (" +
                sb.substring(0, sb.length() - 1).toString() + ")";

            // System.out.println(st);
            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);

            preparedStatement.executeUpdate();
            preparedStatement.close();

        } catch (Exception e) {

            e.printStackTrace();


        }
        //}

    }

}


