package oal.oracle.apps.scm.drm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.naming.NamingException;

import oal.util.logger.OalLogger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DRMResultPublisher {
    
    private String loggerName = DRMResultPublisher.class.getName();
    private static Object lock = new Object();
    private volatile static DRMResultPublisher publisher = null;
    private Connection dbConnection;
    private DRMResultPublisher() throws NamingException, SQLException {
        super();
       
    }
    

    public static DRMResultPublisher getInstance() throws ClassNotFoundException, SQLException, NamingException {
        if (publisher == null) {
            synchronized (lock) {
                if (publisher == null)
                {
                try {
                    publisher = new DRMResultPublisher();
                } catch (NamingException | SQLException e) {
                    
                  //  publisher=null;
                    
                    throw e;
                }
                
                }
            }
        }
        return publisher;
    }

    public Connection getConnection() throws SQLException, NamingException {
        if(dbConnection==null || dbConnection.isClosed())
            synchronized(DRMResultPublisher.class)
            {
                if(dbConnection==null || dbConnection.isClosed())
                    dbConnection=ConnectionUtil.getNewConnection();
            }
        
        return  dbConnection;
        
    }
    public void closeConnection() throws SQLException {
        dbConnection.close();
    }

    public void publishResult(JSONObject message) throws JSONException {

        
        String catalogCode = message.getString("catalogCode");
        String status = message.getString("status");
       
        String maxDepth = message.getString("maxDepth");
        

        String refreshId = message.getString("refreshId");
        long startTime = message.getLong("startTimestamp");
        long endTime = message.getLong("completedTimestamp");
        

        JSONArray arr = message.getJSONArray("data");
        int processed = 0, unprocessed = 0, errored = 0;
        for (int i = 0; i < arr.length(); i++) {

            processed += Integer.valueOf(arr.getJSONObject(i).getString("processed"));
            unprocessed += Integer.valueOf(arr.getJSONObject(i).getString("unprocessed"));
            errored += Integer.valueOf(arr.getJSONObject(i).getString("errored"));
        }

        if (endTime != 0) {
            updateRecordOnCompletion(refreshId, catalogCode, new Timestamp(startTime), new Timestamp(endTime), errored,
                                     processed, unprocessed, maxDepth, status);
        } else {
            updateRecordAsFailure(refreshId, new Timestamp(startTime), catalogCode, errored, processed, unprocessed,
                                  maxDepth, "Failed");
        }
    }

    public synchronized void updateRecordOnCompletion(String refreshId, String catCode, Timestamp starttimestamp,
                                                      Timestamp completedtimestamp, int erroredcat, int processedcat,
                                                      int unprocessedcat, String maxdepth, String status) {
        
        
        
        try {
            Connection dbConnection=getConnection();
            String query =
                "update oalego_drm_sync_record set start_time_stamp= ?, completed_time_stamp = ? ,errored_cat=" +
                erroredcat + ", processed_cat=" + processedcat + ", unprocessed_cat=" + unprocessedcat +
                ", max_depth = " + maxdepth + " , status ='" + status + "' where refresh_id='" + refreshId +
                "' and catalog_code='" + catCode + "'";
            System.err.println(query);
            PreparedStatement preparedStatement = dbConnection.prepareStatement(query);


            preparedStatement.setTimestamp(1, starttimestamp);
            preparedStatement.setTimestamp(2, completedtimestamp);
            preparedStatement.executeUpdate();
            preparedStatement.close();


            //dbConnection.setAutoCommit(false);
            
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "updated completion time at " + completedtimestamp.toString() +
                                           " for record with refid " + refreshId + " and catalog Code" + catCode);
            
            System.out.println("updated completion time at " + completedtimestamp.toString() +
                               " for record with refid " + refreshId + " and catalog Code" + catCode);
        } catch (Exception e) {

            e.printStackTrace();


        }
    }

    public synchronized void updateRecordAsFailure(String refreshId, Timestamp starttimestamp, String catCode,
                                                   int erroredCat, int processedCat, int unprocessedCat,
                                                   String maxDepth, String status) {
        try {
            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement("update oalego_drm_sync_record set start_time_stamp=? , errored_cat=" +
                                              erroredCat + ", processed_cat=" + processedCat + ", unprocessed_cat=" +
                                              unprocessedCat + ", max_depth = " + maxDepth + " , status =" + status +
                                              " where refresh_id='" + refreshId + "' and catalog_code='" + catCode +
                                              "'");
            preparedStatement.setTimestamp(1, starttimestamp);
            preparedStatement.executeUpdate();
            preparedStatement.close();


            //dbConnection.setAutoCommit(false);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
           "updated failure for record with refid " + refreshId + " and catalog Code" + catCode);
            System.out.println("updated failure for record with refid " + refreshId + " and catalog Code" + catCode);
        } catch (Exception e) {

            e.printStackTrace();


        }

    }

    public synchronized void updateRecordStartTimestamp(String refreshId, DRMSyncPropertyV2.Catalog cat,
                                                        Timestamp startTimestamp) {
        try {
            
            Connection dbConnection=getConnection();
           
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement("update oalego_drm_sync_record set start_time_stamp = ? where refresh_id='" +
                                              refreshId + "' and catalog_code='" + cat.getCode() + "'");
            preparedStatement.setTimestamp(1, startTimestamp);
            preparedStatement.executeUpdate();
            preparedStatement.close();


            //dbConnection.setAutoCommit(false);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "updated start timestamp to " + startTimestamp.toString() + " for record with refid " +
                                           refreshId + " and catalog Code" + cat.getCode());
            System.out.println("updated start timestamp to " + startTimestamp.toString() + " for record with refid " +
                               refreshId + " and catalog Code" + cat.getCode());
        } catch (Exception e) {

            e.printStackTrace();


        }
    }

    public synchronized void addToRecord(String newRefreshId, Timestamp timestamp) {
        try {
            Connection dbConnection=getConnection();
            for (DRMSyncPropertyV2.Catalog cat : DRMSyncPropertyV2.Catalog.values()) {
                String catalogCode = cat.getCode();
                String catalogName = cat.getValue();
                String query =
                    "insert into oalego_drm_sync_record (refresh_id,catalog_code,catalog_name,notified_time_stamp) values ('" +
                    newRefreshId + "','" + catalogCode + "','" + catalogName + "',?)";
                System.err.println(query);
                PreparedStatement preparedStatement = dbConnection.prepareStatement(query);
                preparedStatement.setTimestamp(1, timestamp);

                preparedStatement.executeUpdate();
                preparedStatement.close();
            }
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "New record added with refreshid " + newRefreshId + " and timestamp " + timestamp);
            //dbConnection.setAutoCommit(false);
            System.out.println("New record added with refreshid " + newRefreshId + " and timestamp " + timestamp);
        } catch (Exception e) {

            e.printStackTrace();


        }
    }

    public synchronized void removefromQueue(String newRefreshId) {
        try {
            Connection dbConnection=getConnection();
            String st = "delete from oalego_drm_sync_queue where refresh_id='" + newRefreshId + "'";
            System.err.println(st);
            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);

            preparedStatement.executeUpdate();
            preparedStatement.close();
            //dbConnection.setAutoCommit(false);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "\n Record with refreshid " + newRefreshId + " deleted from queue.");
            System.out.println("\n Record with refreshid " + newRefreshId + " deleted from queue.");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public synchronized void findDelta(String refreshId) {

        try {
            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement(DRMSyncPropertyV2.getInstance().getDBProcedure());
            preparedStatement.setObject(1, Integer.parseInt(refreshId));
            preparedStatement.execute();
            preparedStatement.close();
            //dbConnection.setAutoCommit(false);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "Delta finding completed");
            System.out.println("\n Delta finding completed");
        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public synchronized int getNextINQueue(int refreshId) {
        int ref = -1;

        try {
            Connection dbConnection=getConnection();
            String st = "select refresh_id from oalego_drm_sync_queue where refresh_id=" + (refreshId + 10);
            //"and queue_no = (\n" +
            //"select min(queue_no) from oalego_drm_sync_queue) ";
            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);

            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                ref = rs.getInt("refresh_id");
            }
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "Get next called successfully. Next-" + ref);
            //dbConnection.setAutoCommit(false);
            // System.out.println("finding next in queue");
        } catch (Exception e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
            "Error in calling getNext Error:" + e.getMessage());
            e.printStackTrace();


        }
        return ref;
    }

    public synchronized void insertInQueue(int refreshid, String status) {


        try {
            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement("insert into oalscm.oalego_drm_sync_queue (refresh_id,status) values (?,?)");
            preparedStatement.setObject(1, refreshid);
            preparedStatement.setObject(2, status);
            preparedStatement.execute();
            preparedStatement.close();
            //dbConnection.setAutoCommit(false);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "New request added in queue with refreshid " + refreshid);
            System.out.println("New request added in queue with refreshid " + refreshid);
        } catch (Exception e) {

            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
            "Exception while inserting data in queue " + refreshid+" Error:"+e.getMessage());
            e.printStackTrace();
            


        }

    }

    public synchronized void updateQueue(int refreshid, String status) {


        try {

            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement("update oalscm.oalego_drm_sync_queue set status='" + status +
                                              "' where refresh_id='" + refreshid + "'");

            preparedStatement.executeUpdate();
            preparedStatement.close();
            //dbConnection.setAutoCommit(false);
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "status of record in queue updated: refid " + refreshid + " status " + status);
            System.out.println("status of record in queue updated: refid " + refreshid + " status " + status);
        } catch (Exception e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "Error in updating record in queue : refid " + refreshid + " status " + status+" Error:"+e.getMessage());
            e.printStackTrace();


        }
    }
}
