package oal.oracle.apps.scm.drm;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;
import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import oal.util.logger.OalLogger;

public class DRMDataSync {
    public DRMDataSync() {
        super();
    }
    private static Lock lock = new ReentrantLock();
    private static Object lock1 = new Object();
    private static long lastInvokedTimeStamp = 0;
    private static List<String> refreshids = new ArrayList();
    private String loggerName = DRMDataSync.class.getName();


    public static void main(String args[]) throws SQLException, NamingException, InterruptedException {
        //new DRMDataSync().sync();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new DRMDataSync().sync();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, "1");
//        Thread t1 = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    new DRMDataSync().sync();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }, "2");

        t.start();

    }
    //static Object lock = new Object();
    

    public void sync() throws SQLException, NamingException, Exception {
        
        

        if (System.currentTimeMillis() - lastInvokedTimeStamp < 10000) {
            return;
        }
        if (lock.tryLock()) {
            
            OalLogger.sendLog("SCM-DRM-SYNC", loggerName,
                              "SCM-DRM-SYNC", "info",
                              "Initializing sync ");

            try {
                System.out.println("Invoking sync at time:" + getCurrentTimeStamp() + " by " +
                                   Thread.currentThread().getName());

                lastInvokedTimeStamp = System.currentTimeMillis();

                // new refresh id generation
                String newRefreshId = prepare();

                // old data sync
                //   new CategorySyncSaasToStage().sync(Integer.parseInt(newRefreshId)-10);

                if (newRefreshId == null)
                    throw new Exception();

                // catalog sync
                process(newRefreshId);

            } finally {
                System.out.println("All Finished");
                System.out.println("closing all connections");
                
                ConnectionUtil.closeAllConnections();
                    
                lock.unlock();
            }
        } else {
            // Someone else had the lock, abort
            prepare();
            System.out.println("System locked, previous sync running.");
            System.out.println("Your request has been recorded and will be processed shortly !");

        }

    }

    private String prepare() throws InterruptedException, SQLException, NamingException, ClassNotFoundException {
        String newRefreshId = "";
        synchronized (lock1) {

            OalLogger.sendLog("SCM-DRM-SYNC", loggerName,
                              "SCM-DRM-SYNC", "info",
                              " preparing to generate refresh id ");
            System.out.println("Lock1 Acquired at:" + getCurrentTimeStamp() + " with HCode " + lock.hashCode() + " by" +
                               Thread.currentThread().getName());

            DRMSyncPropertyV2.init();
            
            Timestamp dateTime = getCurrentTimeStamp();
            drmViewUpdatedNotification(dateTime.toString());

            newRefreshId = generateNewRefreshId();

            DRMResultPublisher.getInstance().insertInQueue(Integer.parseInt(newRefreshId), "pending");

            //refreshids.add(newRefreshId);
            System.out.println(Thread.currentThread().getName() + " generated new refreshid " + newRefreshId);
            updatelastRefreshId(newRefreshId);
            System.out.println(Thread.currentThread().getName() + " updated new refreshid " + newRefreshId);
            updatelastRefreshTimeStamp(dateTime.toString());
            DRMResultPublisher.getInstance().addToRecord(newRefreshId, dateTime);

            //  updateQueue(Integer.parseInt(newRefreshId), "prepared");
            lock1.notifyAll();
            return newRefreshId;
        }

    }


    public void process(String newRefreshId) throws ClassNotFoundException, SQLException, NamingException {


        System.out.println("Processing " + newRefreshId);

        //Thread.sleep(30000);
        DRMResultPublisher.getInstance().updateQueue(Integer.parseInt(newRefreshId), "processing");
        try {

            seedDataToStageTable(newRefreshId);
            int refId = Integer.parseInt(newRefreshId);
            DRMResultPublisher.getInstance().updateQueue(refId, "started");
            updateCurrentRefreshId(newRefreshId);
            seedDeltaTable(newRefreshId);
            startSyncforAllCatalogs(newRefreshId);

        } catch (NamingException | SQLException e)

        {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            DRMResultPublisher.getInstance().removefromQueue(newRefreshId);
        }

        //
        //
        //            System.out.println("lock released at:" + getCurrentTimeStamp() + " by " + Thread.currentThread().getName());


        int refId = DRMResultPublisher.getInstance().getNextINQueue(Integer.parseInt(newRefreshId));
        if (refId != -1) {
            process(String.valueOf(refId));
        }
    }

    private static Timestamp getCurrentTimeStamp() {
        return (new Timestamp(System.currentTimeMillis()));
    }

    private void drmViewUpdatedNotification(String dateTime) {

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Sending DRMView Update Notification..");


        String message = "DRM VIEW HAS BEEN REFRESHED AT " + dateTime;
        MailNotification.sendSimpleMail("OAL-MDM-DRMSYNC@oracle.com", new String[] { "vikas.vi.yadav@oracle.com" },
                                        "DRM View Updated", message);
    }


    private void updateCurrentRefreshId(String refreshid) throws SQLException, NamingException {
        DRMSyncPropertyV2.getInstance().updateCurrentRefreshId(refreshid);

    }

    private String generateNewRefreshId() throws SQLException, NamingException {


       // DRMSyncPropertyV2.init();
        int refreshid = Integer.parseInt(DRMSyncPropertyV2.getInstance().getLastRefreshId()) + 10;

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Generated new refresh id " + refreshid);

        return String.valueOf(refreshid);
    }

    private void seedDataToStageTable(String newRefreshId) throws ClassNotFoundException, SQLException,
                                                                  NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Copying data from DRMView to paas stage table");
        ////
        DRMResultPublisher.getInstance().updateQueue(Integer.parseInt(newRefreshId), "seeding");

        Connection dbConnection =null;
        try
        {
        dbConnection = ConnectionUtil.getNewConnection();
        PreparedStatement preparedStatement =
            dbConnection.prepareStatement(DRMSyncPropertyV2.getInstance().getStageTableSeedingProcedure());
        preparedStatement.setObject(1, Integer.parseInt(newRefreshId));
        preparedStatement.execute();

        }finally
        {
            if(dbConnection!=null)
                dbConnection.close();
        }
        //dbConnection.setAutoCommit(false);
        System.out.println("\n Datasource Fetched");

        ///


        System.out.println(Thread.currentThread().getName() + " copying data " + newRefreshId);
        //        try {
        //            Thread.sleep(60000);
        //        } catch (InterruptedException e) {
        //        }

        System.out.println(Thread.currentThread().getName() + " copying data finished " + newRefreshId);
        DRMResultPublisher.getInstance().updateQueue(Integer.parseInt(newRefreshId), "seeded");
    }

    private synchronized void startSyncforAllCatalogs(String newRefreshId) {

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Starting sync for catalogs.");

        ExecutorService executorService = Executors.newFixedThreadPool(DRMSyncPropertyV2.Catalog
                                                                                        .values()
                                                                                        .length);
        // List<Thread> list=new ArrayList();

        for (DRMSyncPropertyV2.Catalog cat : DRMSyncPropertyV2.Catalog.values()) {

            DrmSyncWrapper wrapper = new DrmSyncWrapper(newRefreshId, cat);
            executorService.execute(wrapper);
            //            Thread thread = new Thread(wrapper);
            //            list.add(thread);
            //            thread.start();

        }
        executorService.shutdown();
        try {
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //        while(list.get(0).isAlive() || list.get(1).isAlive() || list.get(2).isAlive()) {
        //            try {
        //                Thread.sleep(10000);
        //            } catch (InterruptedException e) {
        //                e.printStackTrace();
        //            }
        //        }
        System.out.println("Finished");

        //Thread t1=new Thread()
    }


    private void updatelastRefreshId(String newRefreshId) throws SQLException, NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Updating last refreshed id");

        DRMSyncPropertyV2.getInstance().updatelastRefreshId(newRefreshId);
    }

    private void updatelastRefreshTimeStamp(String timestamp) throws SQLException, NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Updating last refreshed timestamp");

        DRMSyncPropertyV2.getInstance().updatelastRefreshTimeStamp(timestamp);
    }

    private void seedDeltaTable(String newRefreshId) throws ClassNotFoundException, SQLException, NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Populating Delta Table..");

        DRMResultPublisher.getInstance().findDelta(newRefreshId);

    }


    

}
