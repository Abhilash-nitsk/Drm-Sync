package oal.oracle.apps.misegp.drm;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;

import oal.oracle.apps.scm.drm.exception.DRMPaasServiceException;

import java.util.ArrayList;
import java.util.List;

import oal.util.logger.*;

import java.util.Set;
import java.util.HashSet;

import javax.ws.rs.client.Client;

import javax.ws.rs.client.ClientBuilder;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.ws.rs.core.UriBuilder;

//import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncData;

import org.json.JSONArray;
import org.json.JSONObject;

import org.json.JSONException;

public class OALDRMSyncUtil {
    private static String loggerName = OALDRMSyncUtil.class.getName();
    //private static String currentRefreshId="";
    private static final String GET_CATEGORY_COUNT_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getCategoryCount";
    private static final String GET_ITEM_COUNT_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getItemCount";

    private static final String GET_MAX_LEVEL_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getMaxLevel";
    private static final String GET_CATEGORIES_STAGE_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getCategoryCatalog";
    private static final String GET_CHANGED_CATEGORIES_DELTA_SERVICE_URL="/OALSCMDRMSyncServices/service/categoryChange/getChangedCategories";
    private static final String UPDATE_PROCESSED_FLAG_SERVICE_URL="/OALSCMDRMSyncServices/service/category/updateProcessedFlag";
    private static final String UPDATE_COMMENTS_SERVICE_URL=  "/OALSCMDRMSyncServices/service/category/updateComments";
    private static final String UPDATE_ITEM_PROCESSED_FLAG_SERVICE_URL= "/OALSCMDRMSyncServices/service/category/updateItemProcessedFlag";
    private static final String GET_NO_OF_PROCESSED_CAT_SERVICE_URL=  "/OALSCMDRMSyncServices/service/category/getNoOfProcessedCatgories";
    private static final String DELETE_PROCESSED_CATEGORY_SERVICE_URL=  "/OALSCMDRMSyncServices/service/categoryChange/deleteProcessed";

    
    public OALDRMSyncUtil() {
        super();
    }

public static String getURL(String url,String catalogCode,int level,String refreshId,String processedFlag,
                            String itemAssociation,int limit,int offset,boolean leafFlag,String categoryCode) {
    
    UriBuilder uri = UriBuilder.fromUri(url);
    if(catalogCode!=null)
        uri.queryParam("catalogCode", catalogCode);
    if(level>0)
        uri.queryParam("levl", level);
    if(refreshId!=null)
        uri.queryParam("refreshId", refreshId);
    if(processedFlag!=null)
        uri.queryParam("processedFlag", processedFlag);
    if(itemAssociation!=null)
        uri.queryParam("itemAssociation", itemAssociation);
    if(offset>=0)
        uri.queryParam("offset", offset);
    if(limit>=0)
        uri.queryParam("limit", limit);
    if(leafFlag)
        uri.queryParam("isLeaf", "True");
    if(categoryCode!=null)
        uri.queryParam("categoryCode", categoryCode);
    
    return uri.toString();
   
}


    
public static String getResponse(String itemsUrlWithParams) throws DRMPaasServiceException {
    Client client = ClientBuilder.newClient();
    WebTarget target = client.target(itemsUrlWithParams);
    Response clientResponse = target.request().get();
    String itemsJson = null;
    if (clientResponse.getStatus() != 200) {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "url:[" + itemsUrlWithParams + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                          "Service Failed with response code: " + clientResponse.getStatus());
        System.out.println("Service Failed");
        throw new DRMPaasServiceException("Return Code" + clientResponse.getStatus());

    } else {
        itemsJson = clientResponse.readEntity(String.class);

    }
    return itemsJson;
}
 public static void main(String args[]) throws DRMPaasServiceException, JSONException {
    // System.out.println(OALDRMSyncUtil.getCount("0BBB",4,"P", "1000"));
     JSONObject obj=new JSONObject();
     obj.put("parentCategoryCode", "ZBBB");
     JSONArray arr=new JSONArray();
     arr.put(obj);
    // System.out.println(OALDRMSyncUtil.parentExistV("ZBBB",arr,0,1, "1000"));
     System.out.println(OALDRMSyncUtil.parentExist("ZBBB",arr,0,1, "1000"));
 }
    public static String invokeUpdatePost(String itemsUrlWithParams,String payload) {
        System.out.println(payload);
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(itemsUrlWithParams);
        String clientResponse = null;
        clientResponse = target.request(MediaType.TEXT_PLAIN)
                               .accept(MediaType.TEXT_PLAIN)
                               .post(Entity.text(payload), String.class);
        System.out.println("updated processed flag for " + payload + " with response " + clientResponse +
                           " URL:  " + itemsUrlWithParams);
        return clientResponse;
    }
    public static String invokeUpdatePut(String itemsUrlWithParams,String payload) {
        System.out.println(payload);
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(itemsUrlWithParams);
        String clientResponse = null;
        clientResponse = target.request(MediaType.TEXT_PLAIN)
                               .accept(MediaType.TEXT_PLAIN)
                               .put(Entity.text(payload), String.class);
        System.out.println("updated processed flag for " + payload + " with response " + clientResponse +
                           " URL:  " + itemsUrlWithParams);
        return clientResponse;
    }
    
    public static int getCategoryCount(String catalogCode, int level, String processedFlag,String refreshId) throws DRMPaasServiceException {

        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        //url += "/OALSCMDRMSyncServices/service/category/getCategoryCount";
        url+=GET_CATEGORY_COUNT_SERVICE_URL;
        String itemsUrlWithParams = getURL(url,catalogCode,level,refreshId,processedFlag,null,-1,-1,false,null);
        String itemsJson = getResponse(itemsUrlWithParams);
        return Integer.parseInt(itemsJson);

    }
    public static int getItemCount(String catalogCode, int level, String itemFlag,String refreshId) throws DRMPaasServiceException {

        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        //url += "/OALSCMDRMSyncServices/service/category/getCategoryCount";
        url+=GET_ITEM_COUNT_SERVICE_URL;
        String itemsUrlWithParams = getURL(url,catalogCode,level,refreshId,null,itemFlag,-1,-1,false,null);
        String itemsJson = getResponse(itemsUrlWithParams);
        return Integer.parseInt(itemsJson);

    }
    
    
    
    public static int getMaxLevel(String catalogCode, String refreshId) throws DRMPaasServiceException {


        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get max level of catalog : " + catalogCode);
        
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        //url += "/OALSCMDRMSyncServices/service/category/getMaxLevel";
        url+=GET_MAX_LEVEL_SERVICE_URL;
        String itemsUrlWithParams = getURL(url,catalogCode,0,refreshId,null,null,-1,-1,false,null);
        
        String itemsJson = getResponse(itemsUrlWithParams);
        return Integer.parseInt(itemsJson);
        
    }

    public static Set<String> getErroredCategories(String catalogCode, int level,
                                                   String refreshId) throws DRMPaasServiceException, JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get errored categories for catalog : " + catalogCode + ", level :" +
                          level);

        Set<String> catList = new HashSet<String>();
     //   JSONArray retArr = new JSONArray();

        int offset = 0;
        int serviceLimit = 400;
        
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        //url += "/OALSCMDRMSyncServices/service/category/getCategoryCatalog";
       url+=GET_CATEGORIES_STAGE_SERVICE_URL;
        
        JSONArray jsonArray = null;
        do {
            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, "E", null, serviceLimit, offset,false,null);
            String itemsJson = getResponse(itemsUrlWithParams);
            jsonArray = new JSONArray(itemsJson);
            
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.getJSONObject(i).getString("categoryCode"));
               
            offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);

        System.out.println(catList.size());
         return catList;
    }

    public static JSONArray getCategories(String catalogCode, int level, String refreshId,
                                          boolean leaf) throws DRMPaasServiceException, JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "1.Calling paas ws to get changed categories for catalog : " + catalogCode + ", level :" + level);

        List<String> catList = new ArrayList<String>();
        JSONArray retArr = new JSONArray();

        int offset = 0;
        int serviceLimit = 400;
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        //url += "/OALSCMDRMSyncServices/service/categoryChange/getChangedCategories";
        url+=GET_CHANGED_CATEGORIES_DELTA_SERVICE_URL;
        JSONArray jsonArray = null;
        do {
            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, null, null, serviceLimit, offset,leaf,null);
            String itemsJson = getResponse(itemsUrlWithParams);

                jsonArray = new JSONArray(itemsJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject job = new JSONObject();
                    job = jsonArray.getJSONObject(i);
                    retArr.put(job);
                }
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.get(i).toString());
              
                    offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);

        System.out.println(catList.size());
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "1.Success, Calling paas ws to get changed categories for catalog : " + catalogCode + ", level :" + level);


        //System.out.println("The Array is : \n"+retArr.length());
        return retArr;
    }


    public static JSONArray getCategoriesfromStageTable(String catalogCode, int level,
                                                        String refreshId) throws DRMPaasServiceException,
                                                                                 JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get from stage categories for catalog : " + catalogCode + ", level :" + level);

        List<String> catList = new ArrayList<String>();
        JSONArray retArr = new JSONArray();

        int offset = 0;
        int serviceLimit = 400;
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        //url += "/OALSCMDRMSyncServices/service/category/getCategoryCatalog";
        url+=GET_CATEGORIES_STAGE_SERVICE_URL;
        JSONArray jsonArray = null;
        do {

            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, null, null, serviceLimit, offset,false,null);
            String itemsJson = getResponse(itemsUrlWithParams);
            
                jsonArray = new JSONArray(itemsJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject job = new JSONObject();
                    job = jsonArray.getJSONObject(i);
                    retArr.put(job);
                }
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.get(i).toString());
               
            offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);

        System.out.println(catList.size());
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Success. Calling paas ws to get from stage categories for catalog : " + catalogCode + ", level :" + level);


        //System.out.println("The Array is : \n"+retArr.length());
        return retArr;
    }



    public static String updateCategoriesV2(String catalogCode, JSONArray arr, int a, int b,
                                            String processedFlag,String refreshId) throws JSONException {
        //
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to Update processed flag in stage table");

        StringBuilder sb = new StringBuilder();
        for (int i = a; i < arr.length() && i < b; i++) {
            JSONObject jobj = arr.getJSONObject(i);
            sb.append("'");
            sb.append(jobj.getString("categoryCode"));
            sb.append("'");
            sb.append(",");
        }

        sb.setLength(sb.length() - 1);
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            //url += "/OALSCMDRMSyncServices/service/category/updateProcessedFlag";
            url+=UPDATE_PROCESSED_FLAG_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, processedFlag, null, -1, -1,false,null);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, sb.toString());

            System.out.println("updated processed flag for " + sb.toString() + " with response " + clientResponse +
                               " catalog code " + catalogCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Success. calling paas ws to Update processed flag in stage table");
        return clientResponse;
    }

    public static String updateItemAssociation(String catalogCode, JSONArray arr, int a, int b,
                                               List<Integer> leafIndex,
                                               String itemProcessedFlag,String refreshId) throws JSONException {
        //
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to Update Item Association flag in stage table");
        StringBuilder sb = new StringBuilder();

        if (leafIndex == null) {
            for (int j = a; j < b; j++) {

                JSONObject jobj = arr.getJSONObject(j);
                sb.append("'");
                sb.append(jobj.getString("categoryCode"));
                sb.append("'");
                sb.append(",");

            }
        } else {

            for (int j : leafIndex) {
                if (j < a || j >= b)
                    continue;
                JSONObject jobj = arr.getJSONObject(j);
                sb.append("'");
                sb.append(jobj.getString("categoryCode"));
                sb.append("'");
                sb.append(",");

            }
        }
        if (sb.length() > 0)
            sb.setLength(sb.length() - 1);
        if (sb.length() == 0)
            return "";

        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            //url += "/OALSCMDRMSyncServices/service/category/updateItemProcessedFlag";
            url+=UPDATE_ITEM_PROCESSED_FLAG_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, itemProcessedFlag, -1, -1,false,null);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, sb.toString());
            System.out.println("updated processed flag for " + sb.toString() + " with response " + clientResponse +
                               " catalog code " + catalogCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clientResponse;
    }


    public static String updateComments(String catalogCode, String categoryCode,
                                        String comments,String refreshId) throws JSONException {
        //
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to Update comments in stage table");


        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            //url += "/OALSCMDRMSyncServices/service/category/updateComments";
            url+=UPDATE_COMMENTS_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, null, -1, -1,false,categoryCode);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, comments);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clientResponse;
    }


    public static boolean parentExist(String catalogCode, JSONArray arr, int a, int b,String refreshId) throws JSONException {
        //
        //        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(),loggerName+"["+catalogCode+"]",
        //                          DRMSyncPropertyV2.getInstance().getLoggerID(),
        //                          "debug","calling paas ws to check if parent exist");
        Set<String> catcode = new HashSet<String>();
        StringBuilder sb = new StringBuilder();
        for (int i = a; i < arr.length() && i < b; i++) {

            catcode.add(arr.getJSONObject(i).getString("parentCategoryCode"));

        }
        for (String s : catcode) {
            sb.append("'");
            sb.append(s);
            sb.append("'");
            sb.append(",");
        }

        sb.setLength(sb.length() - 1);

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to check if parent exist for catalog " + catalogCode + " and categories " +
                          sb.toString());
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            //url += "/OALSCMDRMSyncServices/service/category/getNoOfProcessedCatgories";
            url+=GET_NO_OF_PROCESSED_CAT_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, null, -1, -1,false,null);
            System.out.println(itemsUrlWithParams);
            clientResponse=invokeUpdatePost(itemsUrlWithParams, sb.toString());
           
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Integer.parseInt(clientResponse) == catcode.size())
            return true;
        System.out.println("Parent does not exist for some of categories among " + sb.toString());
        return false;
    }


    public static String deleteCategories(String catalogCode, JSONArray arr, int a,
                                          int b,String refreshId) throws JSONException {
        //
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug", "delete in stage table");

        StringBuilder sb = new StringBuilder();
        for (int i = a; i < arr.length() && i < b; i++) {
            JSONObject jobj = arr.getJSONObject(i);
            sb.append("'");
            sb.append(jobj.getString("categoryCode"));
            sb.append("'");
            sb.append(",");
        }

        sb.setLength(sb.length() - 1);
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            //url += "/OALSCMDRMSyncServices/service/categoryChange/deleteProcessed";
            url+=DELETE_PROCESSED_CATEGORY_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, null, -1, -1,false,null);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, sb.toString());
            
            System.out.println(clientResponse);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clientResponse;
    }


}
