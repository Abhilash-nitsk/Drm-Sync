package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.ArrayList;

import javax.ejb.Stateless;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import java.util.HashMap;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import oal.oracle.apps.scm.drm.AssociateItem;
import oal.oracle.apps.scm.drm.CategorySyncSaasToStage;
import oal.oracle.apps.scm.drm.DRMDataSync;
import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import org.json.JSONArray;
import org.json.JSONObject;

@Stateless
@Path("Wrapper")
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
public class SyncWrapperService {
    public SyncWrapperService() {
        //super(OALDRMSync.class);
    }

    @GET
    @Path("/associateItems")
    public String syncItems(@QueryParam("refreshId") String refreshId) {
        System.out.println(" in associate item Service");
        try {

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        new AssociateItem().sync(DRMSyncPropertyV2.Catalog.CRM, refreshId);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, "2");
            t.start();
            //Thread thread = new Thread(wrapper);
            //thread.start();

        } catch (Exception e) {
            return "Failed due to " + e.getStackTrace().toString();
        }
        return "Success";
    }

    @GET
    @Path("/syncSaasPaas")
    public String syncSaasPaas(@QueryParam("refreshId") int refreshId) {
        System.out.println(" in associate item Service");
        try {

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        new CategorySyncSaasToStage().sync(refreshId);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, "3");
            t.start();
            //Thread thread = new Thread(wrapper);
            //thread.start();

        } catch (Exception e) {
            return "Failed due to " + e.getStackTrace().toString();
        }
        return "Success";
    }

    @GET
    @Path("/syncCategories")
    public String syncData() {
        System.out.println(" in syncCategories Service");
        try {

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        new DRMDataSync().sync();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, "1");
            t.start();
            //Thread thread = new Thread(wrapper);
            //thread.start();

        } catch (Exception e) {
            return "Failed due to " + e.getStackTrace().toString();
        }
        return "Success";
    }
    
    @GET
    @Path("/getSaasRoles")
    @Produces("application/json")
    public String getSaasRoles(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit) {
        System.out.println(" in syncCategories Service inside the getSaasRoles method");
            String url =
                new String("https://gxpbt.oracle.com/apex/pgxpbt/oalfnd/oalsec/security/store/policies/OALSCMOPIC/eldo.joseph@oracle.com");
            Client client = ClientBuilder.newClient();
            WebTarget target = client.target(url);
            String res = target.request()
                               .get()
                               .readEntity(String.class);
            JSONArray arr = new JSONArray();
            ArrayList<String> roles = new ArrayList<String>();
            try{
                JSONObject jsonObj =  new JSONObject(res.toString());
                arr = jsonObj.getJSONArray("items");
                System.out.println("Roles are :  "+arr);
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
            return arr.toString();
    }
}
