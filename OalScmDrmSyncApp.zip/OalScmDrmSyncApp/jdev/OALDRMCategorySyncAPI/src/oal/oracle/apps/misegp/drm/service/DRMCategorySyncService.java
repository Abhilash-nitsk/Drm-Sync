package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.nio.charset.Charset;

import java.util.ArrayList;

import java.util.Base64;

import javax.ejb.Stateless;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import java.util.HashMap;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import org.json.JSONArray;
import org.json.JSONObject;

@Stateless
@Path("cateogory_sync_wrapper")
@Produces("application/json")
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
public class DRMCategorySyncService {
    public DRMCategorySyncService() {
        //super(OALDRMSync.class);
    } 
    @GET
    @Path("/get_saas_roles")
    
    public String getSaasRoles(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit,@Context HttpHeaders httpHeaders) {
        System.out.println(" in syncCategories Service inside the getSaasRoles method");
            String url =
                new String("https://gxpbt.oracle.com/apex/pgxpbt/oalfnd/oalsec/security/store/policies/OALSCMOPIC/eldo.joseph@oracle.com");
            Client client = ClientBuilder.newClient();
            WebTarget target = client.target(url);
            String res = target.request()
                               .get()
                               .readEntity(String.class);
            JSONArray arr = new JSONArray();
            ArrayList<String> roles = new ArrayList<String>();
            JSONObject jsonResult = new JSONObject();
            try{
                JSONObject jsonObj =  new JSONObject(res.toString());
                arr = jsonObj.getJSONArray("items");
                if(arr.length()!=0){                     
                     for(int i=0; i<arr.length(); i++){
                            roles.add(   arr.getJSONObject(i).getString("role_common_name"));
                     }
                }
                
                jsonResult.put("role_common_name", roles);
                System.out.println("Roles are :  "+jsonResult);
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
            
            
        System.out.println("Roles are :  "+jsonResult);
//            String authorization = null;
//            httpHeaders.getRequestHeader("Authorization").get(0);
//            String user=null;
//            String pass=null;
//
//            if (authorization != null && authorization.startsWith("Basic")) { // Authorization: Basic base64credentials
//                String base64Credentials = authorization.substring("Basic".length()).trim();
//                String credentials =
//                    new String(Base64.getDecoder().decode(base64Credentials),
//                               Charset.forName("UTF-8")); // credentials = username:password
//                final String[] values = credentials.split(":", 2);
//                user=values[0];
//                pass=values[1];
//                System.out.println("The User name is : " + user + "The password is : "+pass);
//            }
           
            
            return jsonResult.toString();
    }
    @GET
    @Path("/get_user")
    
    public String getUser(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit,@Context HttpHeaders httpHeaders) {
        System.out.println("Inside the getUser method");
        String authorization = null;
        httpHeaders.getRequestHeader("Authorization").get(0);
        String user=null;
        String pass=null;
        String result=null;
        if (authorization != null && authorization.startsWith("Basic")) { // Authorization: Basic base64credentials
            String base64Credentials = authorization.substring("Basic".length()).trim();
            String credentials =
                new String(Base64.getDecoder().decode(base64Credentials),
                           Charset.forName("UTF-8")); // credentials = username:password
            final String[] values = credentials.split(":", 2);
            user=values[0];
            pass=values[1];
            System.out.println("The User name is : " + user + "The password is : "+pass);
            result = new String("User : "+user + "   pass :  "+pass);
        }    
        return result;
    }
    
}
