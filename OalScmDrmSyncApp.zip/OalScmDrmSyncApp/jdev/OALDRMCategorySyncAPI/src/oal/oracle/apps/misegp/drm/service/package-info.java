package oal.oracle.apps.misegp.drm.DRMCategorySyncAPI;

