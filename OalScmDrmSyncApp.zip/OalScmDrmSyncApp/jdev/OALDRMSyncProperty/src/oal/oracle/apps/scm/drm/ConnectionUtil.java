package oal.oracle.apps.scm.drm;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.sql.DataSource;

import oal.util.logger.OalLogger;

public class ConnectionUtil {
    private static String  loggerName = ConnectionUtil.class.getName();

    public ConnectionUtil() {
        super();
    }
    static List<Connection> connections=new ArrayList();
    
    public static List<Connection> getConnections() {
        return connections;
    }

    public static Connection getNewConnection() throws NamingException, SQLException {
        
        Connection connection = null;
        DataSource dataSource = null;
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      //  env.put(Context.PROVIDER_URL, "t3://localhost:7101");
        InitialContext context;
        try {
            
            context = new InitialContext(env);
            dataSource = (DataSource) context.lookup("jdbc/OalscmRuntimeERP");
            
        } catch (NamingException e) {
            OalLogger.sendLog("SCM-MDM-DRM-SYNC", loggerName, "SCM-MDM-DRM-SYNC", "fatal",
                              "Exception occurred while initiating context or db lookup with message "+e.getMessage());
            throw e;
        }
       
        try {
            connection = dataSource.getConnection();
        } catch (SQLException e) {
            OalLogger.sendLog("SCM-MDM-DRM-SYNC", loggerName, "SCM-MDM-DRM-SYNC", "fatal",
                              "Exception occurred while initiating db connection to read property with message "+e.getMessage());
            throw e;
        }
        connections.add(connection);
        return connection;
    }
    public static void closeAllConnections() {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Closing all connections, "+"Total number of connections established "+connections.size());
       System.out.println("Total number of connections established "+connections.size());
        for(int i=connections.size()-1;i>=0;i--) {
            try {
                connections.get(i).close();
            } catch (SQLException e) {
            }
            connections.remove(i);
        }
       
    }
    
}
