package oal.oracle.apps.scm.drm.orbit;

public class DRMXMLStringUtil {
    public DRMXMLStringUtil() {
        super();
    }

    // ITEM

    public static final String ITEM = "item";
    public static final String ITEM_ORGANIZATION_CODE = "OrganizationCode";
    public static final String ITEM_CLASS = "ItemClass";
    public static final String ITEM_NUMBER = "ItemNumber";
    public static final String ITEM_DESCRIPTION = "ItemDescription";
    public static final String ITEM_STATUS_VALUE = "ItemStatusValue";
    public static final String LIFECYCLE_PHASE_VALUE = "LifecyclePhaseValue";
    public static final String PRIMARY_UNIT_OF_MEASUREMENT = "PrimaryUOMValue";

    public static final String ITEM_CATEGORY = "ItemCategory";
    public static final String ITEM_CATALOG = "ItemCatalog";

    public static final String ITEM_OPERATION_PROCESS_ITEM = "processItem";
    public static final String ITEM_OPERATION_MERGE_ITEM = "mergeItem";
    public static final String ITEM_CHANGE_OPERATION = "changeOperation";
    public static final String CATEGORY_NAME = "CategoryName";

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    //// CATEGORY

    public static final String CATEGORY = "category";
    public static final String CATEGORY_CHANGE_OPERATION = "changeOperation";
    public static final String CATEGORY_OPERATION_PROCESS_CATEGORY = "processCategory";
    public static final String CATEGORY_OPERATION_MERGE_CATEGORY = "mergeCategory";
    public static final String CATEGORY_CODE = "CategoryCode";
    public static final String CATEGORY_DESCRIPTIOIN = "Description";
    public static final String START_DATE = "StartDate";
    public static final String END_DATE = "EndDate";
    public static final String CATALOG_CODE = "CatalogCode";
    public static final String PARENT_CATEGORY_CODE = "ParentCategoryCode";
    public static final String CATEGORY_PROCESS_CONTROL = "processControl";
    public static final String CATEGORY_RETURN_MODE = "returnMode";
    public static final String CATEGORY_PARTIAL_FAILURE_ALLOWED = "partialFailureAllowed";
    

}
