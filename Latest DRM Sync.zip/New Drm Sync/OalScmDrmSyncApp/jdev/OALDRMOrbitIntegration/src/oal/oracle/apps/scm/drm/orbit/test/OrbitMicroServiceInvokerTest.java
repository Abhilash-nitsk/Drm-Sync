package oal.oracle.apps.scm.drm.orbit.test;

import java.io.IOException;

import java.text.SimpleDateFormat;

import java.util.Date;

import javax.xml.soap.SOAPException;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;
import oal.oracle.apps.scm.drm.orbit.DRMJSONStringUtil;
import oal.oracle.apps.scm.drm.orbit.OrbitMicroServiceInvoker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static org.junit.Assert.*;
import org.junit.Test;

public class OrbitMicroServiceInvokerTest {
    
    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    public OrbitMicroServiceInvokerTest() {
        super();
    }
    @Test
    public void testMicroservices() throws JSONException, SOAPException, IOException {
        
        JSONObject obj = new JSONObject();
        String catCode="DNU_"+randomAlphaNumeric(8);
        obj.put(DRMJSONStringUtil.CATEGORY_CODE, catCode);
        obj.put(DRMJSONStringUtil.CATEGORY_NAME, catCode);
        obj.put(DRMJSONStringUtil.CATEGORY_DESCRIPTION, "DNU1");
        String modifiedDate = new SimpleDateFormat("dd-MMM-yyyy").format(new Date());

        obj.put(DRMJSONStringUtil.START_DATE, modifiedDate);
        obj.put("type", "N");
        obj.put(DRMJSONStringUtil.END_DATE, modifiedDate);
        String catalogName = DRMSyncPropertyV2.getInstance().getJunitTestCatalogName();
        assertNotNull("Catalog name is null", catalogName);
        String[] out = new String[2];
        
            OrbitMicroServiceInvoker.invokeMergeCategoryService(obj, catalogName, out);
            assertEquals(true, OrbitMicroServiceInvoker.categoryExist(catCode));
            catCode="DNU_"+randomAlphaNumeric(8);
            obj.put(DRMJSONStringUtil.CATEGORY_CODE, catCode);
            obj.put(DRMJSONStringUtil.CATEGORY_NAME, catCode);
            JSONArray arr=new JSONArray();
            arr.put(obj);
            OrbitMicroServiceInvoker.invokeCategoryService(arr, catalogName);
            assertEquals(true, OrbitMicroServiceInvoker.categoryExist(catCode));

        }
    private static String randomAlphaNumeric(int count) {
       StringBuilder builder = new StringBuilder();
       while (count-- != 0) {
           int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
           builder.append(ALPHA_NUMERIC_STRING.charAt(character));
       }
       return builder.toString();
    }
}
