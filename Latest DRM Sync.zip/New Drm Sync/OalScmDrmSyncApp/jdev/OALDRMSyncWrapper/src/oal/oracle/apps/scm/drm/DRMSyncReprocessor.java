package oal.oracle.apps.scm.drm;

import org.json.JSONArray;
import org.json.JSONObject;

public class DRMSyncReprocessor {
    public DRMSyncReprocessor() {
        super();
    }
    
    public void reprocessCompleteSync(String refreshId,JSONArray newDataArray) {
        
    }
    public void reprocessCatalog(DRMSyncPropertyV2.Catalog catalog, JSONArray newDataArray) {
        
    }
    public void reprocessCategory(String categoryCode, JSONObject newData) {
        
    }
}
