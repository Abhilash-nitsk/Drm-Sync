package oal.oracle.apps.scm.drm;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;
import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import oal.util.logger.OalLogger;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class DRMDataSync {
    public DRMDataSync() {
        super();
    }
    private static Lock lock = new ReentrantLock();
    private static Object lock1 = new Object();

    private static String loggerName = DRMDataSync.class.getName();

    @Test
    public void unitTest() throws Exception {
        
    }


    
/**
     * Initiate sync process, lock will be aquired to process the request and if lock is already aquired request will be added to the queue
     * table and will be processed after completion of current request.
     * 
     * @throws SQLException
     * @throws NamingException
     * @throws Exception
     */
    public void sync() throws SQLException, NamingException, Exception {
        
        
        
        if (lock.tryLock()) {
            
            OalLogger.sendLog("SCM-DRM-SYNC", loggerName,
                              "SCM-DRM-SYNC", "info",
                              "Initializing sync ");

            try {

                // new refresh id generation
                String newRefreshId = prepare();

                // old data sync

                if (newRefreshId == null)
                    throw new Exception();

                // catalog sync
                process(newRefreshId);

            } finally {

                ConnectionUtil.closeAllConnections();
                    
                lock.unlock();
            }
        } else {
            // Someone else had the lock, abort
            prepare();

        }

    }
/**
     * This method will generate new refresh Id to be processed and add it to the queue. No two invocation of this method allowed simultaneously
     * For that reason preprocessing is in synchronized block
     * 
     * @return
     * @throws InterruptedException
     * @throws SQLException
     * @throws NamingException
     * @throws ClassNotFoundException
     */

    private String prepare() throws InterruptedException, SQLException, NamingException, ClassNotFoundException {
        String newRefreshId = "";
        
        synchronized (lock1) {

            OalLogger.sendLog("SCM-DRM-SYNC", loggerName,
                              "SCM-DRM-SYNC", "info",
                              " preparing to generate refresh id ");


            DRMSyncPropertyV2.init();
            
            Timestamp dateTime = getCurrentTimeStamp();
            try{
            drmViewUpdatedNotification(dateTime.toString());
            }catch(Exception e){
            }

            newRefreshId = generateNewRefreshId();

            DRMResultPublisher.getInstance().insertInQueue(Integer.parseInt(newRefreshId), "pending");
            updatelastRefreshId(newRefreshId);
            updatelastRefreshTimeStamp(dateTime.toString());
            DRMResultPublisher.getInstance().addToRecord(newRefreshId, dateTime);

            lock1.notifyAll();
            return newRefreshId;
        }

    }

/**
     * This method will take refreshId as input and populate paas custom table accordingly and further call sync
     *
     * @param newRefreshId
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws NamingException
     */
    public void process(String newRefreshId) throws ClassNotFoundException, SQLException, NamingException {

        DRMResultPublisher.getInstance().updateQueue(Integer.parseInt(newRefreshId), "processing");
        try {

            seedDataToStageTable(newRefreshId);
            int refId = Integer.parseInt(newRefreshId);
            DRMResultPublisher.getInstance().updateQueue(refId, "started");
            updateCurrentRefreshId(newRefreshId);
            seedDeltaTable(newRefreshId);
            startSyncforAllCatalogs(newRefreshId);

        } catch (NamingException | SQLException e)

        {
        } catch (ClassNotFoundException e) {
        } finally {
            DRMResultPublisher.getInstance().removefromQueue(newRefreshId);
        }

        int refId = DRMResultPublisher.getInstance().getNextINQueue(Integer.parseInt(newRefreshId));
        if (refId != -1) {
            process(String.valueOf(refId));
        }
    }

    private static Timestamp getCurrentTimeStamp() {
        return (new Timestamp(System.currentTimeMillis()));
    }

    private void drmViewUpdatedNotification(String dateTime) {

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Sending DRMView Update Notification..");


        String message = "DRM VIEW HAS BEEN REFRESHED AT " + dateTime;
        MailNotification.sendSimpleMail(DRMSyncPropertyV2.getInstance().getMailSender(), DRMSyncPropertyV2.getInstance().getMailRecipients(),
                                        "DRM View Updated", message);
    }


    private void updateCurrentRefreshId(String refreshid) throws SQLException, NamingException {
        DRMSyncPropertyV2.getInstance().updateCurrentRefreshId(refreshid);

    }

    private String generateNewRefreshId() throws SQLException, NamingException {
        int refreshid = Integer.parseInt(DRMSyncPropertyV2.getInstance().getLastRefreshId()) + 10;

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Generated new refresh id " + refreshid);

        return String.valueOf(refreshid);
    }
/**
     * This method will populate data from DRM View in oalepm schema to Paas custom table in oalscm schema  by calling underlying PL/SQL Procedure
     *
     * @param newRefreshId
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws NamingException
     */
    private void seedDataToStageTable(String newRefreshId) throws ClassNotFoundException, SQLException,
                                                                  NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Copying data from DRMView to paas stage table");
        
        DRMResultPublisher.getInstance().updateQueue(Integer.parseInt(newRefreshId), "seeding");

        Connection dbConnection =null;
        try
        {
        dbConnection = ConnectionUtil.getNewConnection();
        PreparedStatement preparedStatement =
            dbConnection.prepareStatement(DRMSyncPropertyV2.getInstance().getStageTableSeedingProcedure());
        preparedStatement.setObject(1, Integer.parseInt(newRefreshId));
        preparedStatement.execute();

        }finally
        {
            if(dbConnection!=null)
                dbConnection.close();
        }
        
        DRMResultPublisher.getInstance().updateQueue(Integer.parseInt(newRefreshId), "seeded");
    }
/**
     * Start sync for all three catalogs in multi threaded manner.
     *
     * @param newRefreshId
     */
    private synchronized void startSyncforAllCatalogs(String newRefreshId) {

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Starting sync for catalogs.");

        ExecutorService executorService = Executors.newFixedThreadPool(DRMSyncPropertyV2.Catalog
                                                                                        .values()
                                                                                        .length);

        for (DRMSyncPropertyV2.Catalog cat : DRMSyncPropertyV2.Catalog.values()) {

            DrmSyncWrapper wrapper = new DrmSyncWrapper(newRefreshId, cat);
            executorService.execute(wrapper);
           

        }
        executorService.shutdown();
        try {
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
        }
        
    }


    private void updatelastRefreshId(String newRefreshId) throws SQLException, NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Updating last refreshed id");

        DRMSyncPropertyV2.getInstance().updatelastRefreshId(newRefreshId);
    }

    private void updatelastRefreshTimeStamp(String timestamp) throws SQLException, NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Updating last refreshed timestamp");

        DRMSyncPropertyV2.getInstance().updatelastRefreshTimeStamp(timestamp);
    }
/**
     * Compare two refresh id and populate changes only to new table calling underlying PL/SQL procedure.
     *
     * @param newRefreshId
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws NamingException
     */
    private void seedDeltaTable(String newRefreshId) throws ClassNotFoundException, SQLException, NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info", "Populating Delta Table..");

        DRMResultPublisher.getInstance().findDelta(newRefreshId);

    }

    public static void  addToArchive(String catalog, String newRefreshId) throws ClassNotFoundException, SQLException,
                                                                  NamingException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
                          "Copying data From Changes table to Archive table");
        
        Connection dbConnection =null;
        Connection con = ConnectionUtil.getNewConnection();

        try
        {
            
            String query = "INSERT INTO OALSCM.OALEGO_DRM_SYNC_HISTORY " +
                "(REFRESH_ID, CATALOG_CODE, CATEGORY_CODE, CATEGORY_NAME, CATEGORY_DESC, PARENT_CATEGORY_CODE, START_DATE, END_DATE, LEVL, IS_LEAF  ) " +
                "SELECT REFRESH_ID,CATALOG_CODE, CATEGORY_CODE, CATEGORY_NAME, CATEGORY_DESCRIPTION, PARENT_CATEGORY_CODE, START_DATE, END_DATE, LEVL, IS_LEAF " +
                "FROM OALSCM.OALEGO_DRM_DATA_CHANGE where refresh_id=? and catalog_code=?";
            PreparedStatement preparedStatement =con.prepareStatement("INSERT INTO OALSCM.OALEGO_DRM_SYNC_HISTORY " +
                "(REFRESH_ID, CATALOG_CODE, CATEGORY_CODE, CATEGORY_NAME, CATEGORY_DESC, PARENT_CATEGORY_CODE, START_DATE, END_DATE, LEVL, IS_LEAF  ) " +
                "SELECT REFRESH_ID,CATALOG_CODE, CATEGORY_CODE, CATEGORY_NAME, CATEGORY_DESCRIPTION, PARENT_CATEGORY_CODE, START_DATE, END_DATE, LEVL, IS_LEAF " +
                "FROM OALSCM.OALEGO_DRM_DATA_CHANGE where refresh_id=? and catalog_code=?");
            preparedStatement.setObject(1, newRefreshId);
            preparedStatement.setObject(2, catalog);
            int r = preparedStatement.executeUpdate();
            preparedStatement.close();
       

        }
        catch(Exception e){
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                              "Error while Copying changes to archive table " + "[" + catalog + "] message:" + e.getMessage());
        }
        finally
        {
            if(dbConnection!=null)
                dbConnection.close();
            if(con!=null)
                con.close();
        }
    }
    

}
