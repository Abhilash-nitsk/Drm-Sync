package oal.oracle.apps.scm.drm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.naming.NamingException;

import oal.util.logger.OalLogger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DRMResultPublisher {
    
    private static String loggerName = DRMResultPublisher.class.getName();
    private static Object lock = new Object();
    private volatile static DRMResultPublisher publisher = null;
    private Connection dbConnection;
    private DRMResultPublisher() throws NamingException, SQLException {
        super();
    }
    

    public static DRMResultPublisher getInstance() throws ClassNotFoundException, SQLException, NamingException {
        if (publisher == null) {
            synchronized (lock) {
                if (publisher == null)
                {
                try {
                    publisher = new DRMResultPublisher();
                } catch (NamingException | SQLException e) {
                                        
                    throw e;
                }
                
                }
            }
        }
        return publisher;
    }

    public Connection getConnection() throws SQLException, NamingException {
        if(dbConnection==null || dbConnection.isClosed())
            synchronized(DRMResultPublisher.class)
            {
                if(dbConnection==null || dbConnection.isClosed())
                    dbConnection=ConnectionUtil.getNewConnection();
            }
        
        return  dbConnection;
        
    }
    public void closeConnection() throws SQLException {
        dbConnection.close();
    }

    public void publishResult(JSONObject message) throws JSONException {

        
        String catalogCode = message.getString("catalogCode");
        String status = message.getString("status");
       
        String maxDepth = message.getString("maxDepth");
        

        String refreshId = message.getString("refreshId");
        long startTime = message.getLong("startTimestamp");
        long endTime = message.getLong("completedTimestamp");
        

        JSONArray arr = message.getJSONArray("data");
        int processed = 0, unprocessed = 0, errored = 0;
        for (int i = 0; i < arr.length(); i++) {

            processed += Integer.valueOf(arr.getJSONObject(i).getString("processed"));
            unprocessed += Integer.valueOf(arr.getJSONObject(i).getString("unprocessed"));
            errored += Integer.valueOf(arr.getJSONObject(i).getString("errored"));
        }

        if (endTime != 0) {
            updateRecordOnCompletion(refreshId, catalogCode, new Timestamp(startTime), new Timestamp(endTime), errored,
                                     processed, unprocessed, maxDepth, status);
        } else {
            updateRecordAsFailure(refreshId, new Timestamp(startTime), catalogCode, errored, processed, unprocessed,
                                  maxDepth, "Failed");
        }
    }

    public synchronized void updateRecordOnCompletion(String refreshId, String catCode, Timestamp starttimestamp,
                                                      Timestamp completedtimestamp, int erroredcat, int processedcat,
                                                      int unprocessedcat, String maxdepth, String status) {
        
        
        
        try {
            Connection dbConnection=getConnection();
            String query =
            "update oalego_drm_sync_record set start_time_stamp= ?, completed_time_stamp = ? ,errored_cat= ?, processed_cat= ?, unprocessed_cat= ? , max_depth = ? , status = ? where refresh_id= ? and catalog_code= ?";
            PreparedStatement preparedStatement = dbConnection.prepareStatement(query);
            preparedStatement.setTimestamp(1, starttimestamp);
            preparedStatement.setTimestamp(2, completedtimestamp);
            preparedStatement.setInt(3, erroredcat);
            preparedStatement.setInt(4, processedcat);
            preparedStatement.setInt(5, unprocessedcat);
            preparedStatement.setString(6, maxdepth);
            preparedStatement.setString(7, status);
            preparedStatement.setString(8, refreshId);
            preparedStatement.setString(9, catCode);
            preparedStatement.executeUpdate();
            preparedStatement.close();

            
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "updated completion time at " + completedtimestamp.toString() +
                                           " for record with refid " + refreshId + " and catalog Code" + catCode);
            
        } catch (Exception e) {

        }
    }

    public synchronized void updateRecordAsFailure(String refreshId, Timestamp starttimestamp, String catCode,
                                                   int erroredCat, int processedCat, int unprocessedCat,
                                                   String maxDepth, String status) {
        try {
            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
            dbConnection.prepareStatement("update oalego_drm_sync_record set start_time_stamp=? , errored_cat=? , processed_cat= ?, unprocessed_cat= ?, max_depth = ?, status = ? where refresh_id= ? and catalog_code= ?");
            preparedStatement.setTimestamp(1, starttimestamp);
            preparedStatement.setInt(2, erroredCat);
            preparedStatement.setInt(3, processedCat);
            preparedStatement.setInt(4, unprocessedCat);
            preparedStatement.setString(5, maxDepth);
            preparedStatement.setString(6, status);
            preparedStatement.setString(7, refreshId);
            preparedStatement.setString(8, catCode);
            preparedStatement.executeUpdate();
            preparedStatement.close();

            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
           "updated failure for record with refid " + refreshId + " and catalog Code" + catCode);
        } catch (Exception e) {

        }

    }

    public synchronized void updateRecordStartTimestamp(String refreshId, DRMSyncPropertyV2.Catalog cat,
                                                        Timestamp startTimestamp) {
        try {
            
            Connection dbConnection=getConnection();
           
            PreparedStatement preparedStatement =
            dbConnection.prepareStatement("update oalego_drm_sync_record set start_time_stamp = ? where refresh_id= ? and catalog_code= ?");
            preparedStatement.setTimestamp(1, startTimestamp);
            preparedStatement.setString(2, refreshId);
            preparedStatement.setString(3,  cat.getCode());
            preparedStatement.executeUpdate();
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "updated start timestamp to " + startTimestamp.toString() + " for record with refid " +
                                           refreshId + " and catalog Code" + cat.getCode());

        } catch (Exception e) {



        }
    }

    public synchronized void addToRecord(String newRefreshId, Timestamp timestamp) {
        try {
            Connection dbConnection=getConnection();
            for (DRMSyncPropertyV2.Catalog cat : DRMSyncPropertyV2.Catalog.values()) {
                String catalogCode = cat.getCode();
                String catalogName = cat.getValue();
                String query = "insert into oalego_drm_sync_record (refresh_id,catalog_code,catalog_name,notified_time_stamp) values ( ? , ?, ?, ?)";
                PreparedStatement preparedStatement = dbConnection.prepareStatement(query);
                preparedStatement.setString(1, newRefreshId);
                preparedStatement.setString(2, catalogCode);
                preparedStatement.setString(3, catalogName);
                preparedStatement.setTimestamp(4, timestamp);
                preparedStatement.executeUpdate();
                preparedStatement.close();
            }
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "New record added with refreshid " + newRefreshId + " and timestamp " + timestamp);

        } catch (Exception e) {



        }
    }

    public synchronized void removefromQueue(String newRefreshId) {
        try {
            Connection dbConnection=getConnection();
            String st = "delete from oalego_drm_sync_queue where refresh_id= ?";
            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);
            preparedStatement.setString(1, newRefreshId);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "\n Record with refreshid " + newRefreshId + " deleted from queue.");

        } catch (Exception e) {


        }

    }



    public synchronized void copyToArchive(String newRefreshId) {
        try {
            Connection dbConnection=getConnection();
            String st = "delete from oalego_drm_sync_queue where refresh_id= ?";
            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);
            preparedStatement.setString(1, newRefreshId);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
            "\n Record with refreshid " + newRefreshId + " deleted from queue.");

        } catch (Exception e) {


        }

    }
    
    




    public synchronized void findDelta(String refreshId) {

        try {
            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement(DRMSyncPropertyV2.getInstance().getDBProcedure());
            preparedStatement.setObject(1, Integer.parseInt(refreshId));
            preparedStatement.execute();
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "Delta finding completed");
        } catch (Exception e) {


        }
    }

    public synchronized int getNextINQueue(int refreshId) {
        int ref = -1;

        try {
            Connection dbConnection=getConnection();
            String st = "select refresh_id from oalego_drm_sync_queue where refresh_id=?";

            PreparedStatement preparedStatement = dbConnection.prepareStatement(st);
            preparedStatement.setInt(1, (refreshId + 10));
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                ref = rs.getInt("refresh_id");
            }
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "Get next called successfully. Next-" + ref);

        } catch (Exception e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
            "Error in calling getNext Error:" + e.getMessage());


        }
        return ref;
    }

    public synchronized void insertInQueue(int refreshid, String status) {


        try {
            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
                dbConnection.prepareStatement("insert into oalscm.oalego_drm_sync_queue (refresh_id,status) values (?,?)");
            preparedStatement.setObject(1, refreshid);
            preparedStatement.setObject(2, status);
            preparedStatement.execute();
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "New request added in queue with refreshid " + refreshid);
        } catch (Exception e) {

            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
            "Exception while inserting data in queue " + refreshid+" Error:"+e.getMessage());
            


        }

    }

    public synchronized void updateQueue(int refreshid, String status) {


        try {

            Connection dbConnection=getConnection();
            PreparedStatement preparedStatement =
            dbConnection.prepareStatement("update oalscm.oalego_drm_sync_queue set status= ? where refresh_id= ?"); 
            preparedStatement.setString(1, status );
            preparedStatement.setInt(2, refreshid);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "status of record in queue updated: refid " + refreshid + " status " + status);
        } catch (Exception e) {
            OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName,
                              DRMSyncPropertyV2.getInstance().getLoggerID(), "info",
            "Error in updating record in queue : refid " + refreshid + " status " + status+" Error:"+e.getMessage());


        }
    }
}
