package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncData;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncProperty;

public abstract class SyncPropertyFacade<T> extends AbstractFacade<T> {
    public SyncPropertyFacade(Class<T> entityClass) {
        super(entityClass);
    }


    @SuppressWarnings("unchecked")
    public List<OalegoDrmSyncProperty> getResultsByCriteria(Map<String, Object> criterias, int offset, int limit) {
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery criteriaQuery = queryBuilder.createCriteriaQuery(criterias, criteriaBuilder, OalegoDrmSyncProperty.class);

        return getEntityManager().createQuery(criteriaQuery)
                                 .setFirstResult(offset)
                                 .setMaxResults(limit)
                                 .getResultList();
    }
         
    public String updateSyncPropertyHelper(OalegoDrmSyncProperty[] testCategories) {
        for(OalegoDrmSyncProperty testCategory : testCategories){
            getEntityManager().merge(testCategory);
            getEntityManager().flush();
            getEntityManager().clear();
        }
        return "Success";
    }
    
    
    public String postSyncPropertiesHelper(OalegoDrmSyncProperty[] properties) {
        for(OalegoDrmSyncProperty property : properties){
            getEntityManager().persist(property);
            getEntityManager().flush();
            getEntityManager().clear();
        }
        return "Success";
    }
    
    public String removeSyncPropertyHelper(String property) {
        try{
            super.remove(super.find(property));
            return "Success";
        }
        catch(Exception e){
            return "Failed";
        }
        
        
    }
    
    

}