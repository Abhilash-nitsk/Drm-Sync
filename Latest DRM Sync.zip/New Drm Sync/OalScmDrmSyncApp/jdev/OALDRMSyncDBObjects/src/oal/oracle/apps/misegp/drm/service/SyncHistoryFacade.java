package oal.oracle.apps.misegp.drm.service;

import java.util.List;

import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;

import javax.persistence.criteria.CriteriaQuery;

import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncHistory;


public abstract class SyncHistoryFacade<T> extends AbstractFacade<T> {
    public SyncHistoryFacade(Class<T> entityClass) {
        super(entityClass);
    }


    @SuppressWarnings("unchecked")
    public List<OalegoDrmSyncHistory> getResultsByCriteria(Map<String, Object> criterias, int offset, int limit) {
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery criteriaQuery = queryBuilder.createCriteriaQuery(criterias, criteriaBuilder, OalegoDrmSyncHistory.class);

        return getEntityManager().createQuery(criteriaQuery)
                                 .setFirstResult(offset)
                                 .setMaxResults(limit)
                                 .getResultList();
    }
         
    public String updateSyncHistoryHelper(OalegoDrmSyncHistory[] testCategories) {
        for(OalegoDrmSyncHistory testCategory : testCategories){
            getEntityManager().merge(testCategory);
            getEntityManager().flush();
            getEntityManager().clear();
        }
        return "Success";
    }
    
    
    public String postSyncHistoryHelper(OalegoDrmSyncHistory[] properties) {
        for(OalegoDrmSyncHistory property : properties){
            getEntityManager().persist(property);
            getEntityManager().flush();
            getEntityManager().clear();
        }
        return "Success";
    }
    
    public String removeSyncHistoryHelper(String property) {
        try{
            super.remove(super.find(property));
            return "Success";
        }
        catch(Exception e){
            return "Failed";
        }
        
        
    }
    
    

}