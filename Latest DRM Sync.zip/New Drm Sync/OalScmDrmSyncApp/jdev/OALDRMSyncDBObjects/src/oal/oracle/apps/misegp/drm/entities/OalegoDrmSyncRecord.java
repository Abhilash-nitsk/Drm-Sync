package oal.oracle.apps.misegp.drm.entities;

import java.io.Serializable;

import java.math.BigDecimal;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({ @NamedQuery(name = "OalegoDrmSyncRecord.findAll", query = "select o from OalegoDrmSyncRecord o") })
@Table(name = "OALEGO_DRM_SYNC_RECORD")
public class OalegoDrmSyncRecord implements Serializable {
    @Id
    @Column(name="ROWID")
    String rowid;
    
    
    private static final long serialVersionUID = 6229501427467211555L;
    @Column(name = "CATALOG_CODE", length = 20)
    private String catalogCode;
    @Column(name = "CATALOG_NAME", length = 20)
    private String catalogName;
    @Column(name = "COMPLETED_TIME_STAMP")
    private Timestamp completedTimeStamp;
    @Column(name = "ERRORED_CAT")
    private BigDecimal erroredCat;
    @Column(name = "MAX_DEPTH")
    private BigDecimal maxDepth;
    @Column(name = "NOTIFIED_TIME_STAMP")
    private Timestamp notifiedTimeStamp;
    @Column(name = "PROCESSED_CAT")
    private BigDecimal processedCat;
    @Column(name = "REFRESH_ID")
    private BigDecimal refreshId;
    @Column(name = "START_TIME_STAMP")
    private Timestamp startTimeStamp;
    @Column(length = 7)
    private String status;
    @Column(name = "UNPROCESSED_CAT")
    private BigDecimal unprocessedCat;

    public OalegoDrmSyncRecord() {
    }

    public OalegoDrmSyncRecord(String catalogCode, String catalogName, Timestamp completedTimeStamp,
                               BigDecimal erroredCat, BigDecimal maxDepth, Timestamp notifiedTimeStamp,
                               BigDecimal processedCat, BigDecimal refreshId, Timestamp startTimeStamp, String status,
                               BigDecimal unprocessedCat) {
        this.catalogCode = catalogCode;
        this.catalogName = catalogName;
        this.completedTimeStamp = completedTimeStamp;
        this.erroredCat = erroredCat;
        this.maxDepth = maxDepth;
        this.notifiedTimeStamp = notifiedTimeStamp;
        this.processedCat = processedCat;
        this.refreshId = refreshId;
        this.startTimeStamp = startTimeStamp;
        this.status = status;
        this.unprocessedCat = unprocessedCat;
    }

    public String getCatalogCode() {
        return catalogCode;
    }

    public void setCatalogCode(String catalogCode) {
        this.catalogCode = catalogCode;
    }

    public String getCatalogName() {
        return catalogName;
    }

    public void setCatalogName(String catalogName) {
        this.catalogName = catalogName;
    }

    public Timestamp getCompletedTimeStamp() {
        return completedTimeStamp;
    }

    public void setCompletedTimeStamp(Timestamp completedTimeStamp) {
        this.completedTimeStamp = completedTimeStamp;
    }

    public BigDecimal getErroredCat() {
        return erroredCat;
    }

    public void setErroredCat(BigDecimal erroredCat) {
        this.erroredCat = erroredCat;
    }

    public BigDecimal getMaxDepth() {
        return maxDepth;
    }

    public void setMaxDepth(BigDecimal maxDepth) {
        this.maxDepth = maxDepth;
    }

    public Timestamp getNotifiedTimeStamp() {
        return notifiedTimeStamp;
    }

    public void setNotifiedTimeStamp(Timestamp notifiedTimeStamp) {
        this.notifiedTimeStamp = notifiedTimeStamp;
    }

    public BigDecimal getProcessedCat() {
        return processedCat;
    }

    public void setProcessedCat(BigDecimal processedCat) {
        this.processedCat = processedCat;
    }

    public BigDecimal getRefreshId() {
        return refreshId;
    }

    public void setRefreshId(BigDecimal refreshId) {
        this.refreshId = refreshId;
    }

    public Timestamp getStartTimeStamp() {
        return startTimeStamp;
    }

    public void setStartTimeStamp(Timestamp startTimeStamp) {
        this.startTimeStamp = startTimeStamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getUnprocessedCat() {
        return unprocessedCat;
    }

    public void setUnprocessedCat(BigDecimal unprocessedCat) {
        this.unprocessedCat = unprocessedCat;
    }
}
