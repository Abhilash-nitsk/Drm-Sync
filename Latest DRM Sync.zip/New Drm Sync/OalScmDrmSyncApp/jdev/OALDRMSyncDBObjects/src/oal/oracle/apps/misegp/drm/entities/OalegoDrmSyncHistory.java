package oal.oracle.apps.misegp.drm.entities;

import java.io.Serializable;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({ @NamedQuery(name = "OalegoDrmSyncHistory.findAll", query = "select o from OalegoDrmSyncHistory o") })
@Table(name = "OALEGO_DRM_SYNC_HISTORY")
public class OalegoDrmSyncHistory implements Serializable {
    private static final long serialVersionUID = 4391615792242983009L;
    @Column(name = "CATALOG_CODE", length = 20)
    private String catalogCode;
    @Column(name = "CATEGORY_CODE", length = 20)
    private String categoryCode;
    @Column(name = "CATEGORY_DESC", length = 20)
    private String categoryDesc;
    @Column(name = "CATEGORY_NAME", length = 20)
    private String categoryName;
    @Column(name = "DISABLE_FLAG", length = 10)
    private String disableFlag;
    @Column(name = "END_DATE", length = 20)
    private String endDate;
    @Column(name = "IS_LEAF", length = 10)
    private String isLeaf;
    private BigDecimal levl;
    @Column(name = "PARENT_CATEGORY_CODE", length = 20)
    private String parentCategoryCode;
    @Column(name = "PROCESSED_FLAG", length = 10)
    private String processedFlag;
    @Column(name = "REFRESH_ID")
    private BigDecimal refreshId;
    @Column(name = "START_DATE", length = 20)
    private String startDate;
    @Id
    @Column(name = "UNIQUE_ROW_ID", nullable = false)
    private BigDecimal uniqueRowId;

    public OalegoDrmSyncHistory() {
    }

    public OalegoDrmSyncHistory(String catalogCode, String categoryCode, String categoryDesc, String categoryName,
                                String disableFlag, String endDate, String isLeaf, BigDecimal levl,
                                String parentCategoryCode, String processedFlag, BigDecimal refreshId, String startDate,
                                BigDecimal uniqueRowId) {
        this.catalogCode = catalogCode;
        this.categoryCode = categoryCode;
        this.categoryDesc = categoryDesc;
        this.categoryName = categoryName;
        this.disableFlag = disableFlag;
        this.endDate = endDate;
        this.isLeaf = isLeaf;
        this.levl = levl;
        this.parentCategoryCode = parentCategoryCode;
        this.processedFlag = processedFlag;
        this.refreshId = refreshId;
        this.startDate = startDate;
        this.uniqueRowId = uniqueRowId;
    }

    public String getCatalogCode() {
        return catalogCode;
    }

    public void setCatalogCode(String catalogCode) {
        this.catalogCode = catalogCode;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getCategoryDesc() {
        return categoryDesc;
    }

    public void setCategoryDesc(String categoryDesc) {
        this.categoryDesc = categoryDesc;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDisableFlag() {
        return disableFlag;
    }

    public void setDisableFlag(String disableFlag) {
        this.disableFlag = disableFlag;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getIsLeaf() {
        return isLeaf;
    }

    public void setIsLeaf(String isLeaf) {
        this.isLeaf = isLeaf;
    }

    public BigDecimal getLevl() {
        return levl;
    }

    public void setLevl(BigDecimal levl) {
        this.levl = levl;
    }

    public String getParentCategoryCode() {
        return parentCategoryCode;
    }

    public void setParentCategoryCode(String parentCategoryCode) {
        this.parentCategoryCode = parentCategoryCode;
    }

    public String getProcessedFlag() {
        return processedFlag;
    }

    public void setProcessedFlag(String processedFlag) {
        this.processedFlag = processedFlag;
    }

    public BigDecimal getRefreshId() {
        return refreshId;
    }

    public void setRefreshId(BigDecimal refreshId) {
        this.refreshId = refreshId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getUniqueRowId() {
        return uniqueRowId;
    }

    public void setUniqueRowId(BigDecimal uniqueRowId) {
        this.uniqueRowId = uniqueRowId;
    }
}
