package oal.oracle.apps.misegp.drm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({ @NamedQuery(name = "OalegoDrmSyncProperty.findAll", query = "select o from OalegoDrmSyncProperty o") })
@Table(name = "OALEGO_DRM_SYNC_PROPERTY")
public class OalegoDrmSyncProperty implements Serializable {
    private static final long serialVersionUID = 9071915538039499626L;
    @Id
    @Column(nullable = false, length = 200)
    private String key;
    @Column(length = 200)
    private String value;

    public OalegoDrmSyncProperty() {
    }

    public OalegoDrmSyncProperty(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
