package oal.oracle.apps.misegp.drm.entities;

import java.io.Serializable;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({ @NamedQuery(name = "OalegoDrmSyncQueue.findAll", query = "select o from OalegoDrmSyncQueue o") })
@Table(name = "OALEGO_DRM_SYNC_QUEUE")
public class OalegoDrmSyncQueue implements Serializable {
    private static final long serialVersionUID = 2324349599770677704L;

    @Id    
    @Column(name = "QUEUE_NO", nullable = false)
    private BigDecimal queueNo;
    @Column(name = "REFRESH_ID")
    private BigDecimal refreshId;
    @Column(length = 50)
    private String status;

    public OalegoDrmSyncQueue() {
    }

    public OalegoDrmSyncQueue(BigDecimal queueNo, BigDecimal refreshId, String status) {
        this.queueNo = queueNo;
        this.refreshId = refreshId;
        this.status = status;
    }

    public BigDecimal getQueueNo() {
        return queueNo;
    }

    public void setQueueNo(BigDecimal queueNo) {
        this.queueNo = queueNo;
    }

    public BigDecimal getRefreshId() {
        return refreshId;
    }

    public void setRefreshId(BigDecimal refreshId) {
        this.refreshId = refreshId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
