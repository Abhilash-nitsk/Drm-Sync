package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncRecord;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;

@Stateless
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
@Path("SyncRecord")
public class SyncRecordService extends SyncRecordFacade<OalegoDrmSyncRecord> {
    
    public SyncRecordService() {
        super(OalegoDrmSyncRecord.class);
    }

    @PersistenceContext(unitName = "Model")
    private EntityManager em;

    @GET
    @Produces("application/json")
    @Path("/getSyncRecord")
    public Response getAllSyncRecord(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            List<OalegoDrmSyncRecord> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncRecord>> entities = new GenericEntity<List<OalegoDrmSyncRecord>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @GET
    @Produces("application/json")
    @Path("/getSyncRecord/{refreshId}")
    public Response getSyncRecord(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @PathParam("refreshId") String refreshId, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("refreshId",refreshId);
            List<OalegoDrmSyncRecord> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncRecord>> entities = new GenericEntity<List<OalegoDrmSyncRecord>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateSyncRecord")
    public Response updateSyncRecord(OalegoDrmSyncRecord[] record,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        try{
            String result = updateSyncRecordHelper(record);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @POST
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/postSyncRecord")
    public Response postSyncRecord(OalegoDrmSyncRecord[] record,
                                       @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try{
            String result = postSyncRecordHelper(record);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @DELETE

    @Path("/removeSyncRecord")
    public Response removeSyncRecord(@QueryParam("refreshId") BigDecimal refreshId,@QueryParam("catalogCode") String catalogCode, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            String query="delete from OALSCM.OALEGO_DRM_SYNC_RECORD where refresh_id= ? and Catalog_code= ?";
            Query nativeQuery = getEntityManager().createNativeQuery(query);
            nativeQuery.setParameter(1,refreshId );
            nativeQuery.setParameter(2,catalogCode );

            nativeQuery.executeUpdate();
            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    
    
    
    
    
    
    
 @Override
    protected EntityManager getEntityManager() {
        // TODO Implement this method
        return em;
    }
}


