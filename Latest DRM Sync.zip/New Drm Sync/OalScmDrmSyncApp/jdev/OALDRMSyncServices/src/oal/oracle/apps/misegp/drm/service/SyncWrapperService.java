package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import javax.ejb.Stateless;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import java.util.HashMap;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import javax.ws.rs.core.Response;

import oal.oracle.apps.misegp.drm.helper.AuthHelper;
import oal.oracle.apps.scm.drm.AssociateItem;
import oal.oracle.apps.scm.drm.CategorySyncSaasToStage;
import oal.oracle.apps.scm.drm.DRMDataSync;
import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;
import oal.oracle.apps.scm.drm.KeyStoreAccessor;

@Stateless
@Path("Wrapper")
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
public class SyncWrapperService {
    public SyncWrapperService() {
    }


    
    @GET
    @Path("/getKeyStoreCredentials/{map}/{key}")
    public Response checkCredentialStore(@HeaderParam("authorization") String authString,@PathParam("map") String map,
                                         @PathParam("key") String key) {
    
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
    
        return Response.status(Response.Status.OK)
                       .entity(KeyStoreAccessor.getInstance().getUserName(map,key))
                       .build();
    }
/**
     * Async Service to invoke DRM Sync
     * @return
     */
    @GET
    @Path("/syncCategories")
    public Response syncData(@HeaderParam("authorization") String authString) {
    
        if (!AuthHelper.isAuthorizedUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try {

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        new DRMDataSync().sync();
                    } catch (Exception e) {
                    }
                }
            }, "1");
            t.start();
           
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity("Failed due to " + e.getStackTrace().toString())
                           .build();
             
        }
        return Response.status(Response.Status.OK)
                       .entity("Success")
                       .build();
    }
}
