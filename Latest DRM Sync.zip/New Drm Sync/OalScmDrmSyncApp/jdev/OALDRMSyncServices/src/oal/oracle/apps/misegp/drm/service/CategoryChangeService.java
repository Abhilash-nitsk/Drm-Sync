package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.GenericEntity;


import javax.ws.rs.core.Response;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmDataChange;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncData;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;
import oal.oracle.apps.misegp.drm.helper.CommonUtil;
import oal.oracle.apps.misegp.drm.queries.DBQueries;

import org.json.JSONArray;
import org.json.JSONObject;


@Stateless
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
@Path("categoryChange")
public class CategoryChangeService extends CategoryChangeFacade<OalegoDrmDataChange> {
    
    public CategoryChangeService() {
        super(OalegoDrmDataChange.class);
    }

    @PersistenceContext(unitName = "Model")
    private EntityManager em;

    @GET
    @Path("/getChangedCategories")
    @Produces({"application/xml","application/json"})
    

    public Response getCategories(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit,
                                  @QueryParam("catalogCode") String catalogCode, @QueryParam("levl") String levl,
                                  @QueryParam("refreshId") String refreshId, @QueryParam("isLeaf") String isLeaf,
                                  @HeaderParam("authorization") String authString
                                                                  ) {
        if(!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
            return Response.status(Response.Status.UNAUTHORIZED)
                              .entity("User Not Authorized")
                              .build();
            
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("catalogCode",catalogCode);
            map.put("levl",levl);
            map.put("refreshId",refreshId);
            if(isLeaf!=null)
                map.put("isLeaf",isLeaf);
            List<OalegoDrmDataChange> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmDataChange>> entities = new GenericEntity<List<OalegoDrmDataChange>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }

    @GET
    @Path("/getChangedCategories/{refreshId}/catalogCode/{catalogCode}")
    @Produces({"application/xml","application/json"})

    
    public Response getCategoriesForSync(@PathParam("refreshId") String refreshId,
    @PathParam("catalogCode") String catalogCode,
    @QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit,
                                  @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("refreshId",refreshId);
            map.put("catalogCode",catalogCode);
            List<OalegoDrmDataChange> results = getResultsByCriteria(map, offset, limit);
    
            GenericEntity<List<OalegoDrmDataChange>> entities = new GenericEntity<List<OalegoDrmDataChange>>(results) {
            };
            return Response.status(Response.Status.OK)
                           .entity(entities)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }

    }

    @PUT
    @Consumes("application/json")
    @Produces("text/plain")
    @Path("/deleteProcessed")
    public Response deleteProcessed(String jsonStr, @QueryParam("refreshId") BigDecimal refreshId,
                                    @QueryParam("catalogCode") String catalogCode,
                                    @HeaderParam("authorization") String authString ) throws JSONException {
       
        if(!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                
                return Response.status(Response.Status.UNAUTHORIZED)
                              .entity("User Not Authorized")
                              .build();
            
        }
        try{
            JSONObject obj = new JSONObject(jsonStr);
            JSONArray arr = obj.getJSONArray("categories");
            String categoryCodes=CommonUtil.getCommaSeperatedStringFromJSONArray(arr);
            String query = "delete from ? where refresh_id= ? and catalog_code = ? and category_code in (%s)";
            String formattedQuery = String.format(query,categoryCodes);
            Query nativeQuery = getEntityManager().createNativeQuery(formattedQuery);
            nativeQuery.setParameter(1,DBQueries.getDeltaTable() );
            nativeQuery.setParameter(2,refreshId );
            nativeQuery.setParameter(3,catalogCode );

            nativeQuery.executeUpdate();
            
            return Response.status(Response.Status.OK)
                                  .entity("Success")
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateCategoryChange")
    public Response updateCategoryChange(OalegoDrmDataChange[] categories,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        try{
            String result = updateCategoryChangeHelper(categories);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @POST
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/postCategoryChange")
    public Response postCategoryChange(OalegoDrmDataChange[] categories,
                                       @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try{
            String result = postCategoryChangeHelper(categories);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    @DELETE
    
    @Path("/removeCatChange")
    public Response removeSyncQueue( @QueryParam("uniqueRowId") BigDecimal uniqueRowId, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            super.remove(super.find(uniqueRowId));
            return Response.status(Response.Status.OK)
                           .entity("Success")
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @DELETE
    
    @Path("/removeCatChangeCategoryCode")
    public Response removeSyncRecord(@QueryParam("refreshId") BigDecimal refreshId,@QueryParam("catalogCode") String catalogCode,@QueryParam("categoryCode") String categoryCode, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            String query="delete from OALSCM.OALEGO_DRM_DATA_CHANGE where category_code = ? and refresh_id= ? and Catalog_code= ?";
            Query nativeQuery = getEntityManager().createNativeQuery(query);
            nativeQuery.setParameter(1,categoryCode );
            nativeQuery.setParameter(2,refreshId );
            nativeQuery.setParameter(3,catalogCode );

            nativeQuery.executeUpdate();
            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }

    
    //Trying the API for BULK Delete
    
    @DELETE

    @Path("/removeCategoryBulk/{refreshId}")
    public Response removeSyncBulk(@PathParam("refreshId") String refreshId,@HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            String query="delete from OALSCM.OALEGO_DRM_DATA_CHANGE where refresh_id= ?";
            Query nativeQuery = getEntityManager().createNativeQuery(query);
            nativeQuery.setParameter(1,refreshId );
            nativeQuery.executeUpdate();
            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @Override
    protected EntityManager getEntityManager() {
        // TODO Implement this method
        return em;
    }
}
