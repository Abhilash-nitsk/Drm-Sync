package oal.oracle.apps.misegp.drm.service;


import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("service")
public class ApplicationConfig extends Application {
    public ApplicationConfig() {
        super();
    }

    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();

        // Register root resources.
        classes.add(SyncWrapperService.class);
        classes.add(CategoryService.class);
        classes.add(CategoryChangeService.class);
        classes.add(SyncPropertyService.class);
        classes.add(SyncQueueService.class);
        classes.add(SyncHistoryService.class);
        classes.add(SyncRecordService.class);



        // Register provider classes.

        return classes;
    }
}
