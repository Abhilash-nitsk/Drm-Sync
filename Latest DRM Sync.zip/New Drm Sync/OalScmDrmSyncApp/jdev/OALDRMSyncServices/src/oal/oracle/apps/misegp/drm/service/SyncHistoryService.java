package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncHistory;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;

@Stateless
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
@Path("SyncHistory")
public class SyncHistoryService extends SyncHistoryFacade<OalegoDrmSyncHistory> {
    
    public SyncHistoryService() {
        super(OalegoDrmSyncHistory.class);
    }

    @PersistenceContext(unitName = "Model")
    private EntityManager em;

    @GET
    @Produces("application/json")
    @Path("/getSyncHistory")
    public Response getAllSyncHistory(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            List<OalegoDrmSyncHistory> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncHistory>> entities = new GenericEntity<List<OalegoDrmSyncHistory>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @GET
    @Produces("application/json")
    @Path("/getSyncHistory/{refreshId}")
    public Response getSyncHistoryRefresh(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @PathParam("refreshId") String refreshId, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("refreshId",refreshId);
            List<OalegoDrmSyncHistory> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncHistory>> entities = new GenericEntity<List<OalegoDrmSyncHistory>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @GET
    @Produces("application/json")
    @Path("/getSyncHistory/{refreshId}/catalogCode/{catalogCode}")
    public Response getSyncHistoryRefCatalog(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @PathParam("refreshId") String refreshId, @PathParam("catalogCode") String catalogCode, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("refreshId",refreshId);
            map.put("catalogCode",catalogCode);
            List<OalegoDrmSyncHistory> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncHistory>> entities = new GenericEntity<List<OalegoDrmSyncHistory>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateSyncHistory")
    public Response updateSyncHistory(OalegoDrmSyncHistory[] history,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
        }
        try{
            String result = updateSyncHistoryHelper(history);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @POST
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/postSyncHistory")
    public Response postSyncHistory(OalegoDrmSyncHistory[] history,
                                       @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try{
            String result = postSyncHistoryHelper(history);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    @DELETE
    @Path("/removeSyncHistoryRowID")
    public Response removeSyncProperty( @QueryParam("UniqueRow") BigDecimal uniqueRow, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            super.remove(super.find(uniqueRow));
            return Response.status(Response.Status.OK)
                           .entity("Success")
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @DELETE

    @Path("/removeHistory/{refreshId}/catalogCode/{catalogCode}/categoryCode/{categoryCode}")
    public Response removeHistoryUnique( @PathParam("categoryCode") String categoryCode,@PathParam("refreshId") BigDecimal refreshId,@PathParam("catalogCode") String catalogCode, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            String query="delete from OALSCM.OALEGO_DRM_SYNC_HISTORY where category_code = ? and refresh_id= ? and Catalog_code= ?";
            Query nativeQuery = getEntityManager().createNativeQuery(query);
            nativeQuery.setParameter(1,categoryCode );
            nativeQuery.setParameter(2,refreshId );
            nativeQuery.setParameter(3,catalogCode );

            nativeQuery.executeUpdate();
            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity(String.valueOf("Failed Unauthorized"))
                           .build(); 
        }
    }
    
    
 @Override
    protected EntityManager getEntityManager() {
        // TODO Implement this method
        return em;
    }
}

