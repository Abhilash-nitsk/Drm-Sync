package oal.oracle.apps.misegp.drm.helper;

import org.json.JSONArray;
import org.json.JSONException;

public class CommonUtil {
    public CommonUtil() {
        super();
    }
    public static String getCommaSeperatedStringFromJSONArray(JSONArray arr) throws JSONException {
        if(arr.length()==0)
            return "";
       StringBuilder sb=new StringBuilder();
        for (int i = 0; i < arr.length(); i++) {
            sb.append("'");
            sb.append(arr.getString(i));
            sb.append("'");
            sb.append(",");
        }

        sb.setLength(sb.length() - 1);
        return sb.toString();
    }

}
