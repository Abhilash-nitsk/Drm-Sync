package oal.oracle.apps.misegp.drm.service;

import com.rsa.jcm.c.bb;

import java.lang.reflect.Field;

import java.math.BigDecimal;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;

import javax.naming.NamingException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.Query;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;

import javax.ws.rs.core.Response;

import oal.oracle.apps.misegp.drm.entities.OalegoDrmDataChange;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncData;


import oal.oracle.apps.misegp.drm.helper.AuthHelper;
import oal.oracle.apps.misegp.drm.helper.CommonUtil;
import oal.oracle.apps.misegp.drm.queries.DBQueries;

import org.json.JSONObject;

import oal.oracle.apps.misegp.drm.utils.StringUtils;

import oal.oracle.apps.scm.drm.ConnectionUtil;
import oal.oracle.apps.scm.drm.DRMResultPublisher;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;

import org.json.JSONArray;
import org.json.JSONException;

@Stateless
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
@Path("category")
public class CategoryService extends CategoryFacade<OalegoDrmSyncData> {
    public CategoryService() {
        super(OalegoDrmSyncData.class);
    }

    @PersistenceContext(unitName = "Model")
    private EntityManager em;

    

    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getCategories")
    public Response getCategories(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit,
                                  @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        Map<String, Object> map = new HashMap<String, Object>();
        List<OalegoDrmSyncData> results = getResultsByCriteria(map, offset, limit);

        GenericEntity<List<OalegoDrmSyncData>> entities = new GenericEntity<List<OalegoDrmSyncData>>(results) {
        };
        return Response.status(Response.Status.OK)
                       .entity(entities)
                       .build();

    }


    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getCategories/{refreshId}/catalogCode/{catalogCode}")
    public Response getCategoriesPerRefId(@PathParam("refreshId") String refreshId,
    @PathParam("catalogCode") String catalogCode,
    @QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit,
                                  @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("refreshId",refreshId);
        map.put("catalogCode",catalogCode);
        List<OalegoDrmSyncData> results = getResultsByCriteria(map, offset, limit);

        GenericEntity<List<OalegoDrmSyncData>> entities = new GenericEntity<List<OalegoDrmSyncData>>(results) {
        };
        return Response.status(Response.Status.OK)
                       .entity(entities)
                       .build();

    }
    
    
    
    
    
    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getErroredCategories/{refreshId}/catalogCode/{catalogCode}")
    public Response getErroredCategories(@PathParam("refreshId") String refreshId,
    @PathParam("catalogCode") String catalogCode,
    @QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit,
                                  @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("refreshId",refreshId);
        map.put("catalogCode",catalogCode);
        map.put("processedFlag", "E");
        List<OalegoDrmSyncData> results = getResultsByCriteria(map, offset, limit);

        GenericEntity<List<OalegoDrmSyncData>> entities = new GenericEntity<List<OalegoDrmSyncData>>(results) {
        };
        return Response.status(Response.Status.OK)
                       .entity(entities)
                       .build();

    }
    
    
    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getCategories/{refreshId}/catalogCode/{catalogCode}/level/{level}")
    public Response getCategoriesPerLevel(@PathParam("refreshId") String refreshId,
    @PathParam("catalogCode") String catalogCode,
    @PathParam("level") String level,
    @QueryParam("offset") @DefaultValue("0") Integer offset,
                                      @QueryParam("limit") @DefaultValue("100") Integer limit,
                                  @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("refreshId",refreshId);
        map.put("catalogCode",catalogCode);
        map.put("levl",level);
        List<OalegoDrmSyncData> results = getResultsByCriteria(map, offset, limit);

        GenericEntity<List<OalegoDrmSyncData>> entities = new GenericEntity<List<OalegoDrmSyncData>>(results) {
        };
        return Response.status(Response.Status.OK)
                       .entity(entities)
                       .build();

    }

    //Rest API to Post the Categories in the PAAS Staging table
    @POST
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/postCategories")
    public Response postCategoriesList(OalegoDrmSyncData[] categories, @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           

                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        String result = postCategories(categories);
        return Response.status(Response.Status.OK)
                       .entity(result)
                       .build();
    }
    
    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateCategories")
    public Response updateCategories(OalegoDrmSyncData[] categories,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        String result = updateCategoriesHelper(categories);
        return Response.status(Response.Status.OK)
                       .entity(result)
                       .build();
    }
    
    
    

    //Rest API to update the categories from the paas DB
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateProcessed")
    public Response updateProcessed(OalegoDrmSyncData[] categories,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }

        String result = updateProcessedHelper(categories);
        return Response.status(Response.Status.OK)
                       .entity(result)
                       .build();
    }

    //Rest API to update the categories from the paas DB
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateProcessedFlag")
    public Response updateProcessedFlag(String jsonStr , @QueryParam("refreshId") BigDecimal refreshId,
                                        @QueryParam("catalogCode") String catalogCode,
                                        @QueryParam("processedFlag") String processedFlag,
                                        @HeaderParam("authorization") String authString) throws JSONException {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        JSONObject obj = new JSONObject(jsonStr);
        JSONArray arr = obj.getJSONArray("categories");
        String categoryCodes=CommonUtil.getCommaSeperatedStringFromJSONArray(arr);
        String query = DBQueries.updateProcessedFlag(processedFlag, String.valueOf(refreshId), catalogCode);
        String formattedQuery = String.format(query, categoryCodes);
        Query nativeQuery = getEntityManager().createNativeQuery(formattedQuery);
        nativeQuery.executeUpdate();
        return Response.status(Response.Status.OK)
                       .entity("Success")
                       .build();
    }

    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateItemProcessedFlag")
    public Response updateItemProcessedFlag(String jsonStr, @QueryParam("refreshId") BigDecimal refreshId,
                                            @QueryParam("catalogCode") String catalogCode,
                                            @QueryParam("itemAssociation") String itemAssociation,
                                            @HeaderParam("authorization") String authString) throws JSONException {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
         
        }
        JSONObject obj = new JSONObject(jsonStr);
        JSONArray arr = obj.getJSONArray("categories");
        String categoryCodes=CommonUtil.getCommaSeperatedStringFromJSONArray(arr);
        String query = DBQueries.updateItemAssociation(itemAssociation, String.valueOf(refreshId), catalogCode);
        String formattedQuery = String.format(query, categoryCodes);
        Query nativeQuery = getEntityManager().createNativeQuery(formattedQuery);
        nativeQuery.executeUpdate();
        return Response.status(Response.Status.OK)
                       .entity("Success")
                       .build();
    }


    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateComments")
    public Response updateComments(String jsonStr, @QueryParam("refreshId") BigDecimal refreshId,
                                   @QueryParam("catalogCode") String catalogCode,
                                   @QueryParam("categoryCode") String categoryCode,
                                   @HeaderParam("authorization") String authString) throws JSONException {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        JSONObject comments = new JSONObject(jsonStr);
        String formattedQuery = DBQueries.updateComments(comments.getString("comment"), refreshId, catalogCode, categoryCode);
        Query nativeQuery = getEntityManager().createNativeQuery(formattedQuery);
        nativeQuery.executeUpdate();
        return Response.status(Response.Status.OK)
                       .entity("Success")
                       .build();
    }


    //Rest API to find the given category from the paas DB
    @GET
    @Produces({"application/xml","application/json"})
    @Path("/findCategory")
    public Response findCategories(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                   @QueryParam("limit") @DefaultValue("100") Integer limit,
                                   @QueryParam("categoryCode") String categoryCode,
                                   @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("categoryCode", categoryCode);
        List<OalegoDrmSyncData> results = getResultsByCriteria(map, offset, limit);
        GenericEntity<List<OalegoDrmSyncData>> entities = new GenericEntity<List<OalegoDrmSyncData>>(results) {
        };
        return Response.status(Response.Status.OK)
                       .entity(entities)
                       .build();

    }

    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getCategoryCount")
    public Response getCategoryCount(@QueryParam("catalogCode") String catalogCode, @QueryParam("levl") String levl,
                                     @QueryParam("refreshId") String refreshId,
                                     @QueryParam("processedFlag") String processedFlag,
                                     @HeaderParam("authorization") String authString) {
        
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
		String query = DBQueries.getCategoryCountOnlyDelta(processedFlag, refreshId, catalogCode, levl);
        Query nativeQuery = getEntityManager().createNativeQuery(query);
        Object result = nativeQuery.getSingleResult();
        return Response.status(Response.Status.OK)
                       .entity(String.valueOf(result))
                       .build();
    }

    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getItemCount")
    public Response getItemCount(@QueryParam("catalogCode") String catalogCode, @QueryParam("levl") String levl,
                                 @QueryParam("refreshId") String refreshId,
                                 @QueryParam("itemAssociation") String itemAssociation,
                                 @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        String query = DBQueries.getItemCount(itemAssociation, refreshId, catalogCode, levl);
        Query nativeQuery = getEntityManager().createNativeQuery(query);
        Object result = nativeQuery.getSingleResult();
        return Response.status(Response.Status.OK)
                       .entity(String.valueOf(result))
                       .build();
    }

    //REST API to get all the categories based on the given catalog
    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getCategoryCatalog")
    public Response getCategoryCatalog(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                       @QueryParam("limit") @DefaultValue("100") Integer limit,
                                       @QueryParam("catalogCode") String catalogCode, @QueryParam("levl") String levl,
                                       @QueryParam("refreshId") String refreshId,
                                       @QueryParam("processedFlag") String processedFlag,
                                       @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
          
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("catalogCode", catalogCode);
        map.put("levl", levl);
        map.put("processedFlag", processedFlag);
        map.put("refreshId", refreshId);


        List<OalegoDrmSyncData> results = getResultsByCriteria(map, offset, limit);
        GenericEntity<List<OalegoDrmSyncData>> entities = new GenericEntity<List<OalegoDrmSyncData>>(results) {
        };
        return Response.status(Response.Status.OK)
                       .entity(entities)
                       .build();
    }

    @GET
    @Produces({"application/xml","application/json"})
    @Path("/getMaxLevel")
    public Response getMaxlevel(@QueryParam("catalogCode") String catalogCode,
                                @QueryParam("refreshId") String refreshId,
                                @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }

        String query = DBQueries.GET_MAX_LEVEL_FROM_CATALOG;
        String formattedQuery = String.format(query, catalogCode, refreshId);
        Query nativeQuery =
            getEntityManager().createNativeQuery(formattedQuery, OalegoDrmSyncData.class.getSimpleName());
        List<Object[]> result = nativeQuery.getResultList();
        try {
            return Response.status(Response.Status.OK)
                           .entity(result.get(0)[0].toString())
                           .build();


        } catch (Exception e) {
            return Response.status(Response.Status.OK)
                           .entity("0")
                           .build();
        }

    }


    @POST
    @Consumes("application/json")
    @Produces("text/plain")
    @Path("/getNoOfProcessedCatgories")
    public Response getNoOfProcessedCatgories(String jsonStr, @QueryParam("refreshId") BigDecimal refreshId,
                                              @QueryParam("catalogCode") String catalogCode,
                                              @HeaderParam("authorization") String authString) throws JSONException {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
           
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        JSONObject obj = new JSONObject(jsonStr);        
        JSONArray arr = obj.getJSONArray("categories");
        String categoryCodes=CommonUtil.getCommaSeperatedStringFromJSONArray(arr);
        String query = DBQueries.getNoofcategories(String.valueOf(refreshId), catalogCode);
        String formattedQuery = String.format(query, categoryCodes);
        Query nativeQuery = getEntityManager().createNativeQuery(formattedQuery);
        Object result = nativeQuery.getSingleResult();
        return Response.status(Response.Status.OK)
                       .entity(String.valueOf(result))
                       .build();

    }

    @POST
    @Consumes("application/json")
    @Produces("text/plain")
    @Path("/getUnProcessedORErroredCatgories")
    public Response getUnProcessedORErroredCatgories(String jsonStr,
                                                     @QueryParam("refreshId") BigDecimal refreshId,
                                                     @QueryParam("catalogCode") String catalogCode,
                                                     @HeaderParam("authorization") String authString) throws JSONException {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        JSONObject obj = new JSONObject(jsonStr);  
        JSONArray arr = obj.getJSONArray("categories");
        String categoryCodes=CommonUtil.getCommaSeperatedStringFromJSONArray(arr);
        String query = DBQueries.getUnprocessedOrErroredCat(refreshId, catalogCode);
        String formattedQuery = String.format(query, categoryCodes);
        Query nativeQuery = getEntityManager().createNativeQuery(formattedQuery);
        Object result = nativeQuery.getSingleResult();

        return Response.status(Response.Status.OK)
                       .entity(String.valueOf(result))
                       .build();

    }


    @DELETE

    @Path("/removeCategory")
    public Response removeCategory( @QueryParam("UniqueRowId") BigDecimal uniqueRowId, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            super.remove(super.find(uniqueRowId));
            return Response.status(Response.Status.OK)
                           .entity("Success")
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    

    
    @DELETE

    @Path("/removeCategoryCategoryCode")
    public Response removeCategoryTest( @QueryParam("categoryCode") String categoryCode,@QueryParam("refreshId") BigDecimal refreshId,@QueryParam("catalogCode") String catalogCode, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            String query="delete from OALSCM.OALEGO_DRM_SYNC_DATA where category_code = ? and refresh_id= ? and Catalog_code= ?";
                        Query nativeQuery = getEntityManager().createNativeQuery(query);
            nativeQuery.setParameter(1,categoryCode );
            nativeQuery.setParameter(2, refreshId);
            nativeQuery.setParameter(3, catalogCode);
            nativeQuery.executeUpdate();
            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @DELETE
   
    @Path("/removeCategoryBulk/{refreshId}")
    public Response removeCategoryBulk( @PathParam("refreshId") BigDecimal refreshId, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
       }
        try{
            String query="delete from OALSCM.OALEGO_DRM_SYNC_DATA where category_code = ? and refresh_id= ? and Catalog_code= ?";
            
            Query nativeQuery = getEntityManager().createNativeQuery(query);

            nativeQuery.executeUpdate();
            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }



    @DELETE

    @Path("/removeCategoryBulkProcedure/{refreshId}")
    public Response removeCategoryBulkProcedure( @PathParam("refreshId") BigDecimal refreshId, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
       }
        try{
           
            runBulkDelete(refreshId);

            return Response.status(Response.Status.OK)
                           .entity(String.valueOf("Success"))
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    public static void runBulkDelete(BigDecimal newRefreshId) throws SQLException, NamingException {
        Connection dbConnection =null;
            try
            {
                dbConnection = ConnectionUtil.getNewConnection();
                PreparedStatement preparedStatement =
                    dbConnection.prepareStatement(DRMSyncPropertyV2.getInstance().getPurgeCategoriesProcedure());
                preparedStatement.setObject(1, newRefreshId);
                preparedStatement.execute();

            }
            catch(Exception e){
            }
            finally{
                if(dbConnection!=null)
                    dbConnection.close();
            }
    }
    

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
