package oal.oracle.apps.misegp.drm.helper;

import com.oracle.cie.domain.jdbc.DBConnection;
import java.util.List;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Set;
import java.util.HashSet;
import java.nio.charset.Charset;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.ws.rs.client.WebTarget;

import javax.ws.rs.core.Response;
import org.junit.Test;

import org.json.JSONArray;

import org.json.JSONObject;

import javax.naming.NamingException;

import javax.ws.rs.client.Client;

import javax.ws.rs.client.ClientBuilder;

import oal.oracle.apps.scm.drm.ConnectionUtil;
import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;
import static org.junit.Assert.assertEquals;
public class AuthHelper {

    public static final String DRM_SUPER_USER = "MISSCM_DRM_SUP_USER_JOB";
    public static final String DRM_USER = "MISSCM_DRM_USER_JOB";
    private static String domainName = "";
    private static Set<String> authorizedSuperUsers=new HashSet();
    
    

    public AuthHelper() {
        super();
    }

     public static boolean isAuthorizedUser(String user) throws NamingException, SQLException {
        ArrayList<String> userRoles = getSaasRoles(user);
        if (userRoles.contains(DRM_USER))
            return true;
        return false;
    }

     public static boolean isAuthorizedSuperUser(String user) throws NamingException, SQLException {
        ArrayList<String> userRoles = getSaasRoles(user);
        if (userRoles.contains(DRM_SUPER_USER))
            return true;
        return false;
    }
    private static String getDomainName() throws NamingException, SQLException {
        
        if(!domainName.isEmpty()) {
            return domainName;
        }
        //need to call method or API to log the statements
        String uri = "";
        Connection con = ConnectionUtil.getNewConnection();
        String query = "select OALFND.OALFND_URL.GET('PAAS_APEX') URI from dual";
        try (
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs != null) {
                while (rs.next()) {
                    uri = rs.getString("URI");
                }
            }

        } catch (SQLException e) {
            uri = "";
            //need to call method or API to log the statements
        } catch (Exception e) {
            uri = "";
            //need to call method or API to log the statements
        }
        finally {
            con.close();
        }
        domainName=uri;
        return uri;
    }
    
    public static boolean isAuthorizedUserAuthString(String authString) {
       String user=getUser(authString);
        try {
            return isAuthorizedUser(user);
        } catch (NamingException | SQLException e) {
            return false;
        }
    }
    public static boolean isAuthorizedSuperUserAuthString(String authString)  {
       if(authorizedSuperUsers.contains(authString))
            return true;
       String user=getUser(authString);
        try {
            boolean isSuperUser=isAuthorizedSuperUser(user);
            if(isSuperUser) {
                authorizedSuperUsers.add(authString);
            }
            return isSuperUser;
        } catch (NamingException | SQLException e) {
            return false;
        }
    }
    
    private static String getUser(String authString) {
        String user = "anonymous";
        if (authString != null && authString.startsWith("Basic")) {
            String base64Credentials = authString.substring("Basic".length()).trim();
            String credentials = new String(Base64.getDecoder().decode(base64Credentials), Charset.forName("UTF-8"));
            final String[] values = credentials.split(":");
            user = values[0];
        }
        return user;
    }

    private static ArrayList<String> getSaasRoles(String user) throws NamingException, SQLException {
       
        String url =getDomainName() + "oalfnd/oalsec/security/store/policies/OALDRMSYNC/" + user;
       
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(url);
        String res = target.request()
                           .get()
                           .readEntity(String.class);
        JSONArray arr = new JSONArray();
        ArrayList<String> roles = new ArrayList<String>();
        try {
            JSONObject jsonObj = new JSONObject(res.toString());
            arr = jsonObj.getJSONArray("items");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject roleObj = arr.getJSONObject(i);
                String r = roleObj.getString("role_common_name");
                roles.add(r);
            }
        } catch (Exception e) {
        }
        return roles;
    }

}
