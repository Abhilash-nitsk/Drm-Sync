package oal.oracle.apps.misegp.drm.helper.test;

import static org.junit.Assert.assertEquals;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;
import org.junit.Test;

public class AuthHelperTest {
    
    
    
    public AuthHelperTest() {
        super();
    }
    @Test
    public void authTest() throws Exception 
    {
        assertEquals(true,AuthHelper.isAuthorizedSuperUser("vikas.vi.yadav@oracle.com"));
        assertEquals(false,AuthHelper.isAuthorizedSuperUser("abc@oracle.com"));
        assertEquals(true,AuthHelper.isAuthorizedUser("vikas.vi.yadav@oracle.com"));
        assertEquals(false,AuthHelper.isAuthorizedUser("abc@oracle.com"));
    }
    
}
