package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncData;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncProperty;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;

@Stateless
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
@Path("SyncProperty")
public class SyncPropertyService extends SyncPropertyFacade<OalegoDrmSyncProperty> {
    
    public SyncPropertyService() {
        super(OalegoDrmSyncProperty.class);
    }

    @PersistenceContext(unitName = "Model")
    private EntityManager em;

    @GET
    @Produces("application/json")
    @Path("/getSyncProperties")
    public Response getAllSyncProperties(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            List<OalegoDrmSyncProperty> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncProperty>> entities = new GenericEntity<List<OalegoDrmSyncProperty>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @GET
    @Produces("application/json")
    @Path("/getSyncProperty")
    public Response getSyncProperty(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @QueryParam("key") String key, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("key",key);
            List<OalegoDrmSyncProperty> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncProperty>> entities = new GenericEntity<List<OalegoDrmSyncProperty>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateSyncProperties")
    public Response updateSyncProperties(OalegoDrmSyncProperty[] properties,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        try{
            String result = updateSyncPropertyHelper(properties);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @POST
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/postSyncProperties")
    public Response postSyncProperties(OalegoDrmSyncProperty[] properties,
                                       @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try{
            String result = postSyncPropertiesHelper(properties);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    @DELETE

    @Path("/removeSyncProperty")
    public Response removeSyncProperty( @QueryParam("key") String key, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            super.remove(super.find(key));
            return Response.status(Response.Status.OK)
                           .entity("Success")
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    
 @Override
    protected EntityManager getEntityManager() {
        // TODO Implement this method
        return em;
    }
}

