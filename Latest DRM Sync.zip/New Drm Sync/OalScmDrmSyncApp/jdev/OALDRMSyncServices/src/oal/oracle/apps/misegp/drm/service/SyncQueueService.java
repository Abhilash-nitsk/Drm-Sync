package oal.oracle.apps.misegp.drm.service;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncHistory;
import oal.oracle.apps.misegp.drm.entities.OalegoDrmSyncQueue;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;

@Stateless
@SuppressWarnings("oracle.jdeveloper.webservice.rest.broken-resource-error")
@Path("SyncQueue")
public class SyncQueueService extends SyncQueueFacade<OalegoDrmSyncQueue> {
    
    public SyncQueueService() {
        super(OalegoDrmSyncQueue.class);
    }

    @PersistenceContext(unitName = "Model")
    private EntityManager em;

    @GET
    @Produces("application/json")
    @Path("/getSyncQueue")
    public Response getAllSyncQueue(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            List<OalegoDrmSyncQueue> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncQueue>> entities = new GenericEntity<List<OalegoDrmSyncQueue>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    @GET
    @Produces("application/json")
    @Path("/getSyncQueueNumber")
    public Response getSyncQueue(@QueryParam("offset") @DefaultValue("0") Integer offset,
                                  @QueryParam("limit") @DefaultValue("100") Integer limit, @QueryParam("queueNo") String queueNo, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("queueNo",queueNo);
            List<OalegoDrmSyncQueue> results = getResultsByCriteria(map, offset, limit);
            GenericEntity<List<OalegoDrmSyncQueue>> entities = new GenericEntity<List<OalegoDrmSyncQueue>>(results){};
            return Response.status(Response.Status.OK)
                                  .entity(entities)
                                  .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    @PUT
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/updateSyncQueue")
    public Response updateSyncQueue(OalegoDrmSyncQueue[] queue,
                                    @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
           
        }
        try{
            String result = updateSyncQueueHelper(queue);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
    
    
    
    @POST
    @Consumes("application/json")
    @Produces({"application/xml","application/json"})
    @Path("/postQueue")
    public Response postSyncQueue(OalegoDrmSyncQueue[] queue,
                                       @HeaderParam("authorization") String authString) {

        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
                return Response.status(Response.Status.UNAUTHORIZED)
                               .entity("User Not Authorized")
                               .build();
            
        }
        try{
            String result = postSyncQueueHelper(queue);
            return Response.status(Response.Status.OK)
                           .entity(result)
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
        
    
    
    
    @DELETE

    @Path("/removeSyncQueue/{queueNum}")
    public Response removeSyncQueue( @PathParam("queueNum") BigDecimal queueNum, @HeaderParam("authorization") String authString) {
        if (!AuthHelper.isAuthorizedSuperUserAuthString(authString)) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity("User Not Authorized")
                           .build();
        }
        try{
            super.remove(super.find(queueNum));
            return Response.status(Response.Status.OK)
                           .entity("Success")
                           .build();
        }
        catch(Exception e){
            return Response.status(Response.Status.NO_CONTENT)
                           .entity("Failed : "+e.getMessage())
                           .build();
        }
    }
@Override
    protected EntityManager getEntityManager() {
        // TODO Implement this method
        return em;
    }
}

