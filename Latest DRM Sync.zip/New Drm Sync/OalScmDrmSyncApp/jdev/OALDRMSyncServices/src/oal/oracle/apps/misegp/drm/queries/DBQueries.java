package oal.oracle.apps.misegp.drm.queries;

import java.math.BigDecimal;
import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;
public class DBQueries {
    
    public static String getStageTable() {
       return DRMSyncPropertyV2.getInstance().getStageTable();
    }
   public static String getDeltaTable() {
        return DRMSyncPropertyV2.getInstance().getDeltaTable();
    }
    
    public static final String GET_MAX_LEVEL_FROM_CATALOG = "select max(levl) from "+getStageTable()+" where catalog_code = '%s' and refresh_id= '%s'";
   
    public static String getNoofcategories(String refreshId,String catalogCode) {
        return "select count(*) from "+getStageTable()+" where processed_flag='P' and refresh_id='"+refreshId+"' and catalog_code ='"+catalogCode+"' and category_code in (%s)";
        
    }
    
    
    public static String getCategoryCount(String processedFlag,String refreshId,String catalogCode,String levl) {
        return "select count(*) from "+getStageTable()+" "+
        "where processed_flag='"+processedFlag+"' and refresh_id='"+refreshId+"' and catalog_code ='"+catalogCode+"' and levl='"+levl+"'";
                
    }
    
    public static String getCategoryCountOnlyDelta(String processedFlag,String refreshId,String catalogCode,String levl){
        return "select count(*) from "+getStageTable()+" where category_code in (select category_code from "+ getDeltaTable() +" where refresh_id='"+refreshId+"') and refresh_id='"+
               refreshId+"' and processed_flag='"+processedFlag+"' and catalog_code ='"+catalogCode+"' and levl='"+levl+"'";	    
    }
    
    
    public static String getItemCount(String flag,String refreshId,String catalogCode,String levl) {
        return "select count(*) from "+getStageTable()+" "+
        "where is_leaf='True' and item_association='"+flag+"' and refresh_id='"+refreshId+"' and catalog_code ='"+catalogCode+"' and levl='"+levl+"'";
                
    }
   
    public static String updateProcessedFlag(String processedFlag,String refreshId,String catalogCode) {
        String query = "update "+getStageTable()+" set processed_flag='"+processedFlag+"' where refresh_id='"+refreshId+"' and catalog_code ='"+catalogCode+"' and category_code in (%s)";
        return query;
    }
    public static String updateItemAssociation(String itemAssociation,String refreshId,String catalogCode) {
        String query = "update "+getStageTable()+" set item_association='"+itemAssociation+"' where refresh_id='"+refreshId+"' and catalog_code ='"+catalogCode+"' and category_code in (%s)";
        return query;
    }
    
    
    public DBQueries() {
        super();
    }

    public static String updateComments(String comments, BigDecimal refreshId, String catalogCode, String categoryCode) {
        return "update "+getStageTable()+" set comments='"+comments+"' where refresh_id='"+refreshId+"' and catalog_code='"+catalogCode+"' and category_code='"+categoryCode+"'"; 
    
    }

    public static String getUnprocessedOrErroredCat(BigDecimal refreshId, String catalogCode) {
        return  "select category_code from "+getStageTable()+" where processed_flag!='P' and refresh_id='"+refreshId+"' and catalog_code ='"+catalogCode+"' and category_code in (%s)";
        
      
    }
    
    
    public static String getErroredCategoriesQuery(String refreshId, String catlogCode){
        return "select * from "+getStageTable()+ " where processed_flag='E' and refresh_id='"+refreshId+"' and catalog_code='"+catlogCode+"'";
    }
    
    
}
