package oal.oracle.apps.scm.drm.tests;

import oal.oracle.apps.misegp.drm.OALDRMSyncUtil;
import oal.oracle.apps.misegp.drm.helper.AuthHelper;
import oal.oracle.apps.misegp.drm.helper.test.AuthHelperTest;
import oal.oracle.apps.misegp.drm.test.OALDRMSyncUtilTest;
import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;
import oal.oracle.apps.scm.drm.MailNotification;
import oal.oracle.apps.scm.drm.orbit.OrbitMicroServiceInvoker;

import oal.oracle.apps.scm.drm.orbit.test.OrbitMicroServiceInvokerTest;

import oal.oracle.apps.scm.drm.test.ConnectionUtilTest;

import oal.oracle.apps.scm.drm.test.DRMSyncPropertyV2Test;

import oal.oracle.apps.scm.drm.test.KeyStoreAccessorTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
                 
                   // OrbitMicroServiceInvokerTest.class,
                  //  OALDRMSyncUtilTest.class,
                    ConnectionUtilTest.class,
                   // DRMSyncPropertyV2Test.class,
                  // MailNotification.class
                   // KeyStoreAccessorTest.class,
                   // AuthHelperTest.class,
                    })

public class DRMTests {
    


}
