package oal.oracle.apps.scm.drm;

import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

import java.util.Map;
import java.util.HashMap;
import oracle.security.jps.JpsException;
import oracle.security.jps.service.JpsServiceLocator;
import oracle.security.jps.service.ServiceLocator;
import oracle.security.jps.service.credstore.CredentialStore;
import oracle.security.jps.service.credstore.PasswordCredential;

public class KeyStoreAccessor {
    private KeyStoreAccessor() {
        super();
    }
    
    class CustomCredential {
        private String userName;
        private String password;
        CustomCredential(String user,String pass) {
            userName=user;
            password=pass;
        }
       

        public String getUserName() {
            return userName;
        }

       

        public String getPassword() {
            return password;
        }
    }
    
    private static KeyStoreAccessor keyStoreAccessor;
    private String userName;
    private String password;
    private static Map<String,CustomCredential> credentialsCache = new HashMap();
    
    public static KeyStoreAccessor getInstance() {
        if(keyStoreAccessor == null)
            synchronized (KeyStoreAccessor.class) {
                if (keyStoreAccessor == null) {
                    keyStoreAccessor = new KeyStoreAccessor();
                
                }
            }
        return keyStoreAccessor;
    
    }
    
    public String getUserName(String map, String key) {
        return getCredentials(map, key).getUserName();
    }

    

    public String getPassword(String map, String key) {
        return getCredentials(map, key).getPassword();
    }
    
    //Method to fetch credentials for generic user from CDP keystore
    private CustomCredential getCredentials(String map, String key) {
        
        String uniqueKey = map+":"+key;
        
        if(credentialsCache.containsKey(uniqueKey)) {
            return credentialsCache.get(uniqueKey);
        }
                PasswordCredential credentials = null;
                PrivilegedExceptionAction<PasswordCredential> action =
                    new PrivilegedExceptionAction<PasswordCredential>() {
                        public PasswordCredential run() throws JpsException {
                            ServiceLocator locator = JpsServiceLocator.getServiceLocator();
                            CredentialStore store = locator.lookup(CredentialStore.class);
                            return (PasswordCredential) store.getCredential(map, key);
                        }
                    };

                try {
                    credentials = AccessController.doPrivileged(action);
                    userName = credentials.getName();
                    password = new String(credentials.getPassword());
                    
                    CustomCredential cred=new CustomCredential(userName, password);
                    
                    credentialsCache.put(uniqueKey, cred);
                    
                    return cred;
                    
                } catch (PrivilegedActionException e) {
                }
                return new CustomCredential("","");
    }
    
   
}