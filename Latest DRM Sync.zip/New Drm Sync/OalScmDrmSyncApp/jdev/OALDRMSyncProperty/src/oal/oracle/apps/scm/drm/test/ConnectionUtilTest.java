package oal.oracle.apps.scm.drm.test;

import oal.oracle.apps.scm.drm.ConnectionUtil;

import org.junit.Assert;
import org.junit.Test;

public class ConnectionUtilTest {
    public ConnectionUtilTest() {
        super();
    }
    @Test
    public void connectionTest() throws Exception {
        ConnectionUtil.getNewConnection().close();
        Assert.assertEquals("Success", 1, 1);
    }
}
