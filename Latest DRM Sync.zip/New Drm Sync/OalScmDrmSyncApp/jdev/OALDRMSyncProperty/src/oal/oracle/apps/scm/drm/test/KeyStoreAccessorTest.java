package oal.oracle.apps.scm.drm.test;

import oal.oracle.apps.scm.drm.KeyStoreAccessor;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class KeyStoreAccessorTest {
    public KeyStoreAccessorTest() {
        super();
    }
    @Test
    public void keyStoreTest() throws Exception {
        
        
        String username = KeyStoreAccessor.getInstance().getUserName("OALMDMDRM_MAP","OALMDMDRM_KEY");
        String password = KeyStoreAccessor.getInstance().getPassword("OALMDMDRM_MAP","OALMDMDRM_KEY");
        assertEquals(false,username.isEmpty());
        assertEquals(false,password.isEmpty());
        
    }
}
