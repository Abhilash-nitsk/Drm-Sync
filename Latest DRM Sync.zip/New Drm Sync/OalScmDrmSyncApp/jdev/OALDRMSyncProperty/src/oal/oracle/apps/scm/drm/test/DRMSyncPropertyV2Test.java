package oal.oracle.apps.scm.drm.test;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;

import org.junit.Assert;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class DRMSyncPropertyV2Test {
    public DRMSyncPropertyV2Test() {
        super();
    }
    
    @Test
    public void propertyTest() throws Exception {
            Assert.assertNotNull("Property instance is null", DRMSyncPropertyV2.getInstance());
            Assert.assertNotNull("Properties are null. Error may be while reading from property table.", DRMSyncPropertyV2.getInstance().getLastRefreshId());
            assertEquals(false, DRMSyncPropertyV2.getInstance().getLastRefreshId().isEmpty());
            assertEquals(true, DRMSyncPropertyV2.Catalog.CRM.getCode().length()>=4 
                                && DRMSyncPropertyV2.Catalog.CRM.getCode().length()<=6);
        }
}
