package oal.oracle.apps.scm.drm.exception;

public class DRMEmptyFieldException extends DRMException{
    public DRMEmptyFieldException(String s) {
        super(s);
    }
}
