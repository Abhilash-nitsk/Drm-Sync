package oal.oracle.apps.scm.drm.exception;

public class DRMDataSanityTestFailedException extends DRMException{
    public DRMDataSanityTestFailedException(String msg) {
        super(msg);
    }
}
