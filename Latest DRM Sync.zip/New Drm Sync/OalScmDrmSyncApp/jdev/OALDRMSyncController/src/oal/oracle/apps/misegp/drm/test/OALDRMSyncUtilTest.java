package oal.oracle.apps.misegp.drm.test;

import java.sql.SQLException;

import javax.naming.NamingException;

import oal.oracle.apps.misegp.drm.OALDRMSyncUtil;
import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;
import oal.oracle.apps.scm.drm.exception.DRMPaasServiceException;

import org.json.JSONException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class OALDRMSyncUtilTest {
    public OALDRMSyncUtilTest() {
        super();
    }
    @Test
    public void internalServiceTest() throws DRMPaasServiceException, SQLException, NamingException, JSONException {
        assertNotNull("Categories are null",OALDRMSyncUtil.getCategories(DRMSyncPropertyV2.Catalog.FPH.getCode(), 8,DRMSyncPropertyV2.getInstance().getLastRefreshId(), false));
        assertNotNull("Categories are null",OALDRMSyncUtil.getCategoriesfromStageTable(DRMSyncPropertyV2.Catalog.FPH.getCode(),2,DRMSyncPropertyV2.getInstance().getLastRefreshId()));

        int maxLevel=OALDRMSyncUtil.getMaxLevel(DRMSyncPropertyV2.Catalog.FPH.getCode(), DRMSyncPropertyV2.getInstance().getLastRefreshId());
        assertEquals(8, maxLevel);
        assertEquals(true,(OALDRMSyncUtil.getCategoryCount(DRMSyncPropertyV2.Catalog.FPH.getCode(),maxLevel-1,"U", DRMSyncPropertyV2.getInstance().getLastRefreshId())
                                +OALDRMSyncUtil.getCategoryCount(DRMSyncPropertyV2.Catalog.FPH.getCode(),maxLevel-1,"P", DRMSyncPropertyV2.getInstance().getLastRefreshId())>0));
    }
}
