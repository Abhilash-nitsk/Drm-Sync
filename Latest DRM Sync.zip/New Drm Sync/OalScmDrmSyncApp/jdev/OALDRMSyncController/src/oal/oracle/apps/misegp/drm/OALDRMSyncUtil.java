package oal.oracle.apps.misegp.drm;

import java.sql.SQLException;

import oal.oracle.apps.scm.drm.DRMSyncPropertyV2;

import oal.oracle.apps.scm.drm.exception.DRMPaasServiceException;

import java.util.ArrayList;
import java.util.List;

import oal.util.logger.*;
import java.util.Set;
import java.util.HashSet;
import javax.json.JsonArray;

import javax.naming.NamingException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;



public class OALDRMSyncUtil {
    private static String loggerName = OALDRMSyncUtil.class.getName();
    private static final String GET_CATEGORY_COUNT_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getCategoryCount";
    private static final String GET_ITEM_COUNT_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getItemCount";

    private static final String GET_MAX_LEVEL_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getMaxLevel";
    private static final String GET_CATEGORIES_STAGE_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getCategoryCatalog";
    private static final String GET_CHANGED_CATEGORIES_DELTA_SERVICE_URL="/OALSCMDRMSyncServices/service/categoryChange/getChangedCategories";
    private static final String UPDATE_PROCESSED_FLAG_SERVICE_URL="/OALSCMDRMSyncServices/service/category/updateProcessedFlag";
    private static final String UPDATE_COMMENTS_SERVICE_URL=  "/OALSCMDRMSyncServices/service/category/updateComments";
    private static final String UPDATE_ITEM_PROCESSED_FLAG_SERVICE_URL= "/OALSCMDRMSyncServices/service/category/updateItemProcessedFlag";
    private static final String GET_NO_OF_PROCESSED_CAT_SERVICE_URL=  "/OALSCMDRMSyncServices/service/category/getNoOfProcessedCatgories";
    private static final String DELETE_PROCESSED_CATEGORY_SERVICE_URL=  "/OALSCMDRMSyncServices/service/categoryChange/deleteProcessed";
    private static final String GET_ERRORED_CATEGORY_SERVICE_URL="/OALSCMDRMSyncServices/service/category/getErroredCategories/";
   
    public OALDRMSyncUtil() {
        super();
    }
    
    

public static String getURL(String url,String catalogCode,int level,String refreshId,String processedFlag,
                            String itemAssociation,int limit,int offset,boolean leafFlag,String categoryCode) {
    
    UriBuilder uri = UriBuilder.fromUri(url);
    if(catalogCode!=null)
        uri.queryParam("catalogCode", catalogCode);
    if(level>0)
        uri.queryParam("levl", level);
    if(refreshId!=null)
        uri.queryParam("refreshId", refreshId);
    if(processedFlag!=null)
        uri.queryParam("processedFlag", processedFlag);
    if(itemAssociation!=null)
        uri.queryParam("itemAssociation", itemAssociation);
    if(offset>=0)
        uri.queryParam("offset", offset);
    if(limit>=0)
        uri.queryParam("limit", limit);
    if(leafFlag)
        uri.queryParam("isLeaf", "True");
    if(categoryCode!=null)
        uri.queryParam("categoryCode", categoryCode);
    
    return uri.toString();
   
}


    
public static String getResponse(String itemsUrlWithParams) throws DRMPaasServiceException {
    Client client = ClientBuilder.newClient();
    String authorizationHeaderName = "Authorization";
    String authorizationHeaderValue = "Basic " +
    DRMSyncPropertyV2.getInstance().getPaaSAuthorizationKey();
    WebTarget target = client.target(itemsUrlWithParams);
    Response clientResponse = target.request().header(authorizationHeaderName,authorizationHeaderValue).get();
    String itemsJson = null;
    if (clientResponse.getStatus() != 200) {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "url:[" + itemsUrlWithParams + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "fatal",
                          "Service Failed with response code: " + clientResponse.getStatus());
        throw new DRMPaasServiceException("Return Code" + clientResponse.getStatus());

    } else {
        itemsJson = clientResponse.readEntity(String.class);
    }
    return itemsJson;
}

    public static String invokeUpdatePost(String itemsUrlWithParams,JSONObject payload) {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(itemsUrlWithParams);
        String clientResponse = null;
        String authorizationHeaderName = "Authorization";
        String authorizationHeaderValue = "Basic " +
        DRMSyncPropertyV2.getInstance().getPaaSAuthorizationKey();
        clientResponse = target.request(MediaType.APPLICATION_JSON).header(authorizationHeaderName,authorizationHeaderValue)
                               .accept(MediaType.TEXT_PLAIN)
                               .post(Entity.json(payload.toString()), String.class);

        return clientResponse;
    }
    public static String invokeUpdatePut(String itemsUrlWithParams,JSONObject payload) {
        
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target(itemsUrlWithParams);
        String clientResponse = null;
        String authorizationHeaderName = "Authorization";
        String authorizationHeaderValue = "Basic " +
        DRMSyncPropertyV2.getInstance().getPaaSAuthorizationKey();
        clientResponse = target.request(MediaType.APPLICATION_JSON).header(authorizationHeaderName,authorizationHeaderValue)
                               .accept(MediaType.TEXT_PLAIN)
                               .put(Entity.json(payload.toString()),String.class);

        return clientResponse.toString();
    }
    
    public static int getCategoryCount(String catalogCode, int level, String processedFlag,String refreshId) throws DRMPaasServiceException {

        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_CATEGORY_COUNT_SERVICE_URL;
        String itemsUrlWithParams = getURL(url,catalogCode,level,refreshId,processedFlag,null,-1,-1,false,null);
        String itemsJson = getResponse(itemsUrlWithParams);
        return Integer.parseInt(itemsJson);

    }
    public static int getItemCount(String catalogCode, int level, String itemFlag,String refreshId) throws DRMPaasServiceException {

        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_ITEM_COUNT_SERVICE_URL;
        String itemsUrlWithParams = getURL(url,catalogCode,level,refreshId,null,itemFlag,-1,-1,false,null);
        String itemsJson = getResponse(itemsUrlWithParams);
        return Integer.parseInt(itemsJson);

    }
    
    
    
    public static int getMaxLevel(String catalogCode, String refreshId) throws DRMPaasServiceException {


        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get max level of catalog : " + catalogCode);
        
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_MAX_LEVEL_SERVICE_URL;
        String itemsUrlWithParams = getURL(url,catalogCode,0,refreshId,null,null,-1,-1,false,null);
        
        String itemsJson = getResponse(itemsUrlWithParams);
        return Integer.parseInt(itemsJson);
        
    }

    public static Set<String> getErroredCategories(String catalogCode, int level,
                                                   String refreshId) throws DRMPaasServiceException, JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get errored categories for catalog : " + catalogCode + ", level :" +
                          level);

        Set<String> catList = new HashSet<String>();

        int offset = 0;
        int serviceLimit = 400;
        
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
       url+=GET_CATEGORIES_STAGE_SERVICE_URL;
        
        JSONArray jsonArray = null;
        do {
            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, "E", null, serviceLimit, offset,false,null);
            String itemsJson = getResponse(itemsUrlWithParams);
            jsonArray = new JSONArray(itemsJson);
            
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.getJSONObject(i).getString("categoryCode"));
               
            offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);

         return catList;
    }

    public static JSONArray getCategories(String catalogCode, int level, String refreshId,
                                          boolean leaf) throws DRMPaasServiceException, JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "1.Calling paas ws to get changed categories for catalog : " + catalogCode + ", level :" + level);

        List<String> catList = new ArrayList<String>();
        JSONArray retArr = new JSONArray();

        int offset = 0;
        int serviceLimit = 400;
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_CHANGED_CATEGORIES_DELTA_SERVICE_URL;
        JSONArray jsonArray = null;
        do {
            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, null, null, serviceLimit, offset,leaf,null);
            String itemsJson = getResponse(itemsUrlWithParams);

                jsonArray = new JSONArray(itemsJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject job = new JSONObject();
                    job = jsonArray.getJSONObject(i);
                    retArr.put(job);
                }
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.get(i).toString());
              
                    offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "1.Success, Calling paas ws to get changed categories for catalog : " + catalogCode + ", level :" + level);

        return retArr;
    }
    
    public static JSONArray getBoundCategories(String catalogCode, int level, String refreshId,
                                          boolean leaf,int offset) throws DRMPaasServiceException, JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "1.Calling paas ws to get changed categories for catalog : " + catalogCode + ", level :" + level);

        List<String> catList = new ArrayList<String>();
        JSONArray retArr = new JSONArray();
        int serviceLimit = 400;
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_CHANGED_CATEGORIES_DELTA_SERVICE_URL;
        JSONArray jsonArray = null;
        
            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, null, null, serviceLimit, offset,leaf,null);
            String itemsJson = getResponse(itemsUrlWithParams);

                jsonArray = new JSONArray(itemsJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject job = new JSONObject();
                    job = jsonArray.getJSONObject(i);
                    retArr.put(job);
                }
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.get(i).toString());
              
        
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "1.Success, Calling paas ws to get changed categories for catalog : " + catalogCode + ", level :" + level);
        return retArr;
    }


    public static JSONArray getCategoriesfromStageTable(String catalogCode, int level,
                                                        String refreshId) throws DRMPaasServiceException,
                                                                                 JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get from stage categories for catalog : " + catalogCode + ", level :" + level);

        List<String> catList = new ArrayList<String>();
        JSONArray retArr = new JSONArray();

        int offset = 0;
        int serviceLimit = 400;
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_CATEGORIES_STAGE_SERVICE_URL;
        JSONArray jsonArray = null;
        do {

            String itemsUrlWithParams = getURL(url, catalogCode, level, refreshId, null, null, serviceLimit, offset,false,null);
            String itemsJson = getResponse(itemsUrlWithParams);
            
                jsonArray = new JSONArray(itemsJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject job = new JSONObject();
                    job = jsonArray.getJSONObject(i);
                    retArr.put(job);
                }
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.get(i).toString());
               
            offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Success. Calling paas ws to get from stage categories for catalog : " + catalogCode + ", level :" + level);
        return retArr;
    }




    public static JSONArray getErroredCategoriesfromStageTable(String catalogCode, int level,
                                                        String refreshId) throws DRMPaasServiceException,
                                                                                 JSONException {
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Calling paas ws to get from Errored Categories from stage categories for catalog : " + catalogCode + ", level :" + level);

        List<String> catList = new ArrayList<String>();
        JSONArray retArr = new JSONArray();

        int offset = 0;
        int serviceLimit = 400;
        String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
        url+=GET_ERRORED_CATEGORY_SERVICE_URL;
        url=url+refreshId+"/catalogCode/"+catalogCode;
        JSONArray jsonArray = null;
        do {

            String itemsUrlWithParams = getURL(url, null, 0, null, null, null, serviceLimit, offset,false,null);
            String itemsJson = getResponse(itemsUrlWithParams);
            
                jsonArray = new JSONArray(itemsJson);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject job = new JSONObject();
                    job = jsonArray.getJSONObject(i);
                    retArr.put(job);
                }
                for (int i = 0; i < jsonArray.length(); i++)
                    catList.add(jsonArray.get(i).toString());
               
            offset += jsonArray.length();
        } while (jsonArray.length() == serviceLimit);
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Success. Calling paas ws to get from stage categories for catalog : " + catalogCode + ", level :" + level);
        return retArr;
    }




    public static String updateCategoriesV2(String catalogCode, JSONArray arr, int a, int b,
                                            String processedFlag,String refreshId) throws JSONException {
        //
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to Update processed flag in stage table");

        
        JSONArray retArray = new JSONArray();
        for (int i = a; i < arr.length() && i < b; i++) {
            
            JSONObject jobj = arr.getJSONObject(i);
            retArray.put(jobj.getString("categoryCode"));
           
        }
        JSONObject retObj=new JSONObject();
        retObj.put("categories",retArray);
           

        
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            url+=UPDATE_PROCESSED_FLAG_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, processedFlag, null, -1, -1,false,null);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, retObj);
        } catch (Exception e) {
        }
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "Success. calling paas ws to Update processed flag in stage table");
        return clientResponse;
    }

    public static String updateItemAssociation(String catalogCode, JSONArray arr, int a, int b,
                                               List<Integer> leafIndex,
                                               String itemProcessedFlag,String refreshId) throws JSONException {
        
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to Update Item Association flag in stage table");
        
        JSONArray retArr=new JSONArray();
        
        if (leafIndex == null) {
            for (int j = a; j < b; j++) {

                JSONObject jobj = arr.getJSONObject(j);
                
                retArr.put(jobj.getString("categoryCode"));
               
            }
        } else {

            for (int j : leafIndex) {
                if (j < a || j >= b)
                    continue;
                JSONObject jobj = arr.getJSONObject(j);
                retArr.put(jobj.getString("categoryCode"));

            }
        }
       
        if (retArr.length() == 0)
            return "";

        JSONObject obj=new JSONObject();
        obj.put("categories",retArr);
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            url+=UPDATE_ITEM_PROCESSED_FLAG_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, itemProcessedFlag, -1, -1,false,null);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, obj);
        } catch (Exception e) {
        }
        return clientResponse;
    }


    public static String updateComments(String catalogCode, String categoryCode,
                                        String comments,String refreshId) throws JSONException {
        
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to Update comments in stage table");

        JSONObject obj=new JSONObject();
        obj.put("comment",comments);
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            url+=UPDATE_COMMENTS_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, null, -1, -1,false,categoryCode);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, obj);
            
        } catch (Exception e) {
        }
        return clientResponse;
    }


    public static boolean parentExist(String catalogCode, JSONArray arr, int a, int b,String refreshId) throws JSONException {

        Set<String> catcode = new HashSet<String>();
       
        for (int i = a; i < arr.length() && i < b; i++) {

            catcode.add(arr.getJSONObject(i).getString("parentCategoryCode"));

        }
        JSONArray retArr=new JSONArray();
        for (String s : catcode) {
            retArr.put(s);
        }

        JSONObject obj=new JSONObject();
        obj.put("categories",retArr);
       

        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug",
                          "calling paas ws to check if parent exist for catalog " + catalogCode + " and categories " +
                          retArr.toString());
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            url+=GET_NO_OF_PROCESSED_CAT_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, null, -1, -1,false,null);
            clientResponse=invokeUpdatePost(itemsUrlWithParams, obj);
           
        } catch (Exception e) {
        }
        if (Integer.parseInt(clientResponse) == catcode.size())
            return true;
        return false;
    }


    public static String deleteCategories(String catalogCode, JSONArray arr, int a,
                                          int b,String refreshId) throws JSONException {
        
        OalLogger.sendLog(DRMSyncPropertyV2.getInstance().getLoggerFlowName(), loggerName + "[" + catalogCode + "]",
                          DRMSyncPropertyV2.getInstance().getLoggerID(), "debug", "delete in stage table");

        JSONArray retArr=new JSONArray();
        for (int i = a; i < arr.length() && i < b; i++) {
            JSONObject jobj = arr.getJSONObject(i);
           retArr.put(jobj.getString("categoryCode"));
           
        }
        JSONObject obj = new JSONObject();
            obj.put("categories",retArr);
       
        String clientResponse = null;
        try {
            String url = DRMSyncPropertyV2.getInstance().getDRMSyncServiceBaseURL();
            url+=DELETE_PROCESSED_CATEGORY_SERVICE_URL;
            String itemsUrlWithParams = getURL(url, catalogCode, 0, refreshId, null, null, -1, -1,false,null);
            clientResponse=invokeUpdatePut(itemsUrlWithParams, obj);
            
        } catch (Exception e) {
        }
        return clientResponse;
    }


}
