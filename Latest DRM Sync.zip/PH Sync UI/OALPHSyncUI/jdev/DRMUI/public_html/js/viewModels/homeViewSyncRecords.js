/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * homeViewSyncRecords module
 */

define(['ojs/ojcore', 'knockout', 'jquery', 'viewModels/constData', 'ojs/ojknockout', 'promise', 'ojs/ojtable', 'ojs/ojinputtext', 'ojs/ojtrain', 'ojs/ojbutton', 'ojs/ojmodel', 'ojs/ojcollectiontabledatasource', 'ojs/ojpopup', 'ojs/ojcheckboxset', 'ojs/ojtoolbar', 'ojs/ojmenu', 'ojs/ojradioset', 'ojs/ojlabel', 'ojs/ojpagingcontrol', 'ojs/ojpagingtabledatasource', 'ojs/ojarraydataprovider', 'ojs/ojarraytabledatasource'], function (oj, ko, $, constD) {

    function homeViewSyncRecordsContentViewModel() {
        var self = this;

        self.dataprovider = ko.observable();
        self.categorydataprovider = ko.observable();
        self.catalogdataprovider = ko.observable();
        self.categoryfilter = ko.observable();
        self.selectedStepValue = ko.observable('stp1');
        self.selectedStep = ko.observable('stp1');
        self.showstep1 = ko.observable(true);
        self.showstep2 = ko.observable(false);
        self.showstep3 = ko.observable(false);
        self.lastrundate = ko.observable();
        self.showmessage = ko.observable(false);
        self.showConfirmationMsg = ko.observable(false);
        self.showErrorMsg = ko.observable(false);
        self.conf_messageDetails = ko.observable('');
        self.error_messageDetails = ko.observable('');
        self.showLoader = ko.observable(false);
        self.isdrmuser = constD.isdrmuser();

        $.ajax( {
            url : constD.base_url + "GetSyncRecord/getSyncRefresh", type : 'GET', contentType : 'application/json; charset=utf-8', success : function (data, textStatus) {
                //need to call Logger api to log the statements
                if (JSON.stringify(data) !== null) {
                    self.dataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                    {
                        idAttribute : 'refreshId'
                    })));
                }

            },
            error : function (xhr, textStatus, errorThrown) {
                //need to call Logger api to log the statements
            }
        });
        
        $.ajax( {
            url : constD.base_url + "GetSyncProperty/getSyncProperty?key=last_refresh_timestamp", type : 'GET', contentType : 'application/json; charset=utf-8', timeout : 0, success : function (data, textStatus) {
                //need to call Logger api to log the statements
                if (JSON.stringify(data) !== null) {
                    self.lastrundate(data[0].value);
                }

            },
            error : function (xhr, textStatus, errorThrown) {
                //need to call Logger api to log the statements
                self.lastrundate(null);
            }
        });
        self.stepArray = ko.observableArray([{label : 'Jobs', id : 'stp1'},{label : 'Catalogs', disabled : true, id : 'stp2'},{label : 'Categories', disabled : true, id : 'stp3'}]);
        self.updateLabelText = function (event) {
            var train = document.getElementById("train");
            self.selectedStep(train.getStep(event.detail.value).id);
            self.categoryfilter('');

            self.showstep1(false);
            self.showstep2(false);
            self.showstep3(false);
            if (self.selectedStep() == 'stp1') {
                self.showstep1(true);
                self.stepArray([{label : 'Jobs', id : 'stp1'},{label : 'Catalogs', disabled : true, id : 'stp2'},{label : 'Categories', disabled : true, id : 'stp3'}]);
            }
            if (self.selectedStep() == 'stp2') {
                self.showstep2(true);
                self.stepArray([{label : 'Jobs', id : 'stp1'},{label : 'Catalogs', id : 'stp2'},{label : 'Categories', disabled : true, id : 'stp3'}]);
            }
            if (self.selectedStep() == 'stp3') {
                self.showstep3(true);
                self.stepArray([{label : 'Jobs', id : 'stp1'},{label : 'Catalogs', id : 'stp2'},{label : 'Categories', id : 'stp3'}]);
            }
        };

        self.categoriessearchClick = function (event) {
            var taskCollections, collections, taskModels, datasources;
            if (self.showstep1()) {
                
                $.ajax( {
                    url : constD.base_url + "GetSyncRecord/searchCategoryCode?searchParam=" + self.categoryfilter(), type : 'GET', contentType : 'application/json; charset=utf-8', success : function (data, textStatus) {
                        //need to call Logger api to log the statements
                        if (JSON.stringify(data) !== null) {
                            self.dataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                            {
                                idAttribute : 'refreshId'
                            })));
                        }

                    },
                    error : function (xhr, textStatus, errorThrown) {
                        //need to call Logger api to log the statements
                    }
                });
            }
            else if (self.showstep2()) {
               
                $.ajax( {
                    url : constD.base_url + "GetSyncRecord/searchCategoryCatalogCode/" + self.rkey() + "?searchParam=" + self.categoryfilter(), type : 'GET', contentType : 'application/json; charset=utf-8', success : function (data, textStatus) {
                        //need to call Logger api to log the statements
                        if (JSON.stringify(data) !== null) {
                            self.catalogdataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                            {
                                idAttribute : 'catalogCode'
                            })));
                        }
                        console.log(self.catalogdataprovider());
                    },
                    error : function (xhr, textStatus, errorThrown) {
                        //need to call Logger api to log the statements
                    }
                });
            }
            else if (self.showstep3()) {
                
                $.ajax( {
                    url : constD.base_url + "GetSyncHistoryData/searchCategoryCode/" + self.rkey() + "/catalogCode/" + self.catalogcode() + "?searchParam=" + self.categoryfilter(), type : 'GET', contentType : 'application/json; charset=utf-8', timeout : 0, success : function (data, textStatus) {
                        //need to call Logger api to log the statements
                        if (JSON.stringify(data) !== null) {
                            self.categorydataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                            {
                                idAttribute : 'categoryCode'
                            })));
                        }

                    },
                    error : function (xhr, textStatus, errorThrown) {
                        //need to call Logger api to log the statements
                    }
                });
            }

        }
        self.categoriesclearClick = function (event) {
            self.categoryfilter('');
            var taskCollectionc, collectionc, taskModelc, datasourcec;
            if (self.showstep1()) {
               
                $.ajax( {
                    url : constD.base_url + "GetSyncRecord/getSyncRefresh", type : 'GET', contentType : 'application/json; charset=utf-8', success : function (data, textStatus) {
                        //need to call Logger api to log the statements
                        if (JSON.stringify(data) !== null) {
                            self.dataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                            {
                                idAttribute : 'refreshId'
                            })));
                        }

                    },
                    error : function (xhr, textStatus, errorThrown) {
                        //need to call Logger api to log the statements
                    }
                });
            }
            else if (self.showstep2()) {
                
                $.ajax( {
                    url : constD.base_url + "GetSyncRecord/getSyncCatalog/" + self.rkey(), type : 'GET', contentType : 'application/json; charset=utf-8', success : function (data, textStatus) {
                        //need to call Logger api to log the statements
                        if (JSON.stringify(data) !== null) {
                            self.catalogdataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                            {
                                idAttribute : 'catalogCode'
                            })));
                        }
                        console.log(self.catalogdataprovider());
                    },
                    error : function (xhr, textStatus, errorThrown) {
                        //need to call Logger api to log the statements
                    }
                });
            }
            else if (self.showstep3()) {
                
                $.ajax( {
                    url : constD.base_url + "GetSyncHistoryData/getHistroyCategories/" + self.rkey() + "/catalogCode/" + self.catalogcode(), type : 'GET', contentType : 'application/json; charset=utf-8', timeout : 0, success : function (data, textStatus) {
                        //need to call Logger api to log the statements
                        if (JSON.stringify(data) !== null) {
                            self.categorydataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                            {
                                idAttribute : 'categoryCode'
                            })));
                        }

                    },
                    error : function (xhr, textStatus, errorThrown) {
                        //need to call Logger api to log the statements
                    }
                });
            }

        }
        self.exportClick = function (event) {
            $("#exportButton").ojButton( {
                "disabled" : true
            });
            self.showmessage(true);
            self.showLoader(true);
            $.ajax( {
                url : constD.base_url + "GetSyncHistoryData/getCategoriesReport/" + self.rkey(), type : 'GET', contentType : 'application/json; charset=utf-8', timeout : 0, success : function (data, textStatus) {
                    //need to call Logger api to log the statements
                    if (JSON.stringify(data) !== null && JSON.stringify(data) !== "[]") {
                        JSONToCSVConvertor(data, self.rkey(), 'Test');
                        $("#exportButton").ojButton( {
                            "disabled" : false
                        });
                        self.conf_messageDetails("Downloaded Successfully");
                        self.showLoader(false);
                        self.showConfirmationMsg(true);
                        setTimeout(function () {
                            self.showConfirmationMsg(false);
                            self.showmessage(false);
                        },
                        5000);
                    }
                    else {
                        $("#exportButton").ojButton( {
                            "disabled" : false
                        });
                        self.error_messageDetails("Download Failed.. No data available for requested refresh Id.");
                        self.showLoader(false);
                        self.showErrorMsg(true);
                        setTimeout(function () {
                            self.showErrorMsg(false);
                            self.showmessage(false);
                        },
                        5000);
                    }

                },
                error : function (xhr, textStatus, errorThrown) {
                    //need to call Logger api to log the statements
                    $("#exportButton").ojButton( {
                        "disabled" : false
                    });
                    self.error_messageDetails("Download Failed.. Please try again.");
                    self.showLoader(false);
                    self.showErrorMsg(true);
                    setTimeout(function () {
                        self.showErrorMsg(false);
                        self.showmessage(false);
                    },
                    5000);
                }
            });

        }

        self.rkey = ko.observable();
        self.selectionChange = function (context, valueparam) {
            var key = context.detail.currentRow.rowKey;
            self.rkey(key);
            self.showstep1(false);
            self.showstep2(true);
            self.showstep3(false);
            self.selectedStepValue('stp2');
            self.stepArray([{label : 'Jobs', id : 'stp1'},{label : 'Catalogs', id : 'stp2'},{label : 'Categories', disabled : true, id : 'stp3'}])

            $.ajax( {
                url : constD.base_url + "GetSyncRecord/getSyncCatalog/" + self.rkey(), type : 'GET', contentType : 'application/json; charset=utf-8', success : function (data, textStatus) {
                    //need to call Logger api to log the statements
                    if (JSON.stringify(data) !== null) {
                        self.catalogdataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                        {
                            idAttribute : 'catalogCode'
                        })));
                    }
                    console.log(self.catalogdataprovider());
                },
                error : function (xhr, textStatus, errorThrown) {
                    //need to call Logger api to log the statements
                }
            });

        };
        self.catalogcode = ko.observable();
        self.catalogselectionChange = function (context, valueParam) {
            var rowkey = context.detail.currentRow.rowKey;
            self.catalogcode(rowkey);
            self.showstep1(false);
            self.showstep2(false);
            self.showstep3(true);
            self.selectedStepValue('stp3');
            self.stepArray([{label : 'Jobs', id : 'stp1'},{label : 'Catalogs', id : 'stp2'},{label : 'Categories', id : 'stp3'}])
            $.ajax( {
                url : constD.base_url + "GetSyncHistoryData/getHistroyCategories/" + self.rkey() + "/catalogCode/" + rowkey, type : 'GET', contentType : 'application/json; charset=utf-8', timeout : 0, success : function (data, textStatus) {
                    //need to call Logger api to log the statements
                    if (JSON.stringify(data) !== null) {
                        self.categorydataprovider(new oj.PagingTableDataSource(new oj.ArrayTableDataSource(data, 
                        {
                            idAttribute : 'categoryCode'
                        })));
                    }

                },
                error : function (xhr, textStatus, errorThrown) {
                    //need to call Logger api to log the statements
                }
            });
            
        };

        function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {
            var arrData = typeof JSONData !== 'object' ? JSON.parse(JSONData) : JSONData;
            var CSV = '';
            if (ShowLabel) {
                var row = "";
                for (var index in arrData[0]) {
                    if (arrData[0].hasOwnProperty(index)) {
                        row += index + ',';
                    }
                }
                row = row.slice(0,  - 1);
                CSV += row + '\r\n';
            }

            for (var i = 0;i < arrData.length;i++) {
                var row1 = "";
                for (var index1 in arrData[i]) {
                    if (arrData[i].hasOwnProperty(index1)) {
                        row1 += '"' + arrData[i][index1] + '",';
                    }
                }
                row1.slice(0, row1.length - 1);
                CSV += row1 + '\r\n';
            }
            if (CSV === '') {

                return;
            }
            var fileName = "Export_";
            fileName += ReportTitle;
            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
            var link = document.createElement("a");
            link.href = uri;
            link.style = "visibility:hidden";
            link.download = fileName + ".csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

        }
    }
    return homeViewSyncRecordsContentViewModel;
});